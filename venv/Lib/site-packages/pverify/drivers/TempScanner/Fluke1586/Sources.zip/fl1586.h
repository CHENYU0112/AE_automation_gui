/*****************************************************************************
 *          (c) 2014, National Instruments. All Rights Reserved.                                     
 *----------------------------------------------------------------------------
 *
 * Title:    fl1586.h
 * 
 * Purpose:  Fluke 1586 Precision Temperature Scanner Instrument 
 *           Driver declarations.                               
 *                                                                   
 *****************************************************************************/

#ifndef _FL1586_HEADER_
#define _FL1586_HEADER_

#include <cvidef.h>
#include <vpptype.h>

#if defined(__cplusplus) || defined(__cplusplus__)
extern "C" {
#endif
  
/***************************************************************************************/
/*= Instrument Driver Specific Error/Warning Codes ====================================*/
/***************************************************************************************/
#define VI_ERROR_INSTR_FILE_OPEN                    (_VI_ERROR+0x3FFC0800L)
#define VI_ERROR_INSTR_FILE_WRITE                   (_VI_ERROR+0x3FFC0801L)
#define VI_ERROR_INSTR_INTERPRETING_RESPONSE        (_VI_ERROR+0x3FFC0803L)
#define VI_ERROR_INSTR_PARAMETER9                   (_VI_ERROR+0x3FFC0809L)
#define VI_ERROR_INSTR_PARAMETER10                  (_VI_ERROR+0x3FFC080AL)
#define VI_ERROR_INSTR_PARAMETER11                  (_VI_ERROR+0x3FFC080BL)
#define VI_ERROR_INSTR_PARAMETER12                  (_VI_ERROR+0x3FFC080CL)
#define VI_ERROR_INSTR_PARAMETER13                  (_VI_ERROR+0x3FFC080DL)        
#define VI_ERROR_INSTR_PARAMETER14                  (_VI_ERROR+0x3FFC080EL)
#define VI_ERROR_INSTR_PARAMETER15                  (_VI_ERROR+0x3FFC080FL)
                                        

/***************************************************************************************/
/*= Instrument Specific Error/Warning Codes ===========================================*/
/***************************************************************************************/
#define VI_WARNING_INSTR_OFFSET                     (0x3FFC0900L)
#define VI_ERROR_INSTR_OFFSET                       (_VI_ERROR+0x3FFC0900L)

#define FL1586_ERROR_COMMAND_ERROR                  (VI_ERROR_INSTR_OFFSET + 0x10L)
#define FL1586_ERROR_DEVICE_ERROR                   (VI_ERROR_INSTR_OFFSET + 0x20L) 
#define FL1586_ERROR_TIMEOUT_ERROR                  (VI_ERROR_INSTR_OFFSET + 0x30L)


/*****************************************************************************
 *----------------------- Constant Value Defines ----------------------------*
 *****************************************************************************/

/* Standard Event Register Bits */
#define FL1586_VAL_ESR_OPERATION_COMPLETE          (1)
#define FL1586_VAL_ESR_DEVICE_ERROR                (8)
#define FL1586_VAL_ESR_EXECUTION_ERROR             (16)
#define FL1586_VAL_ESR_COMMAND_ERROR               (32)
#define FL1586_VAL_ESR_POWER_ON                    (128)

/* Defined values for parameter ALARMFUNCTIONNUMBER of function :
    fl1586_ConfigureChannelAlarm
*/
#define FL1586_ALARM_FUNCTION_1 1
#define FL1586_ALARM_FUNCTION_2 2

/* Defined values for parameter ALARMPORT of function :
    fl1586_ConfigureChannelAlarm
*/
#define FL1586_ALARMPORT_NONE   0
#define FL1586_ALARMPORT_1      1
#define FL1586_ALARMPORT_2      2
#define FL1586_ALARMPORT_3      3
#define FL1586_ALARMPORT_4      4
#define FL1586_ALARMPORT_5      5
#define FL1586_ALARMPORT_6      6

/* Defined values for parameter ALARMTYPE of function :
    fl1586_ConfigureChannelAlarm
*/
#define FL1586_ALARMTYPE_OFF    0
#define FL1586_ALARMTYPE_HIGH   1
#define FL1586_ALARMTYPE_LOW    2

/* Defined values for parameter DATAOPERATION of function :
    fl1586_DeleteExportData
*/
#define FL1586_DELETE_ALL_FILES         0
#define FL1586_DELETE_A_FILE            1
#define FL1586_COPY_TO_USB_MEMORY       2

/* Defined values for parameter DCCURRENTRANGE of function :
    fl1586_ConfigureDCCurrentRange
*/
#define FL1586_DC_CURRENT_RANGE_AUTO    0
#define FL1586_DC_CURRENT_RANGE_100UA   1
#define FL1586_DC_CURRENT_RANGE_1MA     2
#define FL1586_DC_CURRENT_RANGE_10MA    3
#define FL1586_DC_CURRENT_RANGE_100MA   4

/* Defined values for parameter DCVOLTAGERANGE of function :
    fl1586_ConfigureDCVoltageRange
*/
#define FL1586_DC_VOLTAGE_RANGE_AUTO    0
#define FL1586_DC_VOLTAGE_RANGE_100MV   1
#define FL1586_DC_VOLTAGE_RANGE_1V      2
#define FL1586_DC_VOLTAGE_RANGE_10V     3
#define FL1586_DC_VOLTAGE_RANGE_50V     4

/* Defined values for parameter FILEOPERATION of function :
    fl1586_DeleteRenameSetupFile
*/
#define FL1586_DELETE_ALL_SETUP_FILES   0
#define FL1586_DELETE_A_SETUP_FILE      1
#define FL1586_RENAME_A_SETUP_FILE      2

/* Defined values for parameter FILEOPERATION of function :
    fl1586_SaveLoadSetupFile
*/
#define FL1586_SAVE_SETUP_FILE  0
#define FL1586_LOAD_SETUP_FILE  1

/* Defined values for parameter FILETYPE of function :
    fl1586_QueryFileStatus
*/
#define FL1586_SETUP_FILE                   0
#define FL1586_INTERNAL_MEMORY_DATA_FILE    1
#define FL1586_USB_MEMORY_DATA_FILE         2

/* Defined values for parameter MATHFUNCTION of function :
    fl1586_ConfigureMathChannel
*/
#define FL1586_MATHFUNCTION_POLYNOMIAL  0
#define FL1586_MATHFUNCTION_SQUARE_ROOT 1
#define FL1586_MATHFUNCTION_POWER       2
#define FL1586_MATHFUNCTION_EXPONENTIAL 3
#define FL1586_MATHFUNCTION_LOG10       4
#define FL1586_MATHFUNCTION_ABSOLUTE    5
#define FL1586_MATHFUNCTION_RECIPROCAL  6
#define FL1586_MATHFUNCTION_ADD         7
#define FL1586_MATHFUNCTION_SUBTRACT    8
#define FL1586_MATHFUNCTION_MULTIPLY    9
#define FL1586_MATHFUNCTION_DIVIDE      10
#define FL1586_MATHFUNCTION_AVERAGE     11
#define FL1586_MATHFUNCTION_MAXIMUM     12
#define FL1586_MATHFUNCTION_MINIMUM     13
#define FL1586_MATHFUNCTION_SUM         14

/* Defined values for parameter MEASUREMENTTYPE of function :
    fl1586_ConfigureChannelMeasurement
*/
#define FL1586_MEASUREMENTTYPE_DC_VOLTAGE           0
#define FL1586_MEASUREMENTTYPE_DC_CURRENT           1
#define FL1586_MEASUREMENTTYPE_FOURWIRE_RESISTANCE  2
#define FL1586_MEASUREMENTTYPE_TWOWIRE_RESISTANCE   3
#define FL1586_MEASUREMENTTYPE_TEMPERATURE          4

/* Defined values for parameter MEMORYDEVICE of function :
    fl1586_StoreScanData
    fl1586_ConfigureDataRecording
    fl1586_ReadDataFile
*/
#define FL1586_INTERNAL_FLASH_MEMORY    0
#define FL1586_EXTERNAL_USB_MEMORY      1

/* Defined values for parameter READOPERATION of function :
    fl1586_ReadScanSweep
*/
#define FL1586_READ_SCAN_SWEEP_NUMBER           0
#define FL1586_READ_LATEST_SCAN_SWEEP           1
#define FL1586_READ_DELETE_EARLIEST_SCAN_SWEEP  2

/* Defined values for parameter REFERENCEJUNCTIONTYPE of function :
    fl1586_ConfigureThermocoupleMeasurement
*/
#define FL1586_REFERENCE_JUNCTION_INTERNAL  0
#define FL1586_REFERENCE_JUNCTION_FIXED     1
#define FL1586_REFERENCE_JUNCTION_EXTERNAL  2

/* Defined values for parameter RESISTANCERANGE of function :
    fl1586_ConfigureFourResistanceRange
    fl1586_ConfigureTwoResistanceRange
*/
#define FL1586_RESISTANCE_RANGE_AUTO        0
#define FL1586_RESISTANCE_RANGE_100OHM      1
#define FL1586_RESISTANCE_RANGE_1KOHM       2
#define FL1586_RESISTANCE_RANGE_10KOHM      3
#define FL1586_RESISTANCE_RANGE_100KOHM 4
#define FL1586_RESISTANCE_RANGE_1MOHM       5
#define FL1586_RESISTANCE_RANGE_10MOHM      6

/* Defined values for parameter SAMPLERATE of function :
    fl1586_ConfigureChannelMeasurement
*/
#define FL1586_SAMPLERATE_MEDIUM    0
#define FL1586_SAMPLERATE_SLOW      1
#define FL1586_SAMPLERATE_FAST      2

/* Defined values for parameter SCANOPERATION of function :
    fl1586_OperateScanning
*/
#define FL1586_SCANOPERATION_INITIATE   0
#define FL1586_SCANOPERATION_ABORT      1
#define FL1586_SCANOPERATION_PAUSE      2
#define FL1586_SCANOPERATION_CONTINUE   3

/* Defined values for parameter SENSORCHARACTERIZATION of function :
    fl1586_ConfigureChannelMeasurement
*/
#define FL1586_CHARACTERIZATION_K_THERMOCOUPLE              0
#define FL1586_CHARACTERIZATION_T_THERMOCOUPLE              1
#define FL1586_CHARACTERIZATION_R_THERMOCOUPLE              2
#define FL1586_CHARACTERIZATION_S_THERMOCOUPLE              3
#define FL1586_CHARACTERIZATION_J_THERMOCOUPLE              4
#define FL1586_CHARACTERIZATION_N_THERMOCOUPLE              5
#define FL1586_CHARACTERIZATION_E_THERMOCOUPLE              6
#define FL1586_CHARACTERIZATION_B_THERMOCOUPLE              7
#define FL1586_CHARACTERIZATION_C_THERMOCOUPLE              8
#define FL1586_CHARACTERIZATION_D_THERMOCOUPLE              9
#define FL1586_CHARACTERIZATION_G_THERMOCOUPLE              10
#define FL1586_CHARACTERIZATION_L_THERMOCOUPLE              11
#define FL1586_CHARACTERIZATION_M_THERMOCOUPLE              12
#define FL1586_CHARACTERIZATION_U_THERMOCOUPLE              13
#define FL1586_CHARACTERIZATION_W_THERMOCOUPLE              14
#define FL1586_CHARACTERIZATION_POLY_THERMOCOUPLE           15
#define FL1586_CHARACTERIZATION_A385                        16
#define FL1586_CHARACTERIZATION_A392                        17
#define FL1586_CHARACTERIZATION_ABC                         18
#define FL1586_CHARACTERIZATION_SPRT                        19
#define FL1586_CHARACTERIZATION_R2K2                        20
#define FL1586_CHARACTERIZATION_R5K                         21
#define FL1586_CHARACTERIZATION_R10K                        22
#define FL1586_CHARACTERIZATION_RPOLY                       23

/* Defined values for parameter SENSORTYPE of function :
    fl1586_ConfigureChannelMeasurement
    fl1586_ConfigureABCCoefficients
*/
#define FL1586_SENSORTYPE_THERMOCOUPLE          0
#define FL1586_SENSORTYPE_TWO_WIRE_RTD          1
#define FL1586_SENSORTYPE_FOUR_WIRE_RTD         2
#define FL1586_SENSORTYPE_THREE_WIRE_RTD        3
#define FL1586_SENSORTYPE_TWO_WIRE_THERMISTOR   4
#define FL1586_SENSORTYPE_FOUR_WIRE_THERMISTOR  5

/* Defined values for parameter TEMPERATUREUNIT of function :
    fl1586_ConfigureChannelMeasurement
*/
#define FL1586_TEMPERATURE_UNIT_CELSIUS      0
#define FL1586_TEMPERATURE_UNIT_FAHRENHEIT   1

/* Defined values for parameter TIME of function :
    fl1586_ConfigureChangeRate
*/
#define FL1586_RATE_TIME_SECOND 0
#define FL1586_RATE_TIME_MINUTE 1

/* Defined values for parameter TRIGGERSOURCE of function :
    fl1586_ConfigureTrigger
*/
#define FL1586_TRIGGERSOURCE_TIMER      0
#define FL1586_TRIGGERSOURCE_EXTERNAL   1
#define FL1586_TRIGGERSOURCE_ALARM      2
#define FL1586_TRIGGERSOURCE_BUS        3
#define FL1586_TRIGGERSOURCE_MANUAL     4
#define FL1586_TRIGGERSOURCE_AUTO       5

/* Defined values for parameter CHANNELORDER of function :
    fl1586_ConfigureAutomatedTest
*/
#define FL1586_CHANNEL_ORDER_LINEAR         0
#define FL1586_CHANNEL_ORDER_REVERSING      1
#define FL1586_CHANNEL_ORDER_ALTERNATING    2

/* Defined values for parameter CharacterizationType of function :
    fl1586_ConfigureThermocoupleCoefficients
*/
#define FL1586_POLY_THERMOCOUPLE        0
#define FL1586_R_THERMOCOUPLE           1
#define FL1586_S_THERMOCOUPLE           2

/* Defined values for parameter ResultType of function :
    fl1586_ReadStatisticResult
*/
#define FL1586_RESULT_TYPE_ARITHMETIC_MEAN      0
#define FL1586_RESULT_TYPE_SAMPLE_SIZE          1
#define FL1586_RESULT_TYPE_MAXIMUM              2
#define FL1586_RESULT_TYPE_MINIMUM              3  
#define FL1586_RESULT_TYPE_PEAK_TO_PEAK         4
#define FL1586_RESULT_TYPE_RATE                 5 
#define FL1586_RESULT_TYPE_STANDARD_DEVIATION   6 

/*****************************************************************************
 *---------------------- Instrument Driver Function Declarations ------------*
 *****************************************************************************/

ViStatus _VI_FUNC  fl1586_Initialize (ViSession* vi,
                                      ViRsrc resourceName,
                                      ViBoolean IDQuery, 
                                      ViBoolean reset);

ViStatus _VI_FUNC  fl1586_Close (ViSession vi);

 /*--------------------------Action-Status-----------------------------*/
ViStatus _VI_FUNC  fl1586_CalculateTemperature (ViSession vi,
                                                ViReal64 InputValue, 
                                                ViReal64 RJTemperature, 
                                                ViChar ChannelNumber[], 
                                                ViReal64* CalculateResult);

ViStatus _VI_FUNC  fl1586_ClearAlarms (ViSession vi, 
                                       ViChar ChannelList[]);

ViStatus _VI_FUNC  fl1586_ClearStatistics (ViSession vi, 
                                           ViChar ChannelList[]);

ViStatus _VI_FUNC  fl1586_ClearTotalizeCount (ViSession vi);

ViStatus _VI_FUNC  fl1586_DeleteAllReadings (ViSession vi);

ViStatus _VI_FUNC  fl1586_OpenDIOChannel (ViSession vi);

ViStatus _VI_FUNC  fl1586_OperateScanning (ViSession vi,
                                           ViInt32 ScanOperation);

ViStatus _VI_FUNC  fl1586_QueryAlarmCondition (ViSession vi,
                                               ViChar ChannelList[], 
                                               ViInt32 AlarmCondition[]);

ViStatus _VI_FUNC  fl1586_QueryMeasurementFunction (ViSession vi,
                                                    ViChar ChannelList[], 
                                                    ViChar MeasurementFunction[]);

 /*--------------------------Memory-----------------------------*/
ViStatus _VI_FUNC  fl1586_DeleteExportData (ViSession vi,
                                            ViInt32 DataOperation,
                                            ViChar FileName[]);

ViStatus _VI_FUNC  fl1586_DeleteRenameSetupFile (ViSession vi, 
                                                 ViInt32 FileOperation,
                                                 ViInt32 StorageLocation,
                                                 ViChar SetupFileName[]);

ViStatus _VI_FUNC  fl1586_QueryFileStatus (ViSession vi, 
                                           ViInt32 FileType,
                                           ViInt32 StorageLocation, 
                                           ViChar FileName[],    
                                           ViBoolean* Existence);

ViStatus _VI_FUNC  fl1586_QueryMemoryStatus (ViSession vi, 
                                             ViInt32* InternalMemoryDataNumber, 
                                             ViInt32* USBMemoryDataNumber, 
                                             ViInt32* InternalMemoryUsed,  
                                             ViInt32* InternalMemoryUnused);

ViStatus _VI_FUNC  fl1586_QueryMountState (ViSession vi,
                                           ViBoolean* MountState);

ViStatus _VI_FUNC  fl1586_SaveLoadSetupFile (ViSession vi,
                                             ViInt32 FileOperation,
                                             ViInt32 StorageLocation);

ViStatus _VI_FUNC  fl1586_StoreScanData (ViSession vi,
                                         ViInt32 MemoryDevice);

 /*--------------------------Configure-----------------------------*/
ViStatus _VI_FUNC  fl1586_ConfigureABCCoefficients (ViSession vi, 
                                                    ViChar ChannelNumber[], 
                                                    ViInt32 SensorType, 
                                                    ViReal64 CoefficientsA, 
                                                    ViReal64 CoefficientsB, 
                                                    ViReal64 CoefficientsC);

ViStatus _VI_FUNC  fl1586_ConfigureAutomatedTest (ViSession vi,
                                                  ViBoolean EnableInstrumentControl,
                                                  ViInt32 PointNumber,
                                                  ViInt32 ChannelOrder,
                                                  ViChar PrimaryReferenceChannel[],
                                                  ViChar SecondaryReferenceChannel[], 
                                                  ViInt32 SetpointValue,
                                                  ViInt32 ReferenceStabilityLimit,
                                                  ViInt32 ReferenceToleranceLimit,
                                                  ViChar SoakTime[]);

ViStatus _VI_FUNC  fl1586_ConfigureChangeRate (ViSession vi, 
                                               ViChar ChannelList[],
                                               ViInt32 Time);

ViStatus _VI_FUNC  fl1586_ConfigureChannelAlarm (ViSession vi, 
                                                 ViInt32 AlarmFunctionNumber, 
                                                 ViChar ChannelList[],      
                                                 ViReal64 AlarmLimit,   
                                                 ViInt32 AlarmPort,     
                                                 ViInt32 AlarmType,   
                                                 ViChar TriggerInputChannel[]);

ViStatus _VI_FUNC  fl1586_ConfigureChannelMeasurement (ViSession vi, 
                                                       ViChar ChannelList[],
                                                       ViInt32 MeasurementType,
                                                       ViInt32 SampleRate,
                                                       ViInt32 SensorType,
                                                       ViInt32 SensorCharacterization,   
                                                       ViInt32 TemperatureUnit);

ViStatus _VI_FUNC  fl1586_ConfigureChannelScanning (ViSession vi,   
                                                    ViChar ChannelList[], 
                                                    ViBoolean AutoResume);

ViStatus _VI_FUNC  fl1586_ConfigureChannel (ViSession vi, 
                                            ViChar ChannelList[],    
                                            ViBoolean EnableChannel,  
                                            ViReal64 ChannelDelay,    
                                            ViChar ChannelName[]);

ViStatus _VI_FUNC  fl1586_ConfigureDataRecording (ViSession vi, 
                                                  ViBoolean AutoDataRecording, 
                                                  ViBoolean EnableDataRecording,
                                                  ViBoolean EnableDataFileSecurity,
                                                  ViInt32 MemoryDevice);

ViStatus _VI_FUNC  fl1586_ConfigureDCCurrentRange (ViSession vi, 
                                                   ViChar ChannelList[],
                                                   ViInt32 DCCurrentRange);

ViStatus _VI_FUNC  fl1586_ConfigureDCVoltageRange (ViSession vi, 
                                                   ViChar ChannelList[],  
                                                   ViInt32 DCVoltageRange);

ViStatus _VI_FUNC  fl1586_ConfigureDigitalDataByte (ViSession vi, 
                                                    ViInt32 OutputDataByte);

ViStatus _VI_FUNC  fl1586_ConfigureFourResistanceRange (ViSession vi, 
                                                        ViChar ChannelList[],  
                                                        ViInt32 ResistanceRange);

ViStatus _VI_FUNC  fl1586_ConfigureMathChannel (ViSession vi, 
                                                ViChar ChannelList[], 
                                                ViInt32 MathFunction,        
                                                ViChar Coefficients[],     
                                                ViChar ChannelA[],
                                                ViChar ChannelB[],                                             
                                                ViReal64 Exponent, 
                                                ViChar SourceList[]);

ViStatus _VI_FUNC  fl1586_ConfigureMonitorChannel (ViSession vi, 
                                                   ViChar ChannelList[],  
                                                   ViBoolean EnableChannelMonitoring);

ViStatus _VI_FUNC  fl1586_ConfigureMxBScaling (ViSession vi, 
                                               ViChar ChannelList[],     
                                               ViBoolean EnableScaling,     
                                               ViReal64 Gain,                  
                                               ViReal64 Offset,               
                                               ViChar Unit[]);

ViStatus _VI_FUNC  fl1586_ConfigureResistanceAtZero (ViSession vi, 
                                                     ViChar ChannelNumber[],   
                                                     ViInt32 SensorType,       
                                                     ViInt32 CharacterizationType, 
                                                     ViReal64 Resistance);

ViStatus _VI_FUNC  fl1586_ConfigureResistanceCalculation (ViSession vi, 
                                                          ViChar ChannelList[], 
                                                          ViInt32 SensorType,    
                                                          ViBoolean EnableResCalc);

ViStatus _VI_FUNC  fl1586_ConfigureRPOLYCoefficients (ViSession vi, 
                                                      ViChar ChannelNumber[],  
                                                      ViInt32 SensorType,         
                                                      ViReal64 PolyCoefficients1,
                                                      ViReal64 PolyCoefficients2,   
                                                      ViReal64 PolyCoefficients3,    
                                                      ViReal64 PolyCoefficients4);

ViStatus _VI_FUNC  fl1586_ConfigureSPRTCoefficients (ViSession vi, 
                                                     ViChar ChannelNumber[],     
                                                     ViInt32 SensorType,             
                                                     ViReal64 HighPolyCoefficients,   
                                                     ViReal64 LowPolyCoefficients,  
                                                     ViReal64 CharacterizationRes);

ViStatus _VI_FUNC  fl1586_ConfigureThermocoupleCoefficients (ViSession vi, 
                                                             ViChar ChannelNumber[],
                                                             ViInt32 CharacterizationType, 
                                                             ViChar Coefficients[]);

ViStatus _VI_FUNC  fl1586_ConfigureThermocoupleMeasurement (ViSession vi, 
                                                            ViChar ChannelList[], 
                                                            ViBoolean EnableVoltageCalculation, 
                                                            ViBoolean EnableOpenCircuitDetection,   
                                                            ViInt32 ReferenceJunctionType,        
                                                            ViReal64 RJTemperature);

ViStatus _VI_FUNC  fl1586_ConfigureTotalizeCount (ViSession vi, 
                                                  ViBoolean EnableTotalizeCounter, 
                                                  ViBoolean EnableTotalizeDebounce,  
                                                  ViBoolean AutoReset);

ViStatus _VI_FUNC  fl1586_ConfigureTrigger (ViSession vi, 
                                            ViInt32 TriggerSource,   
                                            ViInt32 ScanInterval,    
                                            ViInt32 ScanCount);

ViStatus _VI_FUNC  fl1586_ConfigureTwoResistanceRange (ViSession vi, 
                                                       ViChar ChannelList[],
                                                       ViInt32 ResistanceRange);

 /*--------------------------Data-----------------------------*/
ViStatus _VI_FUNC  fl1586_ReadAlarmOutput (ViSession vi, 
                                           ViInt32* AlarmOutput);

ViStatus _VI_FUNC  fl1586_ReadDataFile (ViSession vi, 
                                        ViInt32 MemoryDevice,
                                        ViChar FileName[],
                                        ViChar FileProperties[],       
                                        ViChar FileConfiguration[],    
                                        ViChar FileData[]);

ViStatus _VI_FUNC  fl1586_ReadDigitalInputChannel (ViSession vi,   
                                                   ViInt32* DigitalInput);

ViStatus _VI_FUNC  fl1586_ReadDigitalTotalizePort (ViSession vi, 
                                                   ViReal64* Result);

ViStatus _VI_FUNC  fl1586_ReadLatestMeasurement (ViSession vi, 
                                                 ViChar MeasurementResult[]);

ViStatus _VI_FUNC  fl1586_ReadMonitorChannel (ViSession vi, 
                                              ViReal64* MonitorData);

ViStatus _VI_FUNC  fl1586_ReadScanSweep (ViSession vi, 
                                         ViInt32 ReadOperation,     
                                         ViChar ChannelNumber[],   
                                         ViChar EarliestScanSweep[], 
                                         ViReal64* LatestScanSweep,      
                                         ViInt32* ScanSweepNumber);

ViStatus _VI_FUNC  fl1586_ReadStatisticResult (ViSession vi, 
                                               ViInt32 ResultType,
                                               ViChar ChannelList[], 
                                               ViChar Result[],
                                               ViChar Time[]);

ViStatus _VI_FUNC  fl1586_ReadTotalizeCount (ViSession vi,       
                                             ViInt32* TotalizeCount);

 /*--------------------------Low Level-----------------------------*/
ViStatus _VI_FUNC  fl1586_ReadMeasurementResult (ViSession vi, 
                                                 ViChar MeasurementResult[]);
ViStatus _VI_FUNC  fl1586_WaitforScanComplete (ViSession vi, 
                                               ViInt32 Timeout);

 /*--------------------------Utility-----------------------------*/
ViStatus _VI_FUNC  fl1586_Reset (ViSession vi);

ViStatus _VI_FUNC  fl1586_SelfTest (ViSession vi, 
                                    ViInt32 *testResult,
                                    ViChar testMessage[256]);

ViStatus _VI_FUNC  fl1586_ErrorQuery (ViSession vi, 
                                      ViInt32 *errorCode,
                                      ViChar errorMessage[256]);

ViStatus _VI_FUNC  fl1586_ErrorMessage (ViSession vi, 
                                        ViStatus statusCode,
                                        ViChar message[256]);

ViStatus _VI_FUNC  fl1586_RevisionQuery (ViSession vi,
                                         ViChar driverRev[256], 
                                         ViChar instrRev[256]);

#if defined(__cplusplus) || defined(__cplusplus__)
}
#endif
#endif

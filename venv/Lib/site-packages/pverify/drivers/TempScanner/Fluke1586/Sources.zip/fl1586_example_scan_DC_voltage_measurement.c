/*****************************************************************************/  
/*  (c) 2014, National Instruments, Corporation.  All Rights Reserved.       */
/*****************************************************************************/

/*****************************************************************************
 *  Fluke 1586 Precision Temperature Scanner Instrument Driver   
 *  VXIPNP, LabWindows/CVI 2013 Instrument Driver
 *  Original Release: 01/06/2014                                               
 *                                                                             
 *  Purpose:  This example shows how to scan dc voltages on some channels.                                          
 *                                                                             
 *            To run this sample program, do the following:                     
 *            1) Create a new project in LabWindows/CVI.                     
 *            2) Add this file to the project.  To add files to the project, 
 *               select the Add Files To Project from the Edit menu of the   
 *               Project window.                                             
 *            3) Add one of the following files to the project:                 
 *               fl1586.fp, fl1586.c, or fl1586.lib.                                 
 *            4) Check that the resource name used in fl1586_Initialize()             
 *               is correct. If simulating, change flag to simulate.         
 *            5) Run the project.                                            
 *                                                                            
 *            VCC or Borland Users:                                             
 *            This example uses CVI's MessagePopup() to display the                          
 *            measured value.  Replace this MessagePopup() function with a  
 *            printf() or similar display function.  Remove the include         
 *            statement: #include <userint.h> from the source code.  Follow  
 *            the directions for CVI users given above.                         
 *****************************************************************************/

#include <ansi_c.h>
#include <stdio.h>
#include <userint.h>
#include "fl1586.h"

/*****************************************************************************
 *------------------------- Useful Macros and Definitions -------------------*
 *****************************************************************************/
#ifndef CheckErr
#define CheckErr(fCall) \
        if (error = (fCall), (error = (error < 0) ? error : VI_SUCCESS)) \
        { \
            goto Error; \
        } \
        else
#else
    #error Macro: CheckErr re-definition.
#endif


#define FL1586_EXAMPLE_RESOURCE_ADDRESS      "COM4"
#define BUFFER_SIZE                          1024 
#define TIME_OUT_VALUE                       10000 

int main()
{
    ViSession     vi;
    ViStatus      error = VI_SUCCESS;

    ViChar        MeasurementResult[BUFFER_SIZE];
    ViChar        szMsg[BUFFER_SIZE] = {0}; 
    ViChar        ChannelList[BUFFER_SIZE] = "102,103,104";
    
    /* Initialize. */
    CheckErr (fl1586_Initialize(FL1586_EXAMPLE_RESOURCE_ADDRESS, 
                                  VI_TRUE, VI_TRUE, &vi));
    
    /* Configure channel measurement to DC voltage. */
    CheckErr (fl1586_ConfigureChannelMeasurement (vi, ChannelList, FL1586_MEASUREMENTTYPE_DC_VOLTAGE,
                                                  FL1586_SAMPLERATE_MEDIUM, 0, 0, 0));
    
    /* Configure channel scanning. */    
    CheckErr (fl1586_ConfigureChannelScanning (vi, ChannelList, VI_TRUE)); 

    /* Initiate Scanning */ 
    CheckErr (fl1586_OperateScanning (vi, FL1586_SCANOPERATION_INITIATE));
    
    /* Wait for scan complete */
    CheckErr (fl1586_WaitforScanComplete (vi, TIME_OUT_VALUE));

    /* Read measurement results. */
    CheckErr (fl1586_ReadLatestMeasurement (vi, MeasurementResult));

    sprintf(szMsg, "DC voltage measurement result of channel %s is : %s\n", ChannelList, MeasurementResult);   
    
    
#if defined(_CVI_)    
    MessagePopup("Message", szMsg); 
#endif
    
Error:
    if (error != VI_SUCCESS)
    {
        ViChar  errMsg[256];
        ViChar * pErrMsg = errMsg;
        ViInt32 errCode;
        
        fl1586_ErrorQuery(vi, &errCode, pErrMsg);    
    #if defined(_CVI_)    
        MessagePopup("Error!", "Error executing the example.");
    #endif 
    }
    
    if(vi)
        fl1586_Close(vi);
    
    return 0;
}

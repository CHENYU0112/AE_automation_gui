/*****************************************************************************/  
/*  (c) 2014, National Instruments, Corporation.  All Rights Reserved.       */
/*****************************************************************************/

/*****************************************************************************
 *  Fluke 1586 Precision Temperature Scanner Instrument Driver   
 *  VXIPNP, LabWindows/CVI 2013 Instrument Driver
 *  Original Release: 01/06/2014                                               
 *                                                                             
 *  Purpose:  This example shows how to scan two-wire resistance with the fast   
 *            sample rate.                                          
 *                                                                             
 *            To run this sample program, do the following:                     
 *            1) Create a new project in LabWindows/CVI.                     
 *            2) Add this file to the project.  To add files to the project, 
 *               select the Add Files To Project from the Edit menu of the   
 *               Project window.                                             
 *            3) Add one of the following files to the project:                      
 *               fl1586.fp, fl1586.c, or fl1586.lib.                                 
 *            4) Check that the resource name used in fl1586_Initialize()             
 *               is correct. If simulating, change flag to simulate.         
 *            5) Run the project.                                            
 *                                                                            
 *            VCC or Borland Users:                                             
 *            This example uses CVI's MessagePopup() to display the             
 *            measured value.  Replace this MessagePopup() function with a  
 *            printf() or similar display function.  Remove the include         
 *            statement: #include <userint.h> from the source code.  Follow  
 *            the directions for CVI users given above.                         
 *****************************************************************************/

#include <ansi_c.h>
#include <stdio.h>
#include <userint.h>
#include "fl1586.h"

/*****************************************************************************
 *------------------------- Useful Macros and Definitions -------------------*
 *****************************************************************************/
#ifndef CheckErr
#define CheckErr(fCall) \
        if (error = (fCall), (error = (error < 0) ? error : VI_SUCCESS)) \
        { \
            goto Error; \
        } \
        else
#else
    #error Macro: CheckErr re-definition.
#endif


#define FL1586_EXAMPLE_RESOURCE_ADDRESS      "COM4"
#define BUFFER_SIZE                          1024 
#define TIME_OUT_VALUE                       10000

int main()
{
    ViSession     vi;
    ViStatus      error = VI_SUCCESS;

    ViChar        MeasurementResult[BUFFER_SIZE];
    ViChar        szMsg[BUFFER_SIZE] = {0}; 
    ViChar        ChannelNumber[BUFFER_SIZE] = "101";
    ViReal64      LatestScanSweep = 0;      
    ViInt32       ScanSweepNumber = 0;
    
    /* Initialize. */
    CheckErr (fl1586_Initialize(FL1586_EXAMPLE_RESOURCE_ADDRESS, VI_TRUE, VI_TRUE, &vi));
    
    /* Configure channel measurement to DC current. */
    CheckErr (fl1586_ConfigureChannelMeasurement (vi, ChannelNumber, FL1586_MEASUREMENTTYPE_TWOWIRE_RESISTANCE,
                                                  FL1586_SAMPLERATE_FAST, 0, 0, 0));

    /* Configure trigger. */ 
    CheckErr (fl1586_ConfigureTrigger (vi, FL1586_TRIGGERSOURCE_TIMER, 0, 500));

    /* Initiate Scanning */ 
    CheckErr (fl1586_OperateScanning (vi, FL1586_SCANOPERATION_INITIATE));
    
    /* Wait for scan complete */
    CheckErr (fl1586_WaitforScanComplete (vi, TIME_OUT_VALUE));

    /* Read measurement results. */
    CheckErr (fl1586_ReadScanSweep (vi, FL1586_READ_DELETE_EARLIEST_SCAN_SWEEP, ChannelNumber, 
                                    MeasurementResult, &LatestScanSweep, &ScanSweepNumber));

    sprintf(szMsg, "The earlist resistance measurement result of channel %s is : %s\n", ChannelNumber, MeasurementResult);   
    
    
#if defined(_CVI_)    
    MessagePopup("Message", szMsg); 
#endif
    
Error:
    if (error != VI_SUCCESS)
    {
        ViChar  errMsg[256];
        ViChar * pErrMsg = errMsg;
        ViInt32 errCode;
        
        fl1586_ErrorQuery(vi, &errCode, pErrMsg);    
    #if defined(_CVI_)    
        MessagePopup("Error!", errMsg);
    #endif 
    }
    
    if(vi)
        fl1586_Close(vi);
    
    return 0;
}

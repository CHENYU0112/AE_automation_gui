/*************************************************************************************** 
 * (c) 2014, National Instruments. All Rights Reserved.                                * 
 ***************************************************************************************/
 
/***************************************************************************************
 *  Fluke 1586 Precision Temperature Scanner Instrument Driver   
 *  VXIPNP, LabWindows/CVI 2013 Instrument Driver
 *
 *  Original Release: 01/06/2014                                  
 *  By: Zhifan Su, National Instruments, Shanghai China
 *      PH: 021-50509810
 *      Email: zhifan.su@ni.com
 *                                                                           
 *  Modification History:                                                    
 *                                                                           
 *      01/2/2014  - Instrument Driver Created.
 ***************************************************************************************/

#include <visa.h>
#include <ansi_c.h>
#include <utility.h>
#include "fl1586.h"


/*= DEFINES ===========================================================================*/
#define FL1586_REVISION               "Rev 1.0, 01/2014, CVI 2013"  /* Instrument driver revision */
#define FL1586_BUFFER_SIZE            512L                          /* File I/O buffer size       */
#define FL1586_LARGE_BUFFER_SIZE      8000L                         /* File I/O large buffer size */
#define FL1586_IO_TIMEOUT_VALUE       10000L                        /* I/O timeout value */

/*= Macros ============================================================================*/ 
        /*- Error Checking ------------------------------------------------------------*/
#ifndef CheckErr
#define CheckErr(fCall) \
        if (status = (fCall), (status = (status < 0) ? status : VI_SUCCESS)) \
        { \
            goto Error; \
        } \
        else
#endif

        /*- Invalid Param Reporting ---------------------------------------------------*/
#ifndef CheckParam
#define CheckParam(fCall, errorCode) \
        if (fCall) \
        { \
            status = (errorCode); \
            goto Error; \
        } \
        else
#endif

        /*- Boolean value validation --------------------------------------------------*/
#ifndef IsInvalidBooleanVal
    #define IsInvalidBooleanVal(bValue) (bValue != VI_TRUE && bValue != VI_FALSE)
#else
    #error Validation Macro: IsInvalidBooleanVal re-definition.
#endif

        /*- Numeric value validation --------------------------------------------------*/
#ifndef IsInvalidNumericVal
    #define IsInvalidNumericVal(val, min, max) (val < min || val > max)
#else
    #error Validation Macro: IsInvalidNumericVal re-definition.
#endif

        /*- Pointer validation --------------------------------------------------------*/
#ifndef IsInvalidPtr
    #define IsInvalidPtr(ptr) (ptr == NULL)
#else
    #error Validation Macro: IsInvalidPtr re-definition.
#endif

        /*- Data block validation -----------------------------------------------------*/
#ifndef IsInvalidData
    #define IsInvalidData(data, len) (strlen(data) == len)
#else
    #error Validation Macro: IsInvalidData re-definition. 
#endif

/*****************************************************************************
 *------------------- Instrument dependent command arrays -------------------*
 *****************************************************************************/

static ViConstString  gChannelOrderArr[]     = {"LIN", "REV", "ALT"};
static ViConstString  gTimeArr[]             = {"SEC", "MIN"};
static ViConstString  gAlarmPortArr[]        = {"NONE", "1", "2", "3", "4", "5", "6"};
static ViConstString  gAlarmTypeArr[]        = {"OFF", "HIGH", "LOW"};
static ViConstString  gSampleRateArr[]       = {"MED", "SLOW", "FAST"};
static ViConstString  gSensorTypeArr[]       = {"TC", "RTD", "FRTD", "TRTD", "THER", "FTH"};
static ViConstString  gSensorCharArr[]       = {"K", "T", "R", "S", "J", "N", "E","B",  
                                               "C", "D", "G", "L", "M", "U", "W", "POLY",
                                               "A385", "A392", "ABC", "SPRT", "R2K2", "R5K", 
                                               "R10K", "RPOL"};
static ViConstString  gUnitArr[]             = {"C", "F"};
static ViConstString  gMemoryDeviceArr[]     = {"MEM", "MMEM"};
static ViConstString  gCurrentRangeArr[]     = {"AUTO", "1e-4", "1e-3", "1e-2", "1e-1"};
static ViConstString  gVoltageRangeArr[]     = {"AUTO", "0.1", "1", "10", "50"};
static ViConstString  gFourResRangeArr[]     = {"AUTO", "1e2", "1e3", "1e4", "1e5", 
                                               "1e6", "1e7"};
static ViConstString  gTwoResRangeArr[]      = {"AUTO", "1e2", "1e3", "1e4", "1e5", 
                                               "1e6", "1e7"};
static ViConstString  gMathFunctionArr[]     = {"POLY", "SRO", "POW", "EXP", "LOG",
                                               "ABS", "REC", "ADD", "SUB", "MULT",
                                               "DIV", "AVER", "MAX", "MIN", "SUM"}; 
static ViConstString  gRJTypeArr[]           = {"INT", "FIX", "EXT"};    
static ViConstString  gTriggerSourceArr[]    = {"TIM", "EXT", "ALAR", "BUS", "MAN", "AUTO"};

/*****************************************************************************
 *--------------- Instrument dependent status/range structure ---------------*
 *****************************************************************************/

    /*- fl1586_StringValPair is used in fl1586_ErrorMessage function ----*/
typedef struct fl1586_StringValPair
{
    ViStatus stringVal;
    ViString stringName;
} fl1586_tStringValPair;


/***************************************************************************************/
/*= INSTRUMENT SPECIFIC UTILITY ROUTINE DECLARATIONS (Non-Exportable Functions) =======*/
/***************************************************************************************/
static ViStatus fl1586_DefaultInstrSetup (ViSession vi);  
static ViStatus fl1586_CheckStatus (ViSession vi);        
static ViInt32 StringToViInt32Array(ViChar  dataStr[],
                                   ViInt32 resultData[],
                                   ViChar  delimiter);   
static ViStatus fl1586_QueryData(ViSession vi, ViChar Result[], ViString writeFmt, ...);
/*****************************************************************************
 *------------- User-Callable Functions (Exportable Functions) --------------*
 *****************************************************************************/

/*****************************************************************************
 *Function: fl1586_Initialize
 *Purpose:  Establishes communication with the instrument and optionally performs an
 *          instrument identification query and/or an instrument reset.  It also places
 *          the instrument in a default state needed for other instrument driver operations. 
 *          Therefore, call this function before calling other instrument driver functions
 *          for this instrument.  Generally, you need to call the fl1586_Initialize
 *          function only once at the beginning of an application.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_Initialize (ViSession* vi,
                                      ViRsrc resourceName,
                                      ViBoolean IDQuery, 
                                      ViBoolean reset)
{
    /* Define local variables. */
    ViStatus    status = VI_SUCCESS;
    ViSession   rmSession = 0;
    ViChar      readBuf[FL1586_BUFFER_SIZE] = "";
    ViUInt16    interfaceType = 0;

    /* Parameter validations. */
    CheckParam (IsInvalidPtr(resourceName), VI_ERROR_PARAMETER1);
    CheckParam (IsInvalidBooleanVal(IDQuery), VI_ERROR_PARAMETER2);
    CheckParam (IsInvalidBooleanVal(reset), VI_ERROR_PARAMETER3);
    CheckParam (IsInvalidPtr(vi), VI_ERROR_PARAMETER4);

    /* Open instrument session. */
    CheckErr (viOpenDefaultRM(&rmSession));
    if ((status = viOpen(rmSession, resourceName, VI_NULL, VI_NULL, vi)) < 0)
    {
        viClose (rmSession);
        return status;
    }

    /* Configure asynchronous serial interface if needed. */
    CheckErr (viGetAttribute(*vi, VI_ATTR_INTF_TYPE, &interfaceType));
    switch(interfaceType)
    {
    case VI_INTF_TCPIP:
        CheckErr (viSetAttribute(*vi, VI_ATTR_TERMCHAR, '\n'));        /* Line-feed */
        CheckErr (viSetAttribute(*vi, VI_ATTR_TERMCHAR_EN, VI_TRUE));
        break;
    default:
        break;
    }

    /* Configure VISA Formatted I/O. */

    CheckErr (viSetAttribute(*vi, VI_ATTR_TMO_VALUE, FL1586_IO_TIMEOUT_VALUE));
    CheckErr (viSetBuf(*vi, VI_READ_BUF|VI_WRITE_BUF, FL1586_LARGE_BUFFER_SIZE));
    CheckErr (viSetAttribute(*vi, VI_ATTR_WR_BUF_OPER_MODE, VI_FLUSH_ON_ACCESS));
    CheckErr (viSetAttribute(*vi, VI_ATTR_RD_BUF_OPER_MODE,VI_FLUSH_ON_ACCESS));

    /* Identification query. */
    if (IDQuery)
    {
        ViChar *queryResponse1 = "FLUKE,1586A,";

        CheckErr (viQueryf(*vi, "*IDN?\n", "%256[^\r\n]", readBuf));

        if (!strstr(readBuf, queryResponse1))
        {
            CheckErr (VI_ERROR_FAIL_ID_QUERY);
        }
    }

    /* Reset instrument. */
    if(reset)
    {
        CheckErr (fl1586_Reset(*vi));
    }
    else
    {
        CheckErr (fl1586_DefaultInstrSetup(*vi));
    }

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_Close
 *Purpose:  Performs an instrument error query before terminating the
 *          software connection to the instrument.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_Close (ViSession vi)
{
    ViSession    rmSession;
    ViStatus     status = VI_SUCCESS;

    CheckErr (viGetAttribute(vi, VI_ATTR_RM_SESSION, &rmSession));

    CheckErr (viClose(vi));
    CheckErr (viClose(rmSession));

Error:
    return status;
}

/*****************************************************************************
 *Function: fl1586_CalculateTemperature
 *Purpose:  Calculates temperature for a given set of input values using the 
 *          configuration of the given channel.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_CalculateTemperature (ViSession vi,
                                                ViReal64 InputValue, 
                                                ViReal64 RJTemperature, 
                                                ViChar ChannelNumber[], 
                                                ViReal64* CalculateResult)
{
    ViStatus    status = VI_SUCCESS;

    /* Parameter validations. */
    CheckParam (IsInvalidNumericVal(InputValue, -1e18, 1e18), VI_ERROR_PARAMETER2); 
    CheckParam (IsInvalidNumericVal(RJTemperature, -1e18, 1e18), VI_ERROR_PARAMETER3);
    CheckParam (IsInvalidPtr(ChannelNumber), VI_ERROR_PARAMETER4);
    CheckParam (IsInvalidPtr(CalculateResult), VI_ERROR_PARAMETER5); 
    
    /* Return temperature result. */
    CheckErr (viQueryf(vi, ":TEMP:CALC? %lf,%lf,(@%s)\n", "%lf", InputValue, RJTemperature, ChannelNumber, CalculateResult));

    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_ClearAlarms
 *Purpose:  Clear the alarms for the given channels.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_ClearAlarms (ViSession vi, 
                                       ViChar ChannelList[]) 
{
    ViStatus    status = VI_SUCCESS;

    /* Parameter validations. */
    CheckParam (IsInvalidPtr(ChannelList), VI_ERROR_PARAMETER2);

    if (!strcmp(ChannelList, "ALL"))     /* Clear all alarms. */
        CheckErr (viPrintf(vi, "CALC:LIM:CLE:ALL\n"));
    else                          /* Clear specified alarms. */
        CheckErr (viPrintf(vi, "CALC:LIM:CLE (@%s)\n", ChannelList));

    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_ClearStatistics
 *Purpose:  Clear the statistics for the given channels.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_ClearStatistics (ViSession vi, 
                                           ViChar ChannelList[]) 
{
    ViStatus    status = VI_SUCCESS;

    /* Parameter validations. */
    CheckParam (IsInvalidPtr(ChannelList), VI_ERROR_PARAMETER2);

    if (!strcmp(ChannelList, "ALL"))     /* Clear all statistics. */
        CheckErr (viPrintf(vi, "CALC:AVER:CLE:ALL\n"));
    else                                 /* Clear specified statistics. */
        CheckErr (viPrintf(vi, "CALC:AVER:CLE (@%s)\n", ChannelList));

    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_ClearTotalizeCount
 *Purpose:  Clears the totalize count.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_ClearTotalizeCount (ViSession vi)
{
    ViStatus    status = VI_SUCCESS;

    CheckErr (viPrintf(vi, ":TOT:CLE\n"));

    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_DeleteAllReadings
 *Purpose:  Deletes all readings in scan memory.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_DeleteAllReadings (ViSession vi)
{
    ViStatus    status = VI_SUCCESS;

    CheckErr (viPrintf(vi, "DATA:CLE\n"));

    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_OpenDIOChannel
 *Purpose:  Open DIO channel for scan.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_OpenDIOChannel (ViSession vi)
{
    ViStatus    status = VI_SUCCESS;

    CheckErr (viPrintf(vi, "CONF:DIG:DATA:BYTE\n"));

    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_OperateScanning
 *Purpose:  Operates a scanning in progress.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_OperateScanning (ViSession vi,
                                           ViInt32 ScanOperation)
{
    ViStatus    status = VI_SUCCESS;

    /* Parameter validations. */
    CheckParam (IsInvalidNumericVal(ScanOperation, 0, 3), VI_ERROR_PARAMETER2); 

    switch( ScanOperation )
    {
        case FL1586_SCANOPERATION_INITIATE: /* Initiate scanning */
            CheckErr (viPrintf(vi, "INIT\n"));
            break;
        case FL1586_SCANOPERATION_ABORT:    /* Abort scanning */
            CheckErr (viPrintf(vi, "ABOR\n"));
            break;
        case FL1586_SCANOPERATION_PAUSE:    /* Pause scanning */
            CheckErr (viPrintf(vi, "TRIG:ENAB OFF\n"));
            break;
        case FL1586_SCANOPERATION_CONTINUE: /* Continue scanning */
            CheckErr (viPrintf(vi, "TRIG:ENAB ON\n"));
            break;            
        default:
            break;
    }
    
    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_QueryAlarmCondition
 *Purpose:  Queries the alarm condition of the given channels.
 *****************************************************************************/
 ViStatus _VI_FUNC  fl1586_QueryAlarmCondition (ViSession vi,
                                               ViChar ChannelList[], 
                                               ViInt32 AlarmCondition[])
 {
    ViStatus    status = VI_SUCCESS;
    ViChar      AlarmConditionStr[FL1586_BUFFER_SIZE];
    
    /* Parameter validations. */
    CheckParam (IsInvalidPtr(ChannelList), VI_ERROR_PARAMETER2);
    CheckParam (IsInvalidPtr(AlarmCondition), VI_ERROR_PARAMETER3); 
    
    /* Return temperature result. */
    CheckErr (viQueryf(vi, "CALC:LIM:FAIL? (@%s)\n", "%s", ChannelList, AlarmConditionStr));
    StringToViInt32Array(AlarmConditionStr, AlarmCondition, ','); 
    
    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
 }


/*****************************************************************************
 *Function: fl1586_QueryMeasurementFunction
 *Purpose:  Queries the measurement function of specified channels.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_QueryMeasurementFunction (ViSession vi,
                                                    ViChar ChannelList[], 
                                                    ViChar MeasurementFunction[])
 {
    ViStatus    status = VI_SUCCESS;
    
    /* Parameter validations. */
    CheckParam (IsInvalidPtr(ChannelList), VI_ERROR_PARAMETER2);
    CheckParam (IsInvalidPtr(MeasurementFunction), VI_ERROR_PARAMETER3); 
    
    /* Return temperature result. */
    CheckErr (viQueryf(vi, "CONF? (@%s)\n", "%s", ChannelList, MeasurementFunction));
    
    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
 }


/*****************************************************************************
 *Function: fl1586_DeleteExportData
 *Purpose:  Deletes data file in internal memory or copy a data file stored in 
 *          internal memory to USB memory.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_DeleteExportData (ViSession vi,
                                            ViInt32 DataOperation,
                                            ViChar FileName[])
{
    ViStatus    status = VI_SUCCESS;

    /* Parameter validations. */
    CheckParam (IsInvalidNumericVal(DataOperation, 0, 2), VI_ERROR_PARAMETER2);
    CheckParam (IsInvalidPtr(FileName), VI_ERROR_PARAMETER3);

    switch( DataOperation )
    {
             /* Erase all scan data files in internal memory. */  
        case FL1586_DELETE_ALL_FILES: 
            CheckErr (viPrintf(vi, "MEM:LOG:CLE\n"));
            break;
             /* Delete a data file in internal memory. */
        case FL1586_DELETE_A_FILE:   
            CheckErr (viPrintf(vi, "MEM:LOG:DEL \"%s\"\n", FileName));
            break;
            /* Copy a data file stored in internal memory to USB memory. */ 
        case FL1586_COPY_TO_USB_MEMORY:    
            CheckErr (viPrintf(vi, "MEM:LOG:EXP \"%s\"\n", FileName));
            break;
        default:
            break;
    }
    
    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_DeleteRenameSetupFile
 *Purpose:  Deletes or renames the setup file in the memory.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_DeleteRenameSetupFile (ViSession vi, 
                                                 ViInt32 FileOperation,
                                                 ViInt32 StorageLocation,
                                                 ViChar SetupFileName[])
{
    ViStatus    status = VI_SUCCESS;

    /* Parameter validations. */
    CheckParam (IsInvalidNumericVal(FileOperation, 0, 2), VI_ERROR_PARAMETER2);
    CheckParam (IsInvalidNumericVal(StorageLocation, 1, 99), VI_ERROR_PARAMETER3);     
    CheckParam (IsInvalidPtr(SetupFileName), VI_ERROR_PARAMETER4);

    switch( FileOperation )
    {
             /* Delete all setup files. */  
        case FL1586_DELETE_ALL_SETUP_FILES: 
            CheckErr (viPrintf(vi, "MEM:STAT:CLE\n"));
            break;
             /* Delete a setup file. */
        case FL1586_DELETE_A_SETUP_FILE:   
            CheckErr (viPrintf(vi, "MEM:STAT:DEL %d\n", StorageLocation));
            break;
            /* Rename a setup file. */ 
        case FL1586_RENAME_A_SETUP_FILE:    
            CheckErr (viPrintf(vi, "MEM:STAT:DEF \"%s\",%d\n", SetupFileName, StorageLocation));
            break;
        default:
            break;
    }
    
    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_QueryFileStatus
 *Purpose:  Queries the status of the specified file.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_QueryFileStatus (ViSession vi, 
                                           ViInt32 FileType,
                                           ViInt32 StorageLocation, 
                                           ViChar FileName[],    
                                           ViBoolean* Existence) 
{
    ViStatus    status = VI_SUCCESS;
    ViBoolean   ExistenceTemp = VI_FALSE;

    /* Parameter validations. */
    CheckParam (IsInvalidNumericVal(FileType, 0, 2), VI_ERROR_PARAMETER2);
    CheckParam (IsInvalidNumericVal(StorageLocation, 1, 99), VI_ERROR_PARAMETER3);     
    CheckParam (IsInvalidPtr(FileName), VI_ERROR_PARAMETER4);
    CheckParam (IsInvalidPtr(Existence), VI_ERROR_PARAMETER5);    

    switch( FileType )
    {
             /* Setup file */  
        case FL1586_SETUP_FILE: 
            CheckErr (viQueryf(vi, "MEM:STAT:VAL? %d\n", "%d", StorageLocation, &ExistenceTemp));
            if (ExistenceTemp)
                CheckErr (viQueryf(vi, "MEM:STAT:DEF:NAME? %d\n", "%s", StorageLocation, FileName));
            break;
             /* Internal memory data file */
        case FL1586_INTERNAL_MEMORY_DATA_FILE:   
            CheckErr (viQueryf(vi, "MEM:LOG:NAME? %d\n", "%s", StorageLocation, FileName));
            break;
            /* USB memory data file */ 
        case FL1586_USB_MEMORY_DATA_FILE:    
            CheckErr (viQueryf(vi, "MMEM:LOG:NAME? %d\n", "%s", StorageLocation, FileName)); 
            break;
        default:
            break;
    }
    
    *Existence = ExistenceTemp;
    
    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_QueryMemoryStatus
 *Purpose:  Queries the status of the internal memory and USB memory.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_QueryMemoryStatus (ViSession vi, 
                                             ViInt32* InternalMemoryDataNumber, 
                                             ViInt32* USBMemoryDataNumber, 
                                             ViInt32* InternalMemoryUsed,  
                                             ViInt32* InternalMemoryUnused)
{
    ViStatus    status = VI_SUCCESS;

    /* Parameter validations. */
    CheckParam (IsInvalidPtr(InternalMemoryDataNumber), VI_ERROR_PARAMETER2);
    CheckParam (IsInvalidPtr(USBMemoryDataNumber), VI_ERROR_PARAMETER3);    
    CheckParam (IsInvalidPtr(InternalMemoryUsed), VI_ERROR_PARAMETER4);
    CheckParam (IsInvalidPtr(InternalMemoryUnused), VI_ERROR_PARAMETER5);    
             
    /* Internal memory data number */  
    CheckErr (viQueryf(vi, "MEM:LOG:NFIL?\n", "%d", InternalMemoryDataNumber)); 
    /* Internal memory used and unused */  
    CheckErr (viQueryf(vi, "MEM:LOG:FREE?\n", "%ld,%ld", InternalMemoryUnused, InternalMemoryUsed));
    /* USB memory data number */  
    CheckErr (viQueryf(vi, "MMEM:LOG:NFIL?\n", "%d", USBMemoryDataNumber)); 

    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_QueryMountState
 *Purpose:  Queries the mount state of the USB memory device.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_QueryMountState (ViSession vi,
                                           ViBoolean* MountState)
{
    ViStatus    status = VI_SUCCESS;

    /* Parameter validations. */
    CheckParam (IsInvalidPtr(MountState), VI_ERROR_PARAMETER2);
             
    /* Internal memory data number */  
    CheckErr (viQueryf(vi, "MMEM:MOUN?\n", "%d", MountState)); 

    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_SaveLoadSetupFile
 *Purpose:  Save or load a setup file.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_SaveLoadSetupFile (ViSession vi,
                                             ViInt32 FileOperation,
                                             ViInt32 StorageLocation)
{
    ViStatus    status = VI_SUCCESS;

    /* Parameter validations. */
    CheckParam (IsInvalidNumericVal(FileOperation, 0, 1), VI_ERROR_PARAMETER2);
    CheckParam (IsInvalidNumericVal(StorageLocation, 1, 99), VI_ERROR_PARAMETER3);     

    switch( FileOperation )
    {
             /* Save setup file. */  
        case FL1586_SAVE_SETUP_FILE: 
            CheckErr (viPrintf(vi, "*SAV %d\n", StorageLocation));
            break;
             /* Load setup file. */
        case FL1586_LOAD_SETUP_FILE:   
            CheckErr (viPrintf(vi, "*RCL %d\n", StorageLocation)); 
            break;
        default:
            break;
    }
    
    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_StoreScanData
 *Purpose:  Stores the latest scan data to memory.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_StoreScanData (ViSession vi,
                                         ViInt32 MemoryDevice)
{
    ViStatus    status = VI_SUCCESS;

    /* Parameter validations. */
    CheckParam (IsInvalidNumericVal(MemoryDevice, 0, 1), VI_ERROR_PARAMETER2);

    switch( MemoryDevice )
    {
             /* Store data file to internal flash memory. */  
        case FL1586_INTERNAL_FLASH_MEMORY: 
            CheckErr (viPrintf(vi, "MEM:LOG:STOR\n"));
            break;
             /* Store data file to external USB memory. */
        case FL1586_EXTERNAL_USB_MEMORY:   
            CheckErr (viPrintf(vi, "MMEM:LOG:STOR\n")); 
            break;
        default:
            break;
    }
    
    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_ConfigureABCCoefficients
 *Purpose:  Configures the polynomial characterization coefficients for 
 *          characterization type ABC.
 *
 *          Note:
 *          The channel function must already be set to corresponding
 *          temperature measurement through "fl1586_ConfigureChannelMeasurement".
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_ConfigureABCCoefficients (ViSession vi, 
                                                    ViChar ChannelNumber[], 
                                                    ViInt32 SensorType, 
                                                    ViReal64 CoefficientsA, 
                                                    ViReal64 CoefficientsB, 
                                                    ViReal64 CoefficientsC) 
{
    ViStatus    status = VI_SUCCESS;

    /* Parameter validations. */
    CheckParam (IsInvalidPtr(ChannelNumber), VI_ERROR_PARAMETER2); 
    CheckParam (IsInvalidNumericVal(SensorType, 1, 3), VI_ERROR_PARAMETER3);
    CheckParam (IsInvalidNumericVal(CoefficientsA, 1E-3, 9.9E-3), VI_ERROR_PARAMETER4);
    CheckParam (IsInvalidNumericVal(CoefficientsB, -1E-4, 1E-4), VI_ERROR_PARAMETER5);
    CheckParam (IsInvalidNumericVal(CoefficientsC, -1E-9, 1E-9), VI_ERROR_PARAMETER6);
    
    switch( SensorType )
    {
             /* Two-wire PRT/RTD. */  
        case FL1586_SENSORTYPE_TWO_WIRE_RTD: 
            CheckErr (viPrintf(vi, "TEMP:RTD:ABC:COEF %lf,%lf,%lf,(@%s)\n", CoefficientsA, 
                                   CoefficientsB, CoefficientsC, ChannelNumber));
            break;
             /* Four-wire PRT/RTD. */  
        case FL1586_SENSORTYPE_FOUR_WIRE_RTD: 
            CheckErr (viPrintf(vi, "TEMP:FRTD:ABC:COEF %lf,%lf,%lf,(@%s)\n", CoefficientsA, 
                                   CoefficientsB, CoefficientsC, ChannelNumber));
            break;
             /* Three-wire PRT/RTD. */  
        case FL1586_SENSORTYPE_THREE_WIRE_RTD: 
            CheckErr (viPrintf(vi, "TEMP:TRTD:ABC:COEF %lf,%lf,%lf,(@%s)\n", CoefficientsA, 
                                   CoefficientsB, CoefficientsC, ChannelNumber));
            break;
        default:
            break;
    }
    
    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_ConfigureAutomatedTest
 *Purpose:  Configures the automated test.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_ConfigureAutomatedTest (ViSession vi,
                                                  ViBoolean EnableInstrumentControl,
                                                  ViInt32 PointNumber,
                                                  ViInt32 ChannelOrder,
                                                  ViChar PrimaryReferenceChannel[],
                                                  ViChar SecondaryReferenceChannel[], 
                                                  ViInt32 SetpointValue,
                                                  ViInt32 ReferenceStabilityLimit,
                                                  ViInt32 ReferenceToleranceLimit,
                                                  ViChar SoakTime[])
{
    ViStatus    status = VI_SUCCESS;
    ViInt32     orderCnt = sizeof(gChannelOrderArr)/sizeof(*gChannelOrderArr);  

    /* Parameter validations. */
    CheckParam (IsInvalidBooleanVal(EnableInstrumentControl), VI_ERROR_PARAMETER2); 
    CheckParam (IsInvalidNumericVal(PointNumber, 1, 20), VI_ERROR_PARAMETER3);
    CheckParam (IsInvalidNumericVal(ChannelOrder, 0, orderCnt-1), VI_ERROR_PARAMETER4);
    CheckParam (IsInvalidPtr(PrimaryReferenceChannel), VI_ERROR_PARAMETER5);
    CheckParam (IsInvalidPtr(SecondaryReferenceChannel), VI_ERROR_PARAMETER6);
    CheckParam (IsInvalidNumericVal(SetpointValue, 0, 1E+18), VI_ERROR_PARAMETER7);
    CheckParam (IsInvalidNumericVal(ReferenceStabilityLimit, 0, 1E+18), VI_ERROR_PARAMETER8);    
    CheckParam (IsInvalidNumericVal(ReferenceToleranceLimit, 0, 1E+18), VI_ERROR_INSTR_PARAMETER9);    
    CheckParam (IsInvalidPtr(SoakTime), VI_ERROR_INSTR_PARAMETER10);     
    
    /* Configures the automated test */
    CheckErr (viPrintf(vi, "TRIG:AUTO:CONT %s\n", EnableInstrumentControl ? "ON": "OFF"));  
    CheckErr (viPrintf(vi, "TRIG:AUTO:POIN %d\n", PointNumber));    
    CheckErr (viPrintf(vi, "TRIG:AUTO:ORD %s\n", gChannelOrderArr[ChannelOrder]));  
    CheckErr (viPrintf(vi, "TRIG:AUTO:SPO %ld,%d\n", SetpointValue, PointNumber));    
    CheckErr (viPrintf(vi, "TRIG:AUTO:STAB %ld,%d\n", ReferenceStabilityLimit, PointNumber));      
    CheckErr (viPrintf(vi, "TRIG:AUTO:TOL %ld,%d\n", ReferenceToleranceLimit, PointNumber)); 
    CheckErr (viPrintf(vi, "TRIG:AUTO:DWEL %s,%d\n", SoakTime, PointNumber));     
    CheckErr (viPrintf(vi, "TRIG:AUTO:REF (@%s)\n", PrimaryReferenceChannel)); 
    CheckErr (viPrintf(vi, "TRIG:AUTO:SREF (@%s)\n", SecondaryReferenceChannel));    
   
    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_ConfigureChangeRate
 *Purpose:  Sets the rate of change for the given channels.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_ConfigureChangeRate (ViSession vi, 
                                               ViChar ChannelList[],
                                               ViInt32 Time) 
{
    ViStatus    status = VI_SUCCESS;
    ViInt32     timeCnt = sizeof(gTimeArr)/sizeof(*gTimeArr);  

    /* Parameter validations. */
    CheckParam (IsInvalidPtr(ChannelList), VI_ERROR_PARAMETER2);  
    CheckParam (IsInvalidNumericVal(Time, 0, timeCnt-1), VI_ERROR_PARAMETER3);
    
    /* Configures the rate of change */
    CheckErr (viPrintf(vi, "CALC:AVER:RATE:BASE %s,(@%s)\n", gTimeArr[Time], ChannelList));  
   
    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_ConfigureChannelAlarm
 *Purpose:  Sets the alarm functions of the given channels.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_ConfigureChannelAlarm (ViSession vi, 
                                                 ViInt32 AlarmFunctionNumber, 
                                                 ViChar ChannelList[],      
                                                 ViReal64 AlarmLimit,   
                                                 ViInt32 AlarmPort,     
                                                 ViInt32 AlarmType,   
                                                 ViChar TriggerInputChannel[])
{
    ViStatus    status = VI_SUCCESS;
    ViInt32     alarmPortCnt = sizeof(gAlarmPortArr)/sizeof(*gAlarmPortArr); 
    ViInt32     alarmTypeCnt = sizeof(gAlarmTypeArr)/sizeof(*gAlarmTypeArr); 
    
    /* Parameter validations. */
    CheckParam (IsInvalidNumericVal(AlarmFunctionNumber, 1, 2), VI_ERROR_PARAMETER2); 
    CheckParam (IsInvalidPtr(ChannelList), VI_ERROR_PARAMETER3);
    CheckParam (IsInvalidNumericVal(AlarmLimit, -1E+18, 1E+18), VI_ERROR_PARAMETER4);
    CheckParam (IsInvalidNumericVal(AlarmPort, 0, alarmPortCnt-1), VI_ERROR_PARAMETER5);
    CheckParam (IsInvalidNumericVal(AlarmType, 0, alarmTypeCnt-1), VI_ERROR_PARAMETER6);
    CheckParam (IsInvalidPtr(TriggerInputChannel), VI_ERROR_PARAMETER7);
    
    /* Configures the alarm functions */
    CheckErr (viPrintf(vi, "CALC:LIM%d %lf,(@%s)\n", AlarmFunctionNumber, AlarmLimit, ChannelList));  
    CheckErr (viPrintf(vi, "CALC:LIM%d:FEED %s,(@%s)\n", AlarmFunctionNumber, 
                           gAlarmPortArr[AlarmPort], ChannelList));
    CheckErr (viPrintf(vi, "CALC:LIM%d:STAT %s,(@%s)\n", AlarmFunctionNumber, 
                           gAlarmTypeArr[AlarmType], ChannelList));  
    CheckErr (viPrintf(vi, "TRIG:ALAR:CHAN (@%s)\n", TriggerInputChannel));     

    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_ConfigureChannelMeasurement
 *Purpose:  Configures the measurement of the given channels.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_ConfigureChannelMeasurement (ViSession vi, 
                                                       ViChar ChannelList[],
                                                       ViInt32 MeasurementType,
                                                       ViInt32 SampleRate,
                                                       ViInt32 SensorType,
                                                       ViInt32 SensorCharacterization,   
                                                       ViInt32 TemperatureUnit)  
{
    ViStatus    status = VI_SUCCESS;
    ViInt32     sampleRateCnt = sizeof(gSampleRateArr)/sizeof(*gSampleRateArr); 
    ViInt32     sensorTypeCnt = sizeof(gSensorTypeArr)/sizeof(*gSensorTypeArr);     
    ViInt32     sensorCharCnt = sizeof(gSensorCharArr)/sizeof(*gSensorCharArr);     
    ViInt32     unitCnt = sizeof(gUnitArr)/sizeof(*gUnitArr);     
    
    /* Parameter validations. */
    CheckParam (IsInvalidPtr(ChannelList), VI_ERROR_PARAMETER2);
    CheckParam (IsInvalidNumericVal(MeasurementType, 0, 4), VI_ERROR_PARAMETER3);
    CheckParam (IsInvalidNumericVal(SampleRate, 0, sampleRateCnt-1), VI_ERROR_PARAMETER4); 
    CheckParam (IsInvalidNumericVal(SensorType, 0, sensorTypeCnt-1), VI_ERROR_PARAMETER5); 
    CheckParam (IsInvalidNumericVal(SensorCharacterization, 0, sensorCharCnt-1), VI_ERROR_PARAMETER6); 
    CheckParam (IsInvalidNumericVal(TemperatureUnit, 0, unitCnt-1), VI_ERROR_PARAMETER7); 
 
    /* Configures the measurement of the given channels */
    switch( MeasurementType )
    {
             /* DC voltage */  
        case FL1586_MEASUREMENTTYPE_DC_VOLTAGE: 
            CheckErr (viPrintf(vi, "CONF:VOLT (@%s)\n", ChannelList));
            break;
             /* DC current */  
        case FL1586_MEASUREMENTTYPE_DC_CURRENT: 
            CheckErr (viPrintf(vi, "CONF:CURR (@%s)\n", ChannelList)); 
            break;
             /* Four-wire resistance */  
        case FL1586_MEASUREMENTTYPE_FOURWIRE_RESISTANCE: 
            CheckErr (viPrintf(vi, "CONF:FRES (@%s)\n", ChannelList)); 
            break;
             /* Two-wire resistance */  
        case FL1586_MEASUREMENTTYPE_TWOWIRE_RESISTANCE: 
            CheckErr (viPrintf(vi, "CONF:RES (@%s)\n", ChannelList)); 
            break;
             /* Three-wire resistance */  
        case FL1586_MEASUREMENTTYPE_TEMPERATURE: 
            CheckErr (viPrintf(vi, "CONF:TEMP %s,%s,(@%s)\n", gSensorTypeArr[SensorType], 
                                   gSensorCharArr[SensorCharacterization], ChannelList));
            CheckErr (viPrintf(vi, ":UNIT:TEMP %s\n", gUnitArr[TemperatureUnit]));             
            break;
        default:
            break;
    }
    
    CheckErr (viPrintf(vi, ":RATE %s\n", gSampleRateArr[SampleRate]));     

    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_ConfigureChannelScanning
 *Purpose:  Configures the scanning of given channels.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_ConfigureChannelScanning (ViSession vi,   
                                                    ViChar ChannelList[], 
                                                    ViBoolean AutoResume) 
{
    ViStatus    status = VI_SUCCESS;
    
    /* Parameter validations. */
    CheckParam (IsInvalidPtr(ChannelList), VI_ERROR_PARAMETER2);
    CheckParam (IsInvalidBooleanVal(AutoResume), VI_ERROR_PARAMETER3);
    
    /* Configures the scanning. */
    CheckErr (viPrintf(vi, "ROUT:SCAN (@%s)\n", ChannelList));  
    CheckErr (viPrintf(vi, "ROUT:SCAN:RES %s\n", AutoResume ? "ON": "OFF")); 
    
    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_ConfigureChannel
 *Purpose:  Configures the given channels.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_ConfigureChannel (ViSession vi, 
                                            ViChar ChannelList[],    
                                            ViBoolean EnableChannel,  
                                            ViReal64 ChannelDelay,    
                                            ViChar ChannelName[])
{
    ViStatus    status = VI_SUCCESS;
    
    /* Parameter validations. */
    CheckParam (IsInvalidPtr(ChannelList), VI_ERROR_PARAMETER2);
    CheckParam (IsInvalidBooleanVal(EnableChannel), VI_ERROR_PARAMETER3);
    CheckParam (IsInvalidNumericVal(ChannelDelay, 0, 600), VI_ERROR_PARAMETER4); 
    CheckParam (IsInvalidPtr(ChannelName), VI_ERROR_PARAMETER5)
    
    /* Configures the given channels. */
    CheckErr (viPrintf(vi, "ROUT:CHAN:STAT %s,(@%s)\n", EnableChannel ? "ON": "OFF", ChannelList)); 
    CheckErr (viPrintf(vi, "ROUT:CHAN:DEL %lf,(@%s)\n", ChannelDelay, ChannelList));
    CheckErr (viPrintf(vi, "ROUT:CHAN:NAME \"%s\",(@%s)\n", ChannelName, ChannelList));    
    
    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_ConfigureDataRecording
 *Purpose:  Configures the data recording in memory device.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_ConfigureDataRecording (ViSession vi, 
                                                  ViBoolean AutoDataRecording, 
                                                  ViBoolean EnableDataRecording,
                                                  ViBoolean EnableDataFileSecurity,
                                                  ViInt32 MemoryDevice) 
 {
    ViStatus    status = VI_SUCCESS;
    ViInt32     memoryDeviceCnt = sizeof(gMemoryDeviceArr)/sizeof(*gMemoryDeviceArr);
    
    /* Parameter validations. */
    CheckParam (IsInvalidBooleanVal(AutoDataRecording), VI_ERROR_PARAMETER2);
    CheckParam (IsInvalidBooleanVal(EnableDataRecording), VI_ERROR_PARAMETER3);  
    CheckParam (IsInvalidBooleanVal(EnableDataFileSecurity), VI_ERROR_PARAMETER4);
    CheckParam (IsInvalidNumericVal(MemoryDevice, 0, memoryDeviceCnt-1), VI_ERROR_PARAMETER5); 

    
    /* Configures the data recording. */
    CheckErr (viPrintf(vi, "DATA:LOG:AUTO %s\n", AutoDataRecording ? "ON": "OFF")); 
    CheckErr (viPrintf(vi, "DATA:LOG %s\n", EnableDataRecording ? "ON": "OFF")); 
    CheckErr (viPrintf(vi, "MEM:LOG:SEC %s\n", EnableDataFileSecurity ? "ON": "OFF")); 
    CheckErr (viPrintf(vi, "DATA:LOG:DEST %s\n", gMemoryDeviceArr[MemoryDevice]));    
    
    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_ConfigureDCCurrentRange
 *Purpose:  Configures the DC current range for channels.
 *
 *          Note:
 *          The channel function must already be set to dc current through
 *          "fl1586_ConfigureChannelMeasurement".
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_ConfigureDCCurrentRange (ViSession vi, 
                                                   ViChar ChannelList[],
                                                   ViInt32 DCCurrentRange)
 {
    ViStatus    status = VI_SUCCESS;
    ViInt32     currentRangeCnt = sizeof(gCurrentRangeArr)/sizeof(*gCurrentRangeArr);
    
    /* Parameter validations. */
    CheckParam (IsInvalidPtr(ChannelList), VI_ERROR_PARAMETER2);
    CheckParam (IsInvalidNumericVal(DCCurrentRange, 0, currentRangeCnt-1), VI_ERROR_PARAMETER3); 

    /* Configures the DC current range. */
    if (DCCurrentRange == FL1586_DC_CURRENT_RANGE_AUTO)   /* AUTO */
        CheckErr (viPrintf(vi, "CURR:RANG:AUTO ON,(@%s)\n", ChannelList));    
    else
        CheckErr (viPrintf(vi, "CURR:RANG %s,(@%s)\n", gCurrentRangeArr[DCCurrentRange], ChannelList));      

    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
} 
 
 
/*****************************************************************************
 *Function: fl1586_ConfigureDCVoltageRange
 *Purpose:  Configures the DC voltage range for channels.
 *
 *          Note:
 *          The channel function must already be set to dc voltage through
 *          "fl1586_ConfigureChannelMeasurement".
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_ConfigureDCVoltageRange (ViSession vi, 
                                                   ViChar ChannelList[],  
                                                   ViInt32 DCVoltageRange)  
 {
    ViStatus    status = VI_SUCCESS;
    ViInt32     voltageRangeCnt = sizeof(gVoltageRangeArr)/sizeof(*gVoltageRangeArr);
    
    /* Parameter validations. */
    CheckParam (IsInvalidPtr(ChannelList), VI_ERROR_PARAMETER2);
    CheckParam (IsInvalidNumericVal(DCVoltageRange, 0, voltageRangeCnt-1), VI_ERROR_PARAMETER3); 

    /* Configures the DC voltage range. */
    if (DCVoltageRange == FL1586_DC_VOLTAGE_RANGE_AUTO)   /* AUTO */
        CheckErr (viPrintf(vi, "VOLT:RANG:AUTO ON,(@%s)\n", ChannelList));    
    else
        CheckErr (viPrintf(vi, "VOLT:RANG %s,(@%s)\n", gVoltageRangeArr[DCVoltageRange], ChannelList));      

    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
} 


/*****************************************************************************
 *Function: fl1586_ConfigureDigitalDataByte
 *Purpose:  Sets the digital I/O port output data byte.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_ConfigureDigitalDataByte (ViSession vi, 
                                                    ViInt32 OutputDataByte)
 {
    ViStatus    status = VI_SUCCESS;
    
    /* Parameter validations. */
    CheckParam (IsInvalidNumericVal(OutputDataByte, 0, 255), VI_ERROR_PARAMETER2); 

    /* Sets the digital I/O port output data byte. */
    CheckErr (viPrintf(vi, "SOUR:DIG:DATA:BYTE %d\n", OutputDataByte));      

    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_ConfigureFourResistanceRange
 *Purpose:  Configures the four-wire resistance range for channels.
 *
 *          Note:
 *          The channel function must already be set to four-wire resistance 
 *          through "fl1586_ConfigureChannelMeasurement".
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_ConfigureFourResistanceRange (ViSession vi, 
                                                        ViChar ChannelList[],  
                                                        ViInt32 ResistanceRange)
{
    ViStatus    status = VI_SUCCESS;
    ViInt32     fourResRangeCnt = sizeof(gFourResRangeArr)/sizeof(*gFourResRangeArr);
    
    /* Parameter validations. */
    CheckParam (IsInvalidPtr(ChannelList), VI_ERROR_PARAMETER2);
    CheckParam (IsInvalidNumericVal(ResistanceRange, 0, fourResRangeCnt-1), VI_ERROR_PARAMETER3); 

    /* Configures the four-wire resistance range. */
    if (ResistanceRange == FL1586_RESISTANCE_RANGE_AUTO)   /* AUTO */
        CheckErr (viPrintf(vi, "FRES:RANG:AUTO ON,(@%s)\n", ChannelList));    
    else
        CheckErr (viPrintf(vi, "FRES:RANG %s,(@%s)\n", gFourResRangeArr[ResistanceRange], ChannelList));      

    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_ConfigureMathChannel
 *Purpose:  Configures the math function for the given math channels.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_ConfigureMathChannel (ViSession vi, 
                                                ViChar ChannelList[], 
                                                ViInt32 MathFunction,        
                                                ViChar Coefficients[],     
                                                ViChar ChannelA[],
                                                ViChar ChannelB[],                                             
                                                ViReal64 Exponent, 
                                                ViChar SourceList[]) 
{
    ViStatus    status = VI_SUCCESS;
    ViInt32     mathFunctionCnt = sizeof(gMathFunctionArr)/sizeof(*gMathFunctionArr);
    
    /* Parameter validations. */
    CheckParam (IsInvalidPtr(ChannelList), VI_ERROR_PARAMETER2);
    CheckParam (IsInvalidNumericVal(MathFunction, 0, mathFunctionCnt-1), VI_ERROR_PARAMETER3); 
    CheckParam (IsInvalidPtr(Coefficients), VI_ERROR_PARAMETER4); 
    CheckParam (IsInvalidPtr(ChannelA), VI_ERROR_PARAMETER5);
    CheckParam (IsInvalidPtr(ChannelB), VI_ERROR_PARAMETER6);
    CheckParam (IsInvalidNumericVal(Exponent, -1E+18, 1E+18), VI_ERROR_PARAMETER7); 
    CheckParam (IsInvalidPtr(SourceList), VI_ERROR_PARAMETER8);     
    
    /* Configures the math function. */
    CheckErr (viPrintf(vi, "CALC:MATH:FUNC %s,(@%s)\n", gMathFunctionArr[MathFunction], ChannelList));
    switch( MathFunction )
    {
             /* Polynomial */  
        case FL1586_MATHFUNCTION_POLYNOMIAL: 
            CheckErr (viPrintf(vi, "CALC:MATH:SOUR:ACH (@%s),(@%s)\n", ChannelA, ChannelList));
            CheckErr (viPrintf(vi, "CALC:MATH:COEF %s,(@%s)\n", Coefficients, ChannelList));
            break;
             /* Square Root */  
        case FL1586_MATHFUNCTION_SQUARE_ROOT:
             /* Exponential */ 
        case FL1586_MATHFUNCTION_EXPONENTIAL:
             /* Log10 */ 
        case FL1586_MATHFUNCTION_LOG10:
             /* Absolute Value */ 
        case FL1586_MATHFUNCTION_ABSOLUTE:
             /* Reciprocal */ 
        case FL1586_MATHFUNCTION_RECIPROCAL: 
            CheckErr (viPrintf(vi, "CALC:MATH:SOUR:ACH (@%s),(@%s)\n", ChannelA, ChannelList)); 
            break;
             /* Power */  
        case FL1586_MATHFUNCTION_POWER: 
            CheckErr (viPrintf(vi, "CALC:MATH:SOUR:ACH (@%s),(@%s)\n", ChannelA, ChannelList));
            CheckErr (viPrintf(vi, "CALC:MATH:EXP %lf,(@%s)\n", Exponent, ChannelList));
            break;            
             /* Add */ 
        case FL1586_MATHFUNCTION_ADD:
             /* Subtract */ 
        case FL1586_MATHFUNCTION_SUBTRACT:
             /* Multiply */ 
        case FL1586_MATHFUNCTION_MULTIPLY:
             /* Divide */ 
        case FL1586_MATHFUNCTION_DIVIDE: 
            CheckErr (viPrintf(vi, "CALC:MATH:SOUR:ACH (@%s),(@%s)\n", ChannelA, ChannelList)); 
            CheckErr (viPrintf(vi, "CALC:MATH:SOUR:BCH (@%s),(@%s)\n", ChannelB, ChannelList));
            break; 
             /* Average */ 
        case FL1586_MATHFUNCTION_AVERAGE:
             /* Maximum */ 
        case FL1586_MATHFUNCTION_MAXIMUM:
             /* Minimum */ 
        case FL1586_MATHFUNCTION_MINIMUM:
             /* Sum */ 
        case FL1586_MATHFUNCTION_SUM: 
            CheckErr (viPrintf(vi, "CALC:MATH:SOUR:LIST (@%s),(@%s)\n", SourceList, ChannelList)); 
            break;
        default:
            break;
    }    
    
    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_ConfigureMonitorChannel
 *Purpose:  Configures the monitor channel.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_ConfigureMonitorChannel (ViSession vi, 
                                                   ViChar ChannelList[],  
                                                   ViBoolean EnableChannelMonitoring)
{
    ViStatus    status = VI_SUCCESS;
    
    /* Parameter validations. */
    CheckParam (IsInvalidPtr(ChannelList), VI_ERROR_PARAMETER2);    
    CheckParam (IsInvalidBooleanVal(EnableChannelMonitoring), VI_ERROR_PARAMETER3);  
    
    /* Configures the monitor channel. */
    CheckErr (viPrintf(vi, "ROUT:MON:STAT %s\n", EnableChannelMonitoring ? "ON": "OFF")); 
    CheckErr (viPrintf(vi, "ROUT:MON (@%s)\n", ChannelList));    
    
    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_ConfigureMxBScaling
 *Purpose:  Configures the Mx+B scaling for the given channels.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_ConfigureMxBScaling (ViSession vi, 
                                               ViChar ChannelList[],     
                                               ViBoolean EnableScaling,     
                                               ViReal64 Gain,                  
                                               ViReal64 Offset,               
                                               ViChar Unit[])
{
    ViStatus    status = VI_SUCCESS;
    
    /* Parameter validations. */
    CheckParam (IsInvalidPtr(ChannelList), VI_ERROR_PARAMETER2);    
    CheckParam (IsInvalidBooleanVal(EnableScaling), VI_ERROR_PARAMETER3);  
    CheckParam (IsInvalidNumericVal(Gain, -1E+18, 1E+18), VI_ERROR_PARAMETER4); 
    CheckParam (IsInvalidNumericVal(Offset, -1E+18, 1E+18), VI_ERROR_PARAMETER5);     
    CheckParam (IsInvalidPtr(ChannelList), VI_ERROR_PARAMETER6);
    
    /* Configures the Mx+B scaling. */
    CheckErr (viPrintf(vi, "CALC:SCAL:STAT %s,(@%s)\n", EnableScaling ? "ON": "OFF", ChannelList)); 
    CheckErr (viPrintf(vi, "CALC:SCAL:GAIN %lf,(@%s)\n", Gain, ChannelList));    
    CheckErr (viPrintf(vi, "CALC:SCAL:OFFS %lf,(@%s)\n", Offset, ChannelList));
    CheckErr (viPrintf(vi, "CALC:SCAL:UNIT \"%s\",(@%s)\n", Unit, ChannelList));
    
    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_ConfigureResistanceAtZero
 *Purpose:  Configures the resistance at zero of specified sensor.
 *
 *          Note:
 *          The channelfunction must already be set to corresponding temperature 
 *          measurement through "fl1586_ConfigureChannelMeasurement".
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_ConfigureResistanceAtZero (ViSession vi, 
                                                     ViChar ChannelNumber[],   
                                                     ViInt32 SensorType,       
                                                     ViInt32 CharacterizationType, 
                                                     ViReal64 Resistance)
{
    ViStatus    status = VI_SUCCESS;
    
    /* Parameter validations. */
    CheckParam (IsInvalidPtr(ChannelNumber), VI_ERROR_PARAMETER2);    
    CheckParam (IsInvalidNumericVal(SensorType, 1, 3), VI_ERROR_PARAMETER3);
    CheckParam (IsInvalidNumericVal(CharacterizationType, 16, 18), VI_ERROR_PARAMETER4);
    CheckParam (IsInvalidNumericVal(Resistance, 1, 1E+3), VI_ERROR_PARAMETER5);
    
    /* Configures the resistance at zero. */
    CheckErr (viPrintf(vi, "TEMP:%s:%s:RZER %lf,(@%s)\n", gSensorTypeArr[SensorType], 
                       gSensorCharArr[CharacterizationType], Resistance, ChannelNumber)); 
    
    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_ConfigureResistanceCalculation
 *Purpose:  Configures the resistance calculation for the given channels.
 *
 *          Note:
 *          The channelfunction must already be set to corresponding temperature 
 *          measurement through "fl1586_ConfigureChannelMeasurement".
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_ConfigureResistanceCalculation (ViSession vi, 
                                                          ViChar ChannelList[], 
                                                          ViInt32 SensorType,    
                                                          ViBoolean EnableResCalc)
{
    ViStatus    status = VI_SUCCESS;
    
    /* Parameter validations. */
    CheckParam (IsInvalidPtr(ChannelList), VI_ERROR_PARAMETER2);    
    CheckParam (IsInvalidNumericVal(SensorType, 1, 5), VI_ERROR_PARAMETER3);
    CheckParam (IsInvalidBooleanVal(EnableResCalc), VI_ERROR_PARAMETER4); 
    
    /* Configures the resistance calculation. */
    CheckErr (viPrintf(vi, "TEMP:%s:CALC:RES %s,(@%s)\n", gSensorTypeArr[SensorType], 
                       EnableResCalc ? "ON": "OFF", ChannelList)); 
    
    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_ConfigureRPOLYCoefficients
 *Purpose:  Configures the characterization coefficients for type RPOLY.
 *
 *          Note:
 *          The channelfunction must already be set to corresponding temperature 
 *          measurement through "fl1586_ConfigureChannelMeasurement".
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_ConfigureRPOLYCoefficients (ViSession vi, 
                                                      ViChar ChannelNumber[],  
                                                      ViInt32 SensorType,         
                                                      ViReal64 PolyCoefficients1,
                                                      ViReal64 PolyCoefficients2,   
                                                      ViReal64 PolyCoefficients3,    
                                                      ViReal64 PolyCoefficients4)
{
    ViStatus    status = VI_SUCCESS;
    
    /* Parameter validations. */
    CheckParam (IsInvalidPtr(ChannelNumber), VI_ERROR_PARAMETER2);    
    CheckParam (IsInvalidNumericVal(SensorType, 4, 5), VI_ERROR_PARAMETER3);
    CheckParam (IsInvalidNumericVal(PolyCoefficients1, -1E+4, 1E+4), VI_ERROR_PARAMETER4); 
    CheckParam (IsInvalidNumericVal(PolyCoefficients2, -1E+7, 1E+7), VI_ERROR_PARAMETER5); 
    CheckParam (IsInvalidNumericVal(PolyCoefficients3, -1E+9, 1E+9), VI_ERROR_PARAMETER6); 
    CheckParam (IsInvalidNumericVal(PolyCoefficients4, -1E+11, 1E+11), VI_ERROR_PARAMETER7);     
    
    /* Configures the characterization coefficients. */
    CheckErr (viPrintf(vi, "TEMP:%s:RPOL:COEF %lf,%lf,%lf,%lf,(@%s)\n", gSensorTypeArr[SensorType], 
              PolyCoefficients1, PolyCoefficients2, PolyCoefficients3, PolyCoefficients4, ChannelNumber)); 
    
    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_ConfigureSPRTCoefficients
 *Purpose:  Configures deviation polynomial coefficients and characterization 
 *          resistance for SPRT characterization type.
 *
 *          Note:
 *          The channelfunction must already be set to corresponding temperature 
 *          measurement through "fl1586_ConfigureChannelMeasurement".
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_ConfigureSPRTCoefficients (ViSession vi, 
                                                     ViChar ChannelNumber[],     
                                                     ViInt32 SensorType,             
                                                     ViReal64 HighPolyCoefficients,   
                                                     ViReal64 LowPolyCoefficients,  
                                                     ViReal64 CharacterizationRes)
{
    ViStatus    status = VI_SUCCESS;
    
    /* Parameter validations. */
    CheckParam (IsInvalidPtr(ChannelNumber), VI_ERROR_PARAMETER2);    
    CheckParam (IsInvalidNumericVal(SensorType, 1, 3), VI_ERROR_PARAMETER3);
    CheckParam (IsInvalidNumericVal(HighPolyCoefficients, -0.1, 0.1), VI_ERROR_PARAMETER4); 
    CheckParam (IsInvalidNumericVal(LowPolyCoefficients, -0.1, 0.1), VI_ERROR_PARAMETER5); 
    CheckParam (IsInvalidNumericVal(CharacterizationRes, -1E-1, 1.2E+3), VI_ERROR_PARAMETER6); 
    
    /* Configures deviation polynomial coefficients. */
    CheckErr (viPrintf(vi, "TEMP:%s:SPRT:COEF:HIGH %lf,(@%s)\n", gSensorTypeArr[SensorType], 
                       HighPolyCoefficients, ChannelNumber)); 
    CheckErr (viPrintf(vi, "TEMP:%s:SPRT:COEF:LOW %lf,(@%s)\n", gSensorTypeArr[SensorType], 
                       LowPolyCoefficients, ChannelNumber)); 
    /* Configures deviation characterization resistance. */ 
    CheckErr (viPrintf(vi, "TEMP:%s:SPRT:RTPW %lf,(@%s)\n", gSensorTypeArr[SensorType], 
                       CharacterizationRes, ChannelNumber));    
    
    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_ConfigureThermocoupleCoefficients
 *Purpose:  Configures the characterization coefficients for a thermocouple.
 *
 *          Note:
 *          The channelfunction must already be set to corresponding temperature 
 *          measurement through "fl1586_ConfigureChannelMeasurement".
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_ConfigureThermocoupleCoefficients (ViSession vi, 
                                                             ViChar ChannelNumber[],
                                                             ViInt32 CharacterizationType, 
                                                             ViChar Coefficients[]) 
{
    ViStatus    status = VI_SUCCESS;
    
    /* Parameter validations. */
    CheckParam (IsInvalidPtr(ChannelNumber), VI_ERROR_PARAMETER2);    
    CheckParam (IsInvalidNumericVal(CharacterizationType, 0, 2), VI_ERROR_PARAMETER3);
    CheckParam (IsInvalidPtr(Coefficients), VI_ERROR_PARAMETER4);
    
    /* Configures the characterization coefficients for a thermocouple. */
    switch( CharacterizationType )
    {
             /* Polynomial characterized thermocouple */  
        case FL1586_POLY_THERMOCOUPLE: 
            CheckErr (viPrintf(vi, "TEMP:TC:POLY:COEF %s,(@%s)\n", Coefficients, ChannelNumber));
            break;
             /* R thermocouple */  
        case FL1586_R_THERMOCOUPLE: 
            CheckErr (viPrintf(vi, "TEMP:TC:R:COEF %s,(@%s)\n", Coefficients, ChannelNumber));
            break;
             /* S thermocouple */  
        case FL1586_S_THERMOCOUPLE: 
            CheckErr (viPrintf(vi, "TEMP:TC:S:COEF %s,(@%s)\n", Coefficients, ChannelNumber));
            break;
        default:
            break;
    }  
    
    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_ConfigureThermocoupleMeasurement
 *Purpose:  Configures the measurement of thermocouple.
 *
 *          Note:
 *          The channelfunction must already be set to corresponding temperature 
 *          measurement through "fl1586_ConfigureChannelMeasurement".
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_ConfigureThermocoupleMeasurement (ViSession vi, 
                                                            ViChar ChannelList[], 
                                                            ViBoolean EnableVoltageCalculation, 
                                                            ViBoolean EnableOpenCircuitDetection,   
                                                            ViInt32 ReferenceJunctionType,        
                                                            ViReal64 RJTemperature)
{
    ViStatus    status = VI_SUCCESS;
    ViInt32     RJTypeCnt = sizeof(gRJTypeArr)/sizeof(*gRJTypeArr);
    
    /* Parameter validations. */
    CheckParam (IsInvalidPtr(ChannelList), VI_ERROR_PARAMETER2);    
    CheckParam (IsInvalidBooleanVal(EnableVoltageCalculation), VI_ERROR_PARAMETER3);
    CheckParam (IsInvalidBooleanVal(EnableOpenCircuitDetection), VI_ERROR_PARAMETER4); 
    CheckParam (IsInvalidNumericVal(ReferenceJunctionType, 0, RJTypeCnt-1), VI_ERROR_PARAMETER5); 
    CheckParam (IsInvalidNumericVal(RJTemperature, -100, 100), VI_ERROR_PARAMETER6);
    
    /* Configures the measurement of thermocouple. */
    CheckErr (viPrintf(vi, "TEMP:TC:CALC:VOLT %s,(@%s)\n", EnableVoltageCalculation ? "ON": "OFF", ChannelList)); 
    CheckErr (viPrintf(vi, "TEMP:TC:ODET %s,(@%s)\n", EnableOpenCircuitDetection ? "ON": "OFF", ChannelList)); 
    CheckErr (viPrintf(vi, "TEMP:TC:RJUN:TYPE %s,(@%s)\n", gRJTypeArr[ReferenceJunctionType], ChannelList)); 
    
    if(ReferenceJunctionType == FL1586_REFERENCE_JUNCTION_FIXED)
        CheckErr (viPrintf(vi, "TEMP:TC:RJUN %lf,(@%s)\n", RJTemperature, ChannelList));   
    
    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}
                            

/*****************************************************************************
 *Function: fl1586_ConfigureTotalizeCount
 *Purpose:  Configures the totalize count.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_ConfigureTotalizeCount (ViSession vi, 
                                                  ViBoolean EnableTotalizeCounter, 
                                                  ViBoolean EnableTotalizeDebounce,  
                                                  ViBoolean AutoReset)
{
    ViStatus    status = VI_SUCCESS;
    
    /* Parameter validations. */
    CheckParam (IsInvalidBooleanVal(EnableTotalizeCounter), VI_ERROR_PARAMETER2);
    CheckParam (IsInvalidBooleanVal(EnableTotalizeDebounce), VI_ERROR_PARAMETER3); 
    CheckParam (IsInvalidBooleanVal(AutoReset), VI_ERROR_PARAMETER4);
    
    /* Configures the measurement of thermocouple. */
    CheckErr (viPrintf(vi, "TOT:STAT %s\n", EnableTotalizeCounter ? "ON": "OFF")); 
    CheckErr (viPrintf(vi, "TOT:TYPE %s\n", AutoReset ? "PRES": "READ")); 
    CheckErr (viPrintf(vi, "TOT:DEB %s\n", EnableTotalizeDebounce ? "ON": "OFF")); 
    
    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_ConfigureTrigger
 *Purpose:  Configures triggering and scanning.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_ConfigureTrigger (ViSession vi, 
                                            ViInt32 TriggerSource,   
                                            ViInt32 ScanInterval,    
                                            ViInt32 ScanCount)
{
    ViStatus    status = VI_SUCCESS;
    ViInt32     triggerSourceCnt = sizeof(gTriggerSourceArr)/sizeof(*gTriggerSourceArr);
    
    /* Parameter validations. */
    CheckParam (IsInvalidNumericVal(TriggerSource, 0, triggerSourceCnt-1), VI_ERROR_PARAMETER2); 
    CheckParam (IsInvalidNumericVal(ScanInterval, 0, 359999), VI_ERROR_PARAMETER3);
    CheckParam (IsInvalidNumericVal(ScanCount, 0, 99999), VI_ERROR_PARAMETER4); 
    
    /* Configures triggering and scanning. */
    CheckErr (viPrintf(vi, "TRIG:SOUR %s\n", gTriggerSourceArr[TriggerSource])); 
    CheckErr (viPrintf(vi, "TRIG:COUN %d\n", ScanCount)); 
    CheckErr (viPrintf(vi, "TRIG:TIM %d\n", ScanInterval)); 
    
    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_ConfigureTwoResistanceRange
 *Purpose:  Configures the two-wire resistance range for channels.
 *
 *          Note:
 *          The channel function must already be set to two-wire resistance.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_ConfigureTwoResistanceRange (ViSession vi, 
                                                       ViChar ChannelList[],
                                                       ViInt32 ResistanceRange)
{
    ViStatus    status = VI_SUCCESS;
    ViInt32     twoResRangeCnt = sizeof(gTwoResRangeArr)/sizeof(*gTwoResRangeArr);
    
    /* Parameter validations. */
    CheckParam (IsInvalidPtr(ChannelList), VI_ERROR_PARAMETER2);
    CheckParam (IsInvalidNumericVal(ResistanceRange, 0, twoResRangeCnt-1), VI_ERROR_PARAMETER3); 

    /* Configures the two-wire resistance range. */
    if (ResistanceRange == FL1586_RESISTANCE_RANGE_AUTO)   /* AUTO */
        CheckErr (viPrintf(vi, "RES:RANG:AUTO ON,(@%s)\n", ChannelList));    
    else
        CheckErr (viPrintf(vi, "RES:RANG %s,(@%s)\n", gTwoResRangeArr[ResistanceRange], ChannelList));      

    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_ReadAlarmOutput
 *Purpose:  Reads the alarm output.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_ReadAlarmOutput (ViSession vi, 
                                           ViInt32* AlarmOutput)
{
    ViStatus    status = VI_SUCCESS;
    
    /* Parameter validations. */
    CheckParam (IsInvalidPtr(AlarmOutput), VI_ERROR_PARAMETER2);
    
    /* Reads the alarm output. */
    CheckErr (viQueryf(vi, "OUTP:ALAR?\n", "%d", AlarmOutput));
    
    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_ReadDataFile
 *Purpose:  Reads the data file stored in internal memory or USB memory.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_ReadDataFile (ViSession vi, 
                                        ViInt32 MemoryDevice,
                                        ViChar FileName[],
                                        ViChar FileProperties[],       
                                        ViChar FileConfiguration[],    
                                        ViChar FileData[])
{
    ViStatus    status = VI_SUCCESS;
    
    /* Parameter validations. */
    CheckParam (IsInvalidNumericVal(MemoryDevice, 0, 1), VI_ERROR_PARAMETER2);
    CheckParam (IsInvalidPtr(FileName), VI_ERROR_PARAMETER3);  
    CheckParam (IsInvalidPtr(FileProperties), VI_ERROR_PARAMETER4);
    CheckParam (IsInvalidPtr(FileConfiguration), VI_ERROR_PARAMETER5);
    CheckParam (IsInvalidPtr(FileData), VI_ERROR_PARAMETER6);    
    
    switch( MemoryDevice )
    {
             /* Reads the data file stored in internal memory. */  
        case FL1586_INTERNAL_FLASH_MEMORY: 
            CheckErr (fl1586_QueryData(vi, FileProperties, "MEM:LOG:PROP? \"%s\"\n", FileName));  
            CheckErr (fl1586_QueryData(vi, FileConfiguration, "MEM:LOG:READ:CONF? \"%s\"\n", FileName));
            CheckErr (fl1586_QueryData(vi, FileData, "MEM:LOG:READ? \"%s\"\n", FileName));              
            break;
             /* Reads the data file stored in USB memory. */  
        case FL1586_EXTERNAL_USB_MEMORY: 
            CheckErr (fl1586_QueryData(vi, FileConfiguration, "MMEM:LOG:READ:CONF? \"%s\"\n", FileName));
            CheckErr (fl1586_QueryData(vi, FileData, "MMEM:LOG:READ? \"%s\"\n", FileName)); 
            break;
        default:
            break;
    }

    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_ReadDigitalInputChannel
 *Purpose:  Acquires and returns a reading of the digital input channel.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_ReadDigitalInputChannel (ViSession vi, 
                                                   ViInt32* DigitalInput)
{
    ViStatus    status = VI_SUCCESS;
    
    /* Parameter validations. */
    CheckParam (IsInvalidPtr(DigitalInput), VI_ERROR_PARAMETER2);
    
    /* Acquires and returns a reading of the digital input channel. */
    CheckErr (viQueryf(vi, "MEAS:DIG:DATA:BYTE?\n", "%d", DigitalInput));
    
    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_ReadDigitalTotalizePort
 *Purpose:  Acquires and returns a reading of the digital totalize port.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_ReadDigitalTotalizePort (ViSession vi, 
                                                   ViReal64* Result)
{
    ViStatus    status = VI_SUCCESS;
    
    /* Parameter validations. */
    CheckParam (IsInvalidPtr(Result), VI_ERROR_PARAMETER2);
    
    /* Acquires and returns a reading of the digital input channel. */
    CheckErr (viQueryf(vi, "MEAS:DIG:DATA:BYTE?\n", "%lf", Result));
    
    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_ReadLatestMeasurement
 *Purpose:  Reads the latest measurement or scan sweep.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_ReadLatestMeasurement (ViSession vi, 
                                                 ViChar MeasurementResult[])
{
    ViStatus    status = VI_SUCCESS;
    
    /* Parameter validations. */
    CheckParam (IsInvalidPtr(MeasurementResult), VI_ERROR_PARAMETER2);
    
    /* Reads the latest measurement or scan sweep. */
    CheckErr (viQueryf(vi, "FETC?\n", "%s", MeasurementResult));
    
    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_ReadMonitorChannel
 *Purpose:  Queries the latest reading of the monitor channel.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_ReadMonitorChannel (ViSession vi, 
                                              ViReal64* MonitorData)
{
    ViStatus    status = VI_SUCCESS;
    
    /* Parameter validations. */
    CheckParam (IsInvalidPtr(MonitorData), VI_ERROR_PARAMETER2);
    
    /* Queries the latest reading of the monitor channel. */
    CheckErr (viQueryf(vi, "ROUT:MON:DATA?\n", "%lf", MonitorData));
    
    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_ReadScanSweep
 *Purpose:  Reads the scan sweep in scan memory.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_ReadScanSweep (ViSession vi, 
                                         ViInt32 ReadOperation,     
                                         ViChar ChannelNumber[],   
                                         ViChar EarliestScanSweep[], 
                                         ViReal64* LatestScanSweep,      
                                         ViInt32* ScanSweepNumber)
{
    ViStatus    status = VI_SUCCESS;
    
    /* Parameter validations. */
    CheckParam (IsInvalidNumericVal(ReadOperation, 0, 2), VI_ERROR_PARAMETER2);
    CheckParam (IsInvalidPtr(ChannelNumber), VI_ERROR_PARAMETER3);
    CheckParam (IsInvalidPtr(EarliestScanSweep), VI_ERROR_PARAMETER4);
    CheckParam (IsInvalidPtr(LatestScanSweep), VI_ERROR_PARAMETER5);    
    CheckParam (IsInvalidPtr(ScanSweepNumber), VI_ERROR_PARAMETER6); 
    
    switch( ReadOperation )
    {
             /* Read Scan Sweep Number. */  
        case FL1586_READ_SCAN_SWEEP_NUMBER: 
            CheckErr (viQueryf(vi, "DATA:POIN?\n", "%d", ScanSweepNumber));  
            break;
             /* Read Latest Scan Sweep of Given Channel. */  
        case FL1586_READ_LATEST_SCAN_SWEEP: 
            CheckErr (viQueryf(vi, "DATA? (@%s)\n", "%lf", ChannelNumber, LatestScanSweep));
            break;
             /* Read and Delete Earliest Scan Sweep. */   
        case FL1586_READ_DELETE_EARLIEST_SCAN_SWEEP: 
            CheckErr (viQueryf(vi, "DATA:READ?\n", "%s", EarliestScanSweep)); 
            break;
        default:
            break;
    }

    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_ReadStatisticResult
 *Purpose:  Read the statistic result for the given channels.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_ReadStatisticResult (ViSession vi, 
                                               ViInt32 ResultType,
                                               ViChar ChannelList[], 
                                               ViChar Result[],
                                               ViChar Time[])
{
    ViStatus    status = VI_SUCCESS;
    
    /* Parameter validations. */
    CheckParam (IsInvalidNumericVal(ResultType, 0, 6), VI_ERROR_PARAMETER2);
    CheckParam (IsInvalidPtr(ChannelList), VI_ERROR_PARAMETER3);
    CheckParam (IsInvalidPtr(Result), VI_ERROR_PARAMETER4);
    CheckParam (IsInvalidPtr(Time), VI_ERROR_PARAMETER5); 
    
    switch( ResultType )
    {
             /* Arithmetic Mean */  
        case FL1586_RESULT_TYPE_ARITHMETIC_MEAN: 
            CheckErr (viQueryf(vi, "CALC:AVER:AVER? (@%s)\n", "%s", ChannelList, Result));  
            break;
             /* Statistics Sample Size */  
        case FL1586_RESULT_TYPE_SAMPLE_SIZE: 
            CheckErr (viQueryf(vi, "CALC:AVER:COUN? (@%s)\n", "%s", ChannelList, Result));
            break;
             /* Maximum Readings */   
        case FL1586_RESULT_TYPE_MAXIMUM: 
            CheckErr (viQueryf(vi, "CALC:AVER:MAX? (@%s)\n", "%s", ChannelList, Result)); 
            CheckErr (viQueryf(vi, "CALC:AVER:MAX:TIME? (@%s)\n", "%s", ChannelList, Time)); 
            break;
             /* Minimum Readings */   
        case FL1586_RESULT_TYPE_MINIMUM: 
            CheckErr (viQueryf(vi, "CALC:AVER:MIN? (@%s)\n", "%s", ChannelList, Result)); 
            CheckErr (viQueryf(vi, "CALC:AVER:MIN:TIME? (@%s)\n", "%s", ChannelList, Time)); 
            break;
             /* Peak to Peak */  
        case FL1586_RESULT_TYPE_PEAK_TO_PEAK: 
            CheckErr (viQueryf(vi, "CALC:AVER:PTP? (@%s)\n", "%s", ChannelList, Result));
            break;
             /* Rate */  
        case FL1586_RESULT_TYPE_RATE: 
            CheckErr (viQueryf(vi, "CALC:AVER:RATE? (@%s)\n", "%s", ChannelList, Result));
            break;
             /* Standard Deviation */  
        case FL1586_RESULT_TYPE_STANDARD_DEVIATION: 
            CheckErr (viQueryf(vi, "CALC:AVER:SDEV? (@%s)\n", "%s", ChannelList, Result));
            break;            
        default:
            break;
    }

    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_ReadTotalizeCount
 *Purpose:  Reads the totalize count.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_ReadTotalizeCount (ViSession vi,       
                                             ViInt32* TotalizeCount)
{
    ViStatus    status = VI_SUCCESS;
    
    /* Parameter validations. */
    CheckParam (IsInvalidPtr(TotalizeCount), VI_ERROR_PARAMETER2);
    
    /* Reads the totalize count. */
    CheckErr (viQueryf(vi, ":TOT:DATA?\n", "%d", TotalizeCount));
    
    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_ReadMeasurementResult
 *Purpose:  Sets the trigger source to TIMer, sets the scan count to 1, initiates 
 *          a scan,wait for the scan sweep to complete, and returns the readings.

 *          Notes:
 *          1. Channels should be configured for measurement before using this 
 *             function.
 *          2. The high-level functions automatically incorporate this functionality. 
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_ReadMeasurementResult (ViSession vi, 
                                                 ViChar MeasurementResult[])
{
    ViStatus    status = VI_SUCCESS;
    
    /* Parameter validations. */
    CheckParam (IsInvalidPtr(MeasurementResult), VI_ERROR_PARAMETER2);
    
    /* Reads the totalize count. */
    CheckErr (viQueryf(vi, "READ?\n", "%s", MeasurementResult));
    
    CheckErr (fl1586_CheckStatus(vi));

Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_WaitforScanComplete
 *Purpose:  Waits for scan sweep complete.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_WaitforScanComplete (ViSession vi, 
                                               ViInt32 Timeout) 
{
    ViStatus    status = VI_SUCCESS;
    ViInt32     OperationStatus = 0;
    ViReal64    timeStart = 0;
    ViReal64    timeCurr = 0; 
    ViReal64    timeInterval = 0;  
    
    /* Parameter validations. */
    CheckParam (IsInvalidNumericVal(Timeout, 0, 4294967295), VI_ERROR_PARAMETER2); 
    
    /* Waits for scan sweep complete. */
    timeStart = Timer();
    while((timeInterval*1000) < Timeout)
    {
        Delay(0.2);
        CheckErr (viQueryf(vi, "STAT:OPER?\n", "%d", &OperationStatus));
        if((OperationStatus & 16) != 0)
            goto Error;
        timeCurr = Timer();
        timeInterval = timeCurr - timeStart;
    }
    
    CheckErr (FL1586_ERROR_TIMEOUT_ERROR);
    
Error:
    return status;
}


/*****************************************************************************
 *Function: fl1586_Reset
 *Purpose:  Resets the instrument and then sends a set of default setup
 *          commands to the instrument.
 *****************************************************************************/
ViStatus _VI_FUNC  fl1586_Reset (ViSession vi)
{
    ViStatus    status = VI_SUCCESS;

    /* Reset the instrument to a known state */
    CheckErr (viPrintf (vi, "*RST\n;"));   
    
    CheckErr (fl1586_DefaultInstrSetup (vi));
    
    CheckErr (fl1586_CheckStatus (vi)); 

Error:
    return status;
}

/***************************************************************************************  
 * Function: fl1586_SelfTest                                                               
 *                                                                                     
 * Purpose:  This function executes the instrument self-test and returns the result.   
 ***************************************************************************************/
ViStatus _VI_FUNC  fl1586_SelfTest (ViSession vi, 
                                    ViInt32 *testResult,
                                    ViChar testMessage[256])
{
    ViStatus    status = VI_SUCCESS;
    ViInt32     oldTimeout = 0;
    
    /* Check input parameter ranges */
    CheckParam (IsInvalidPtr(testResult), VI_ERROR_PARAMETER2);
    CheckParam (IsInvalidPtr(testMessage), VI_ERROR_PARAMETER3);
    
    /* Self Test */
    CheckErr (viGetAttribute(vi, VI_ATTR_TMO_VALUE, &oldTimeout));
    CheckErr (viSetAttribute(vi, VI_ATTR_TMO_VALUE, 50000));
    
    CheckErr (viQueryf (vi, "*TST?\n;", "%d", testResult));
    
    CheckErr (viSetAttribute(vi, VI_ATTR_TMO_VALUE, oldTimeout));
    
    strcpy (testMessage, *testResult ? "Failed self-test." : "Passed self-test.");

    CheckErr (fl1586_CheckStatus (vi)); 

Error:
    return status;
}

/***************************************************************************************     
 * Function: fl1586_ErrorQuery                                                             
 *                                                                                     
 * Purpose:  This function queries the instrument error queue, and returns the result. 
 ***************************************************************************************/
ViStatus _VI_FUNC fl1586_ErrorQuery (ViSession vi,
                                     ViInt32 *errorCode,
                                     ViChar errorMessage[256])
{
    ViStatus    status = VI_SUCCESS;

    /* Check input parameter ranges */  
    CheckParam (IsInvalidPtr(errorCode), VI_ERROR_PARAMETER2);
    CheckParam (IsInvalidPtr(errorMessage), VI_ERROR_PARAMETER3);   
    
    /* Queris the error queue */

    CheckErr (viQueryf (vi, ":SYST:ERR?\n;", "%d,\"%[^\"]", errorCode, errorMessage));  
    
    CheckErr (fl1586_CheckStatus (vi)); 
    
Error:
    return status;
}

/***************************************************************************************         
 * Function: fl1586_ErrorMessage                                                            
 *                                                                                    
 * Purpose:  This function translates the error return value from the instrument      
 *           driver into a user-readable string.                                      
 ***************************************************************************************/
ViStatus _VI_FUNC fl1586_ErrorMessage (ViSession vi, 
                                       ViStatus statusCode, 
                                       ViChar errMessage[256])
{
    ViStatus    status = VI_SUCCESS;
    ViInt32     i;
    
    static      fl1586_tStringValPair statusDescArray[] = {
        {VI_WARN_NSUP_ID_QUERY,                 "WARNING: ID Query not supported"},
        {VI_WARN_NSUP_RESET,                    "WARNING: Reset not supported"},
        {VI_WARN_NSUP_SELF_TEST,                "WARNING: Self-test not supported"},
        {VI_WARN_NSUP_ERROR_QUERY,              "WARNING: Error Query not supported"},     
        {VI_WARN_NSUP_REV_QUERY,                "WARNING: Revision Query not supported"},
        {VI_ERROR_PARAMETER1,                   "ERROR: Parameter 1 out of range"},
        {VI_ERROR_PARAMETER2,                   "ERROR: Parameter 2 out of range"},
        {VI_ERROR_PARAMETER3,                   "ERROR: Parameter 3 out of range"},
        {VI_ERROR_PARAMETER4,                   "ERROR: Parameter 4 out of range"},
        {VI_ERROR_PARAMETER5,                   "ERROR: Parameter 5 out of range"},
        {VI_ERROR_PARAMETER6,                   "ERROR: Parameter 6 out of range"},
        {VI_ERROR_PARAMETER7,                   "ERROR: Parameter 7 out of range"},
        {VI_ERROR_PARAMETER8,                   "ERROR: Parameter 8 out of range"},
        {VI_ERROR_FAIL_ID_QUERY,                "ERROR: Identification query failed"},
        {VI_ERROR_INV_RESPONSE,                 "ERROR: Interpreting instrument response"},
        {VI_ERROR_INSTR_FILE_OPEN,              "ERROR: Opening the specified file"},
        {VI_ERROR_INSTR_FILE_WRITE,             "ERROR: Writing to the specified file"},
        {VI_ERROR_INSTR_INTERPRETING_RESPONSE,  "ERROR: Interpreting the instrument's response"},
        {VI_ERROR_INSTR_PARAMETER9,             "ERROR: Parameter 9 out of range"},
        {VI_ERROR_INSTR_PARAMETER10,            "ERROR: Parameter 10 out of range"},
        {VI_ERROR_INSTR_PARAMETER11,            "ERROR: Parameter 11 out of range"},
        {VI_ERROR_INSTR_PARAMETER12,            "ERROR: Parameter 12 out of range"},
        {VI_ERROR_INSTR_PARAMETER13,            "ERROR: Parameter 13 out of range"},
        {VI_ERROR_INSTR_PARAMETER14,            "ERROR: Parameter 14 out of range"},
        {VI_ERROR_INSTR_PARAMETER15,            "ERROR: Parameter 15 out of range"},
        
        {FL1586_ERROR_COMMAND_ERROR,            "ERROR: Instrument command error"},
        {FL1586_ERROR_DEVICE_ERROR,             "ERROR: Device dependent error"},
        {FL1586_ERROR_TIMEOUT_ERROR,            "ERROR: Timeout error"},
        {VI_NULL, VI_NULL}
    };
    
    /* Check input parameter ranges */
    CheckParam (IsInvalidPtr(errMessage), VI_ERROR_PARAMETER3);

    status = viStatusDesc (vi, statusCode, errMessage);
    if (status == VI_WARN_UNKNOWN_STATUS) 
    {
        for (i = 0; statusDescArray[i].stringName; i++) 
        {
            if (statusDescArray[i].stringVal == statusCode) 
            {
                sprintf (errMessage, "%s", statusDescArray[i].stringName); 
                return (VI_SUCCESS);
            }
        }
        sprintf (errMessage, "Unknown Error 0x%x[uw8p0]", statusCode);
        return (VI_WARN_UNKNOWN_STATUS);
    }
    
    status = VI_SUCCESS;
    
Error:  
    return status;
}


/***************************************************************************************    
 * Function: fl1586_RevisionQuery                                                           
 *                                                                                     
 * Purpose:  This function returns the driver and instrument revisions.                
 ***************************************************************************************/ 
ViStatus _VI_FUNC fl1586_RevisionQuery (ViSession vi,
                                        ViChar driverRev[256], 
                                        ViChar instrRev[256])
{
    ViStatus status = VI_SUCCESS;

    /* Check input parameter ranges */
    CheckParam (IsInvalidPtr(driverRev), VI_ERROR_PARAMETER2);
    CheckParam (IsInvalidPtr(instrRev), VI_ERROR_PARAMETER3);

    CheckErr (viQueryf (vi, "*IDN?\n;", "%*[^,],%*[^,],%*[^,],%[^\n]", instrRev));

    sprintf (driverRev, "%s", FL1586_REVISION);
    
    CheckErr (fl1586_CheckStatus (vi)); 

Error:
    return status;
}

/***************************************************************************************    
 * Function: fl1586_DefaultInstrSetup                                                   
 *                                                                                     
 * Purpose:  This function sends a default setup to the instrument.  This function is  
 *           called by the fl1586_Reset function and by the fl1586_Initialize function
 *           if the reset option has not been selected.
 ***************************************************************************************/ 
static ViStatus fl1586_DefaultInstrSetup (ViSession vi)
{
    ViStatus    status = VI_SUCCESS;

    /* *ESE 60 - enables command, execution, query, and device errors in event status register */
    /* *SRE 36 - enables standard event bits and error queue summary bit in the status byte    */
    /* *CLS - clears status                                                                    */  
    CheckErr (viPrintf(vi, "*ESE 60\n"));
    CheckErr (viPrintf(vi, "*SRE 36\n"));
    CheckErr (viPrintf(vi, "*CLS\n"));

Error:
    return status;
}

/***************************************************************************************
 * Function: fl1586_CheckStatus
 *
 * Purpose:  This function check if there is command error or device error by
 *           check the Event Status Register of the instrument.
 ***************************************************************************************/
static ViStatus fl1586_CheckStatus (ViSession vi)
{
    ViStatus    status = VI_SUCCESS;
    ViUInt32    esrValue = 0;

    CheckErr (viQueryf(vi, "*ESR?\n", "%d", &esrValue));

    if (esrValue & FL1586_VAL_ESR_COMMAND_ERROR)
    {
        CheckErr (FL1586_ERROR_COMMAND_ERROR);
    }
    else if (esrValue & FL1586_VAL_ESR_DEVICE_ERROR)
    {
        CheckErr (FL1586_ERROR_DEVICE_ERROR);
    }
    
Error:
    return status;
}


/*************************************************************************************** 
 * Function:    StringToViInt32Array
 * Description: Convert the delimiter seperated data string into ViInt32 array.
 *              The return value will be the count of data element converted.
 ***************************************************************************************/
static ViInt32 StringToViInt32Array(ViChar  dataStr[],
                                   ViInt32 resultData[],
                                   ViChar  delimiter)
{
    ViInt32 i, iArrayIdx, iNumLen, iLoopCnt = strlen(dataStr);

    for(i = 0, iArrayIdx = 0, iNumLen = 0; i < iLoopCnt; ++i)
    {
        if(dataStr[i] == delimiter || i == iLoopCnt - 1)
        {
            sscanf(dataStr + i - iNumLen, "%d", &resultData[iArrayIdx++]);
            iNumLen = 0;
        }
        else if(dataStr[i] != delimiter)
        {
            ++iNumLen;
        }
    }

    return iArrayIdx;
}


/***************************************************************************************
 * Function: fl1586_QueryData
 *
 * Purpose:  This function sends command and returns the data.
 ***************************************************************************************/
static ViStatus fl1586_QueryData(ViSession vi, ViChar Result[], ViString writeFmt, ...)
{
    ViStatus    status = VI_SUCCESS;
    ViUInt16    interface = 0;
    ViInt32     ByteNumber = 0;
    ViInt32     actureReturn = 0;

    va_list ap;
    va_start(ap, writeFmt);   
    
    CheckErr (viGetAttribute(vi, VI_ATTR_INTF_TYPE, &interface));
    if(interface == VI_INTF_ASRL)
    {   
        /* Serial */
        CheckErr (viSetAttribute(vi, VI_ATTR_ASRL_END_IN, 0)); 
        CheckErr (viSetAttribute(vi, VI_ATTR_ASRL_END_OUT, 0));
        
        CheckErr (viVPrintf(vi, writeFmt, ap));  
        Delay(0.5);    /* The data may be so large, so add a delay to way for data transport */
        CheckErr (viGetAttribute(vi, VI_ATTR_ASRL_AVAIL_NUM, &ByteNumber)); 
        CheckErr (viRead(vi, Result, ByteNumber, &actureReturn)); 

        CheckErr (viSetAttribute(vi, VI_ATTR_ASRL_END_IN, 2)); 
        CheckErr (viSetAttribute(vi, VI_ATTR_ASRL_END_OUT, 2));
    }
    else
    {
        /* TCPIP */
        CheckErr (viSetAttribute(vi, VI_ATTR_SEND_END_EN, VI_FALSE)); 
        CheckErr (viSetAttribute(vi, VI_ATTR_SUPPRESS_END_EN, VI_FALSE));
        CheckErr (viSetAttribute(vi, VI_ATTR_TERMCHAR_EN, VI_FALSE)); 

        CheckErr (viVPrintf(vi, writeFmt, ap));        
        Delay(0.5);   /* The data may be so large, so add a delay to way for data transport */
        CheckErr (viRead(vi, Result, FL1586_LARGE_BUFFER_SIZE, &actureReturn));  
        
        CheckErr (viSetAttribute(vi, VI_ATTR_SEND_END_EN, VI_TRUE)); 
        CheckErr (viSetAttribute(vi, VI_ATTR_SUPPRESS_END_EN, VI_TRUE));
        CheckErr (viSetAttribute(vi, VI_ATTR_TERMCHAR_EN, VI_TRUE)); 
    }
    
    va_end(ap);

    
Error:
   return status;
}


/*****************************************************************************
 *-------------------------- End Instrument Driver Source Code --------------*
 *****************************************************************************/

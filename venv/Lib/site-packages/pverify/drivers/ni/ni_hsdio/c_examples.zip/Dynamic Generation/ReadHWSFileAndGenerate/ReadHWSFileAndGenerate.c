/************************************************************************
*
*  Example Program:
*    ReadHWSFileAndGenerate.c
*
*  Description:
*    Read waveform data from file and generate.
*
*  Pin Connection Information:
*    None.
*
************************************************************************/


/* Includes */
#include <stdio.h>
#include <stdlib.h>
#include "niHSDIO.h"

int main(void)
{
   ViRsrc deviceID = "PXI1Slot2";
   ViConstString channelList = "0-15";
   ViString filePath = "mydata.hws";
   ViReal64 sampleClockRate = 50.0e6;
   ViConstString waveformName = "myWfm";
   ViInt32 waveformSize;
   ViInt32 timeout = 10000; /* milliseconds */

   ViSession vi = VI_NULL;
   ViStatus error = VI_SUCCESS;
   ViChar errDesc[1024];


   /* Initialize generation session */
   checkErr(niHSDIO_InitGenerationSession(
            deviceID, VI_FALSE, VI_FALSE, VI_NULL, &vi));

   /* Assign channels for dynamic generation */
   checkErr(niHSDIO_AssignDynamicChannels (vi, channelList));

   /* Configure sample clock parameters */
   checkErr(niHSDIO_ConfigureSampleClock(
            vi, NIHSDIO_VAL_ON_BOARD_CLOCK_STR, sampleClockRate));
      
   /* Write the waveform data directly to the device's onboard memory */
   checkErr(niHSDIO_WriteNamedWaveformFromFileHWS(
	    vi, waveformName, filePath, VI_FALSE, &waveformSize));

   /* Initiate generation */
   checkErr(niHSDIO_Initiate(vi));

   /* Wait for generation to complete */
   checkErr(niHSDIO_WaitUntilDone(vi, timeout));

Error:
   

   if (error == VI_SUCCESS)
   {
      /* print result */
      printf("Done without error.\n");
   }
   else
   {
      /* Get error description and print */
      niHSDIO_GetError(vi, &error, sizeof(errDesc)/sizeof(ViChar), errDesc);
      
      printf("\nError encountered\n===================\n%s\n", errDesc);
   }
   
   /* close the session */
   niHSDIO_close(vi);
   
   /* prompt to exit (for pop-up console windows) */
   printf("\nHit <Enter> to continue...\n");
   getchar();
   
   return error;
}

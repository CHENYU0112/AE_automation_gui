/************************************************************************
*
*  Example Program:
*    MultiDeviceHardwareCompare-ErrorLocationsTClk.c
*
*  Description:
*    This example demonstrates how to fetch error sample locations, 
*    as well as error bits in corresponding error samples, using 
*    multiple devices synchronized using NI-TClk.  A source-synchronous 
*    wrapback configuration is required for this example.  
*    The generation engine exports its Sample clock to 
*    DDC CLK OUT (default) and Data Active events to PFI 1 (default).
*
*  Pin Connection Information:
*    Use equal length cable to make the following connections on each device:
*	 Connect Generation Data 0-7 to Acquisition Data 8-15(0 to 8, 1 to 9, etc.)
*    Connect the exported sample clock (default: DDC Clk-Out) from the
*    generation devices to the clock input terminal (default: Strobe)
*    on the acquisition devices, and connect the Data Active Event
*    (default PFI1) to the Acquisition Start Trigger (default PFI2).
*   
*    If there are more acquisition devices than there are generation
*    devices, there may be termination and signal strength issues to
*    consider when routing any signal from a single source to multiple
*    destinations. See the section named Termination in the NI Digital
*    Waveform Generator/Analyzer Help for more information.
*    
*
************************************************************************/


/* Includes */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "niHSDIO.h"
#include "nihws.h"
#include "niTClk.h" 

/* Defines */
#define WAVEFORM_SIZE 1024
#define SAMPLES_TO_READ 1024
#define GEN_DEVICE_COUNT 2
#define ACQ_DEVICE_COUNT 2

/* These three functions were created simply to make the main program easier to read 
 * readWaveformDataFromFile:
 *   Retrieves stimulus and expected response waveforms from file.
 *   Constructs and returns waveform to be downloaded to the device
 * setupGenerationDevice:
 *   Configures generation session for stimulus response operation.
 *   Sample clock and Data Active signals exported for source-synchronous
 *   configuration
 * setupAcquisitionDevice:
 *   Configures acquisition session for stimulus response operation.
 *   Sample clock is imported from the STROBE terminal, and Start trigger is
 *   expected on the PFI 2 terminal.  See Pin connection information above.
*/
ViStatus readWaveformDataFromFile(
	ViConstString stimulusWfmFilePath, ViConstString expectedResponseWfmFilePath, 
	ViUInt8** wfmToDownload, ViInt32* numSamplesInWfmToDownload);

ViStatus setupGenerationDevice(
	ViRsrc genDeviceID, ViConstString genChannelList, 
	ViReal64 sampleClockRate, ViConstString sampleClockOutputTerminal, 
	ViConstString dataActiveEventDestination, ViConstString waveformName, 
	ViUInt8* wfmToDownload, ViInt32 numSamplesInWfmToDownload, 
	ViSession *genViPtr);

ViStatus setupAcquisitionDevice(
	ViRsrc acqDeviceID, ViConstString acqChannelList, 
	ViConstString sampleClockSource, ViReal64 sampleClockRate, 
	ViConstString startTriggerSource, ViInt32 numSamplesToAcquire, 
	ViSession *genViPtr);

int main(void)
{
	ViReal64 sampleClockRate = 50.0e6;
	ViConstString stimulusWfmChannelList = "0-7";
	ViConstString responseWfmChannelList = "8-15";
	ViInt32 timeout = 10000; /* milliseconds */
	ViInt32 numErrorSamplesAvailableToFetch = 0;
	ViInt32 numErrorSamplesRead = 0;
	ViReal64* errorSampleNumbers = NULL;
	ViUInt32* errorBitMasks = NULL;
	ViInt32* errorRepeatCounts = NULL;

	
	ViStatus error = VI_SUCCESS;
	ViChar errDesc[1024];
	ViInt32 i; /* iterator */
	
	/* Waveform parameters */
	ViString stimulusWfmFilePath = "driveWfm_8BitCountUpWithErrors.hws";
	/* stimulus waveform file without errors also provided:
     * driveWfm_8BitCountUp.hws */
	ViString expectedResponseWfmFilePath = "compareWfm_8BitCountUp.hws";
	ViUInt8* wfmToDownload = NULL;
	ViInt32 numSamplesInWfmToDownload;
	
	/* Generation parameters */
	ViRsrc genDeviceID[GEN_DEVICE_COUNT] = {"pxi1slot4","pxi1slot5"};//Change to your device names
	ViChar genChannelList[1024];
	ViConstString sampleClockOutputTerminal = NIHSDIO_VAL_DDC_CLK_OUT_STR;
	ViConstString dataActiveEventDestination = NIHSDIO_VAL_PFI1_STR;
	ViConstString waveformName = "myWfm";
	ViSession genVi[GEN_DEVICE_COUNT];
	
	/* Acquisition parameters */
	ViRsrc acqDeviceID[ACQ_DEVICE_COUNT] = {"pxi1slot4","pxi1slot5"};//Change to your device names
	ViConstString sampleClockSource = NIHSDIO_VAL_STROBE_STR;
	ViConstString startTriggerSource = NIHSDIO_VAL_PFI2_STR;
	ViInt32 numSamplesRead;
	ViUInt8 patternRead[SAMPLES_TO_READ];
	//ViUInt32 patternRead[SAMPLES_TO_READ];
	ViSession acqVi[ACQ_DEVICE_COUNT];
	
	/* Read waveform data from file */
	checkErr(readWaveformDataFromFile(
		stimulusWfmFilePath, expectedResponseWfmFilePath,
		&wfmToDownload, &numSamplesInWfmToDownload));
	
	/* Initialize all ViSession variables to VI_NULL */
	for (i = 0; i < GEN_DEVICE_COUNT; i++) 
		genVi[i] = VI_NULL;
	for (i = 0; i < ACQ_DEVICE_COUNT; i++)
		acqVi[i] = VI_NULL;
      
	/* Initialize, configure, and write waveforms to generation sessions 
     * Downloaded waveform contains stimulus and response waveforms
	 * concatenated together, so channel list must contain stimulus
	 * and response waveforms concatenated in the same order */
	strcpy(genChannelList, stimulusWfmChannelList);
	strcat(genChannelList, ",");
	strcat(genChannelList, responseWfmChannelList);
	for (i = 0; i < GEN_DEVICE_COUNT; i++) 
		checkErr(setupGenerationDevice(
			genDeviceID[i], genChannelList,	sampleClockRate, 
			sampleClockOutputTerminal, dataActiveEventDestination, 
			waveformName, wfmToDownload, numSamplesInWfmToDownload, 
			&genVi[i]));
   
	/* Configure Generation Devices for Homogeneous Triggers */
	checkErr(niTClk_ConfigureForHomogeneousTriggers(GEN_DEVICE_COUNT, genVi));
	   
	/* Synchronize All Generation Devices */
	checkErr(niTClk_Synchronize(GEN_DEVICE_COUNT, genVi, 0.0));
	
	/* Commit settings on generation devices so the sample clocks will start.
	 * This must run before Initiate is run for the Acquisition sessions */
	for (i = 0; i < GEN_DEVICE_COUNT; i++)
		checkErr(niHSDIO_CommitDynamic(genVi[i]));
   
	/* Initialize, Configure, and Initiate Acquisition Sessions */
	for (i = 0; i < ACQ_DEVICE_COUNT; i++)
		checkErr(setupAcquisitionDevice(
			acqDeviceID[i], responseWfmChannelList, sampleClockSource, 
			sampleClockRate, startTriggerSource, numSamplesInWfmToDownload, 
			&acqVi[i]));
   
	/* Initiate synchronized generation. This function must be run after the 
	 * acquisition sessions are initiated and waiting for a start trigger.
	 * Otherwise, the generation may begin before the acquisition is ready 
	 * to receive data. */
	checkErr(niTClk_Initiate(GEN_DEVICE_COUNT, genVi));
   
	for (i = 0; i < ACQ_DEVICE_COUNT; i++)
	{
		/* Wait until the waveform has been acquired by the device */
		checkErr(niHSDIO_WaitUntilDone(acqVi[i], timeout));

		/* Query the acquisition session for the number of errors that have 
		 * been acquired (but not fetched) by the device */
		checkErr(niHSDIO_GetAttributeViInt32(
			acqVi[i], "", NIHSDIO_ATTR_HWC_SAMPLE_ERROR_BACKLOG, 
			&numErrorSamplesAvailableToFetch));

		/* Fetch the sample error information */
		if(numErrorSamplesAvailableToFetch > 0)
		{
			errorSampleNumbers = 
				malloc(numErrorSamplesAvailableToFetch * sizeof(ViReal64));
			errorBitMasks = 
				malloc(numErrorSamplesAvailableToFetch * sizeof(ViUInt32));
			errorRepeatCounts = 
				malloc(numErrorSamplesAvailableToFetch * sizeof(ViInt32));

			if((errorSampleNumbers == NULL)||
				(errorBitMasks == NULL)||
				(errorRepeatCounts == NULL))
			{
				printf("The necessary memory could not be allocated.\n");
				checkErr(IVI_ERROR_OUT_OF_MEMORY);
			}

			checkErr(niHSDIO_HWC_FetchSampleErrors(
				acqVi[i], numErrorSamplesAvailableToFetch, timeout, 
				&numErrorSamplesRead, errorSampleNumbers, errorBitMasks, 
				errorRepeatCounts, NULL, NULL));
		}
   }

Error:
		if(error == VI_SUCCESS)
		{
			/* print result */
			printf("Done without error.\n");
			printf("Number of error samples read = %d.\n", numErrorSamplesRead);
		}
		else
		{
			printf("Error encountered\n===================\n");
			
			/* Get errors from NI-HSDIO sessions first.  Calling 
			 * niHSDIO_GetError returns the error and clears the error for 
			 * that session.  Calling niTClk_GetExtendedErrorInfo only returns 
			 * an error generated by NI-TClk. */
			
			for(i = 0; i < GEN_DEVICE_COUNT; i++)
			{
				niHSDIO_GetError(genVi[i], &error, 
					sizeof(errDesc)/sizeof(ViChar), errDesc);
				if(error != VI_SUCCESS)
					printf("Device ID: %s\nError Description: %s\n", 
						genDeviceID[i], errDesc);

				/* Clear error description buffer to prevent the error from 
				 * being printed multiple times */
				errDesc[0]='\0';
			}

			for(i = 0; i < ACQ_DEVICE_COUNT; i++)
			{
				niHSDIO_GetError(acqVi[i], &error, 
					sizeof(errDesc)/sizeof(ViChar), errDesc);
				if(error != VI_SUCCESS)
					printf("Device ID: %s\nError Description: %s\n", 
						acqDeviceID[i], errDesc);

				/* Clear error description buffer to prevent the error from 
				 * being printed multiple times */
				errDesc[0]='\0';
			}
			
			niTClk_GetExtendedErrorInfo(errDesc, sizeof(errDesc)/sizeof(ViChar));
      		printf("%s\n",errDesc);
			
		}
  
   /* close the sessions */
   for (i = 0; i < ACQ_DEVICE_COUNT; i++)
      niHSDIO_close(acqVi[i]);
   
   for (i = 0; i < GEN_DEVICE_COUNT; i++)
      niHSDIO_close(genVi[i]);
   
   	/* free allocated memory */
	free(wfmToDownload);
	free(errorSampleNumbers);
	free(errorBitMasks);
	free(errorRepeatCounts);
   
   /* prompt to exit (for pop-up console windows) */
   printf("\nHit <Enter> to continue...\n");
   getchar();
   
   return error;
}

ViStatus readWaveformDataFromFile(
	ViConstString stimulusWfmFilePath, ViConstString expectedResponseWfmFilePath, 
	ViUInt8** wfmToDownload, ViInt32* numSamplesInWfmToDownload)
{
	ViStatus error = VI_SUCCESS;
	ViInt32 stimulusWfmLength;
	ViInt32 responseWfmLength;
	ViInt32 numSignalsInStimulusWfm;
	ViInt32 numSignalsInResponseWfm;
	ViInt32 numSignalsInWfmToDownload;
	ViUInt8* stimulusWfm = NULL;
	ViUInt8* responseWfm = NULL;
	ViInt32 i, j, k; /* iterators */

	ViChar errDesc[1024];

	if(numSamplesInWfmToDownload == NULL)
	{
		printf("Null output parameter passed to readWaveformDataFromFile function.\n");
		checkErr(IVI_ERROR_NULL_POINTER);
	}

	/* Get stimulus and expected response waveform lengths and number of signals */
	checkErr(niHWS_RetrieveDigitalWfmWDT(
		stimulusWfmFilePath, VI_NULL, niHWS_Val_GroupBySample, 0, VI_NULL, 
		&numSignalsInStimulusWfm, & stimulusWfmLength));

	checkErr(niHWS_RetrieveDigitalWfmWDT(
		expectedResponseWfmFilePath, VI_NULL, niHWS_Val_GroupBySample, 0, VI_NULL, 
		&numSignalsInResponseWfm, &responseWfmLength));

	/* Ensure both waveforms are of the same length. 
	 * If not, truncate the longer waveform */
	if(stimulusWfmLength != responseWfmLength)
	{
		printf("Stimulus and Response waveform sizes are not equal.\n"
			"The longer waveform will be truncated.");
	}

	*numSamplesInWfmToDownload = 
		(stimulusWfmLength < responseWfmLength) ? stimulusWfmLength : responseWfmLength;

	/* Retrieve stimulus and expected response waveforms from file */
	stimulusWfm = 
		malloc(numSignalsInStimulusWfm * *numSamplesInWfmToDownload * sizeof(ViUInt8));

	responseWfm = 
		malloc(numSignalsInResponseWfm * *numSamplesInWfmToDownload * sizeof(ViUInt8));

	if((stimulusWfm == NULL)||(responseWfm == NULL))
	{
		printf("The necessary memory could not be allocated.\n");
		checkErr(IVI_ERROR_OUT_OF_MEMORY);
	}

	checkErr(niHWS_RetrieveDigitalWfmWDT(
		stimulusWfmFilePath, VI_NULL, niHWS_Val_GroupBySample, 
		*numSamplesInWfmToDownload * numSignalsInStimulusWfm, stimulusWfm, 
		&numSignalsInStimulusWfm, &stimulusWfmLength));
	checkErr(niHWS_RetrieveDigitalWfmWDT(
		expectedResponseWfmFilePath , VI_NULL, niHWS_Val_GroupBySample, 
		*numSamplesInWfmToDownload * numSignalsInResponseWfm, responseWfm, 
		&numSignalsInResponseWfm, &responseWfmLength));

	/* Construct waveform to download.  
	 * Append stimulus signals to response signals for each sample. */
	numSignalsInWfmToDownload = numSignalsInStimulusWfm + numSignalsInResponseWfm;
	*wfmToDownload = 
		malloc(numSignalsInWfmToDownload * *numSamplesInWfmToDownload * sizeof(ViUInt8));

	if(*wfmToDownload == NULL)
	{
		printf("The necessary memory could not be allocated.\n");
		checkErr(IVI_ERROR_OUT_OF_MEMORY);
	}

	/* Iterators correspond to the following:
	 * i - sample index in waveforms
	 * j - signal index in the current stimulus waveform sample
	 * k - signal index in the current response waveform sample
	*/
	for(i = 0; i < *numSamplesInWfmToDownload; ++i)
	{
		for(j = 0; j < numSignalsInStimulusWfm; ++j)
		{
			(*wfmToDownload)[(i * numSignalsInWfmToDownload) + j]= 
				stimulusWfm[(i * numSignalsInStimulusWfm) + j];			
		}
		for(k = 0; k < numSignalsInResponseWfm; ++k)
		{
			(*wfmToDownload)[(i * numSignalsInWfmToDownload) + numSignalsInStimulusWfm + k] =
				responseWfm[(i * numSignalsInResponseWfm) + k];
		}
	}
Error:

	if(error != VI_SUCCESS)
	{
		printf("Error encountered\n===================\n");

		/* Get errors from HWS */
		niHWS_GetErrorString(error, sizeof(errDesc)/sizeof(ViChar), errDesc);
		printf("File read error: %s\n\n", errDesc);
	}

	free(stimulusWfm);
	free(responseWfm);

	return error;
}

ViStatus setupGenerationDevice(
	ViRsrc genDeviceID, ViConstString genChannelList, 
	ViReal64 sampleClockRate, ViConstString sampleClockOutputTerminal, 
	ViConstString dataActiveEventDestination, ViConstString waveformName, 
	ViUInt8* wfmToDownload, ViInt32 numSamplesInWfmToDownload, 
	ViSession* genViPtr)
{
   
	ViStatus error = VI_SUCCESS;

	if(genViPtr == NULL)
	{
		printf("Null output parameter passed to setupGeneration funciton.\n");
		checkErr(IVI_ERROR_NULL_POINTER);
	}

	/* Initialize generation session */
	checkErr(niHSDIO_InitGenerationSession (
            genDeviceID, VI_FALSE, VI_FALSE, VI_NULL, genViPtr)); 
   
	/* Assign channels for dynamic generation */
	checkErr(niHSDIO_AssignDynamicChannels (*genViPtr, genChannelList));
   
	/* Configure Sample Clock */
	checkErr(niHSDIO_ConfigureSampleClock (
		*genViPtr, NIHSDIO_VAL_ON_BOARD_CLOCK_STR, sampleClockRate));
   
	/* Export Sample Clock */
	checkErr(niHSDIO_ExportSignal (
		*genViPtr, NIHSDIO_VAL_SAMPLE_CLOCK, VI_NULL, 
		sampleClockOutputTerminal));
   
	/* Export data active event */
	checkErr(niHSDIO_ExportSignal(
		*genViPtr, NIHSDIO_VAL_DATA_ACTIVE_EVENT, 
		VI_NULL, dataActiveEventDestination));

   /* Enable extended digital states to use hardware compare */
	checkErr(niHSDIO_SetAttributeViInt32(
		*genViPtr, "", NIHSDIO_ATTR_SUPPORTED_DATA_STATES, 
		NIHSDIO_VAL_STATES_0_1_Z_L_H_X));

	/* Write waveform to device */
	checkErr(niHSDIO_WriteNamedWaveformWDT(
		*genViPtr, waveformName, numSamplesInWfmToDownload, 
		NIHSDIO_VAL_GROUP_BY_SAMPLE, wfmToDownload));
   
Error:
   
   return error;
}


ViStatus setupAcquisitionDevice(
	ViRsrc acqDeviceID, ViConstString acqChannelList, 
	ViConstString sampleClockSource, ViReal64 sampleClockRate, 
	ViConstString startTriggerSource, ViInt32 numSamplesToAcquire, 
	ViSession *acqViPtr)
{
	ViStatus error = VI_SUCCESS;

	if(acqViPtr == NULL)
	{
		printf("Null output parameter passed to setupAcquisition function.\n");
		checkErr(IVI_ERROR_NULL_POINTER);
	}

	/* Initialize acquisition session */
	checkErr(niHSDIO_InitAcquisitionSession(
		acqDeviceID, VI_FALSE, VI_FALSE, VI_NULL, acqViPtr));
   
	/* Assign channels for dynamic acquisition */
	checkErr(niHSDIO_AssignDynamicChannels (*acqViPtr, acqChannelList));
   
   
	/* Configure clocking parameters */
	checkErr(niHSDIO_ConfigureSampleClock(
		*acqViPtr, sampleClockSource, sampleClockRate));
   
	/* Configure start trigger */
	checkErr(niHSDIO_ConfigureDigitalEdgeStartTrigger(
		*acqViPtr, startTriggerSource, NIHSDIO_VAL_RISING_EDGE));

   /* Enable extended digital states to use hardware compare */
	checkErr(niHSDIO_SetAttributeViInt32(
		*acqViPtr, "", NIHSDIO_ATTR_SUPPORTED_DATA_STATES, 
		NIHSDIO_VAL_STATES_0_1_Z_L_H_X));

	/* Configure the number of samples to acquire to device */
	checkErr(niHSDIO_ConfigureAcquisitionSize(
		*acqViPtr, numSamplesToAcquire, 1));
   
	/* Initiate Acquisition */
	checkErr(niHSDIO_Initiate(*acqViPtr));
   
Error:
   
   return error;
   
}

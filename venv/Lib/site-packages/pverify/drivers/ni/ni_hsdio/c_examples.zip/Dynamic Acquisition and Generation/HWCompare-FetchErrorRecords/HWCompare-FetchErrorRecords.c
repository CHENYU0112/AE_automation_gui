/************************************************************************
*
*  Example Program:
*    HWCompare-FetchErrorRecords.c
*
*  Description:
*  This example demonstrates how to fetch error sample records using 
*  NI-HSDIO hardware comparison features. External connections are 
*  required for this example.  Refer to the Pin Connection Information  
*  section below for more information about signal connections.
*
*  Pin Connection Information:
*    Please use equal lengths of cable to make the following connections 
*    on the terminal block:
*    1) DDC CLK OUT to STROBE
*    2) PFI 1 to PFI 2
*    3) Data lines 0-7 to Data lines 8-15 (line 0 to line 8, etc.)
*
************************************************************************/


/* Includes */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "niHSDIO.h"
#include "nihws.h"
 
 
/* These three functions were created simply to make the main program easier to read 
 * readWaveformDataFromFile:
 *    Retrieves stimulus and expected response waveforms from file.
 *    Constructs and returns waveform to be downloaded to the device
 * setupGeneration:
 *    Configures generation session for stimulus response operation.
 *    Sample clock and data active signals exported for source synchronous
 *    setup
 * setupAcquisition:
 *    Configures acquisition session for stimulus response operation.
 *    Sample clock is imported from Strobe terminal, and start trigger is
 *    expected on PFI2 terminal.  See Pin connection information above.
 */
ViStatus readWaveformDataFromFile(
      ViConstString stimulusWfmFilePath, ViConstString expectedResponseWfmFilePath,
      ViUInt8** wfmToDownload, ViInt32* numSamplesInWfmToDownload);

ViStatus setupGeneration(
      ViRsrc deviceID, ViConstString genChannelList,
      ViReal64 sampleClockRate, ViConstString sampleClockOutputTerminal, 
      ViConstString dataActiveEventDestination, ViConstString waveformName,
      ViUInt8* wfmToDownload, ViInt32 numSamplesInWfmToDownload, 
      ViSession* genViPtr);

ViStatus setupAcquisition(
      ViRsrc deviceID, ViConstString acqChannelList,
      ViConstString sampleClockSource, ViReal64 sampleClockRate, 
      ViConstString startTriggerSource, ViInt32 numSamplesToAcquire, 
      ViSession* acqViPtr);


int main(void)
{
   ViRsrc deviceID = "PXI1Slot2";
   ViReal64 sampleClockRate = 50.0e6;
   ViConstString stimulusWfmChannelList = "0-7";
   ViConstString responseWfmChannelList = "8-15";
   ViInt32 timeout = 10000; /* milliseconds */
   ViInt32 numErrorSamplesAvailableToFetch = 0;
   ViInt32 numErrorRecordsToFetch = 0;
   ViReal64* errorSampleNumbers = NULL;
   ViInt32 recordFetchOffset = 0;
   ViInt32 availablePreErrorSamples = 0;
   ViInt32 availablePostErrorSamples = 0;
   ViInt32 i; /* iterator */

   ViInt32 numPreErrorSamples = 10;
   ViInt32 numPostErrorSamples = 10;
   ViUInt32* errorRecords = NULL;
   ViInt32* numSamplesInCorrespondingRecord = NULL;
   ViInt32* errorSampleIndexInCorrespondingRecord = NULL;

   ViStatus error = VI_SUCCESS;
   ViChar errDesc[1024];

   /* Waveform parameters */
   ViString stimulusWfmFilePath = "driveWfm_8BitCountUpWithErrors.hws";
   /* stimulus waveform file without errors also provided: 
    * driveWfm_8BitCountUp.hws */
   ViString expectedResponseWfmFilePath = "compareWfm_8BitCountUp.hws";
   ViUInt8* wfmToDownload = NULL;
   ViInt32 numSamplesInWfmToDownload;
   
   /* Generation parameters */
   ViChar genChannelList[1024];
   ViConstString sampleClockOutputTerminal = NIHSDIO_VAL_DDC_CLK_OUT_STR;
   ViConstString dataActiveEventDestination = NIHSDIO_VAL_PFI1_STR;
   ViConstString waveformName = "myWfm";
   ViSession genVi = VI_NULL;
   
   /* Acquisition parameters */
   ViConstString sampleClockSource = NIHSDIO_VAL_STROBE_STR;
   ViConstString startTriggerSource = NIHSDIO_VAL_PFI2_STR;
   ViSession acqVi = VI_NULL;
   
   /* Read waveform data from file */
   checkErr(readWaveformDataFromFile (
            stimulusWfmFilePath, expectedResponseWfmFilePath,
            &wfmToDownload, &numSamplesInWfmToDownload));

   /* Initialize, configure, and write waveforms to generation session.
    * Downloaded waveform contains stimulus and response waveforms
    * concatenated together, so channel list must contain stimulus
    * and response waveforms concatenated in the same order */
   strcpy (genChannelList, stimulusWfmChannelList);
   strcat (genChannelList, ",");
   strcat (genChannelList, responseWfmChannelList);
   
   checkErr(setupGeneration (
            deviceID, genChannelList, sampleClockRate, 
            sampleClockOutputTerminal, dataActiveEventDestination,
            waveformName, wfmToDownload, numSamplesInWfmToDownload,
            &genVi));
   
   /* Initialize and configure acquisition session */
   checkErr(setupAcquisition (
            deviceID, responseWfmChannelList, sampleClockSource, 
            sampleClockRate, startTriggerSource, numSamplesInWfmToDownload,
            &acqVi));
   
   /* Initiate acquisition session so it is waiting for a Start trigger
    * which is sourced from the generation engine. Initiate the generation
    * session so that the Data Active event is exported to start the
    * acquistion session */
   checkErr(niHSDIO_Initiate (acqVi));
   checkErr(niHSDIO_Initiate (genVi));
   
   /* Wait until the waveform has been acquired by the device */
   checkErr(niHSDIO_WaitUntilDone (acqVi, timeout));
   
   /* Query the acquisition session for the number of errors that
    * have been acquired (but not fetched) by the device */
   checkErr(niHSDIO_GetAttributeViInt32 (
            acqVi, "", NIHSDIO_ATTR_HWC_SAMPLE_ERROR_BACKLOG, 
            &numErrorSamplesAvailableToFetch));
   
   /* Fetch the sample error information and allocate memory
    * to fetch error records (and info) */
   if (numErrorSamplesAvailableToFetch > 0)
   {
      errorSampleNumbers =
         malloc (numErrorSamplesAvailableToFetch * sizeof(ViReal64));
         
      if (errorSampleNumbers == NULL) 
      {
         printf("The necessary memory could not be allocated.\n");
         checkErr(IVI_ERROR_OUT_OF_MEMORY);
      }

      checkErr(niHSDIO_HWC_FetchSampleErrors (
               acqVi, numErrorSamplesAvailableToFetch,
               timeout, &numErrorRecordsToFetch,
               errorSampleNumbers, NULL, NULL,
               NULL, NULL));

      errorRecords =
         malloc ((numPreErrorSamples + numPostErrorSamples) * numErrorRecordsToFetch * sizeof(ViUInt32));
      numSamplesInCorrespondingRecord =
         malloc (numErrorRecordsToFetch * sizeof(ViInt32));
      errorSampleIndexInCorrespondingRecord =
         malloc (numErrorRecordsToFetch * sizeof(ViInt32));
         
      if ((errorRecords == NULL) ||
          (numSamplesInCorrespondingRecord == NULL) ||
          (errorSampleIndexInCorrespondingRecord == NULL))
      {
         printf("The necessary memory could not be allocated.\n");
         checkErr(IVI_ERROR_OUT_OF_MEMORY);
      }
   }

   /* Fetch Error records (and record information) */
   for (i = 0; i < numErrorRecordsToFetch; ++i)
   {
      /* Determine the size of each record to acquire based on the 
       * error sample numbers.
       * Error samples may be close to the beginning or end of the acquired
       * data, so the pre- and post-error record samples expected may
       * not be available*/
      availablePreErrorSamples = 
         ((ViInt32)errorSampleNumbers[i] - numPreErrorSamples) < 0 ?
         (ViInt32)errorSampleNumbers[i] : numPreErrorSamples;

      availablePostErrorSamples =
         ((ViInt32)errorSampleNumbers[i] + numPostErrorSamples) > numSamplesInWfmToDownload ?
         (numSamplesInWfmToDownload - (ViInt32)errorSampleNumbers[i]) : numPostErrorSamples;

      numSamplesInCorrespondingRecord[i] =
         availablePreErrorSamples + availablePostErrorSamples;
      errorSampleIndexInCorrespondingRecord[i] = availablePreErrorSamples;

      /* Determine fetch offset of error sample and fetch error record */
      recordFetchOffset = (ViInt32)errorSampleNumbers[i] - availablePreErrorSamples;

      checkErr(niHSDIO_SetAttributeViInt32 (
               acqVi, "", NIHSDIO_ATTR_FETCH_RELATIVE_TO, NIHSDIO_VAL_FIRST_SAMPLE));
      checkErr(niHSDIO_SetAttributeViInt32 (
               acqVi, "", NIHSDIO_ATTR_FETCH_OFFSET, recordFetchOffset)); 
               
      checkErr(niHSDIO_FetchWaveformU32 (
               acqVi, numSamplesInCorrespondingRecord[i], timeout, 
               numSamplesInCorrespondingRecord + i,
               errorRecords + (i * (numPreErrorSamples + numPostErrorSamples))));
   }


Error:
   
   if (error == VI_SUCCESS)
   {
      /* print result */ 
      printf("Done without error.\n");
      printf("Number of error records fetched = %d.\n", numErrorRecordsToFetch);
   }
   else
   {
      printf("Error encountered\n===================\n");
      
      /*  Get errors from NI-HSDIO sessions. Calling niHSDIO_GetError returns 
          the error and clears the error for that session. */
      niHSDIO_GetError(genVi, &error, sizeof(errDesc)/sizeof(ViChar), errDesc);           
      if (error != VI_SUCCESS)
         printf("Device ID: %s\nError Description: %s\n", deviceID, errDesc);
      
      niHSDIO_GetError(acqVi, &error, sizeof(errDesc)/sizeof(ViChar), errDesc);            
      if (error != VI_SUCCESS)
         printf("Device ID: %s\nError Description: %s\n", deviceID, errDesc);
   }     
   
   /* close the sessions */
   niHSDIO_close(acqVi);
   niHSDIO_close(genVi);

   /* free allocated memory */
   free (wfmToDownload);
   free (errorSampleNumbers);
   free (errorRecords);
   free (numSamplesInCorrespondingRecord);
   free (errorSampleIndexInCorrespondingRecord);
   
   /* prompt to exit (for pop-up console windows) */
   printf("\nHit <Enter> to continue...\n");
   getchar();
   
   return error;
}


ViStatus readWaveformDataFromFile(
      ViConstString stimulusWfmFilePath, ViConstString expectedResponseWfmFilePath,
      ViUInt8** wfmToDownload, ViInt32* numSamplesInWfmToDownload)
{
   ViStatus error = VI_SUCCESS;
   ViInt32 stimulusWfmLength;
   ViInt32 responseWfmLength;
   ViInt32 numSignalsInStimulusWfm;
   ViInt32 numSignalsInResponseWfm;
   ViInt32 numSignalsInWfmToDownload;
   ViUInt8* stimulusWfm = NULL;
   ViUInt8* responseWfm = NULL;
   ViInt32 i, j, k; /* iterators */
   
   ViChar errDesc[1024];
   
   if (numSamplesInWfmToDownload == NULL)
   {
      printf("Null output parameter passed to readWaveformDataFromFile function.\n");
      checkErr(IVI_ERROR_NULL_POINTER);
   }

   /* Get stimulus and expected response waveform lenghths and number of signals */
   checkErr(niHWS_RetrieveDigitalWfmWDT(
            stimulusWfmFilePath, VI_NULL, niHWS_Val_GroupBySample, 0, VI_NULL,
            &numSignalsInStimulusWfm, &stimulusWfmLength));
            
   checkErr(niHWS_RetrieveDigitalWfmWDT(
            expectedResponseWfmFilePath, VI_NULL, niHWS_Val_GroupBySample, 0, VI_NULL,
            &numSignalsInResponseWfm, &responseWfmLength));

   /* Ensure both waveforms are of the same length.  
    * If not, truncate the longer waveform */
   if (stimulusWfmLength != responseWfmLength)
   {
      printf("Stimulus and Response waveform sizes are not equal.\n"
             "The longer waveform will be truncated.");
   }
   
   *numSamplesInWfmToDownload = 
      (stimulusWfmLength < responseWfmLength) ?
      stimulusWfmLength : responseWfmLength;
   
   /* Retrieve stimulus and expected response waveforms from file */
   stimulusWfm = 
      malloc (numSignalsInStimulusWfm * *numSamplesInWfmToDownload * sizeof(ViUInt8));
      
   responseWfm = 
      malloc (numSignalsInResponseWfm * *numSamplesInWfmToDownload * sizeof(ViUInt8));
   
   if ((stimulusWfm == NULL) || (responseWfm == NULL))
   {
      printf("The necessary memory could not be allocated.\n");
      checkErr(IVI_ERROR_OUT_OF_MEMORY);
   }

   checkErr(niHWS_RetrieveDigitalWfmWDT(
            stimulusWfmFilePath, VI_NULL, niHWS_Val_GroupBySample, 
            *numSamplesInWfmToDownload * numSignalsInStimulusWfm, stimulusWfm,
            &numSignalsInStimulusWfm, &stimulusWfmLength));
            
   checkErr(niHWS_RetrieveDigitalWfmWDT(
            expectedResponseWfmFilePath, VI_NULL, niHWS_Val_GroupBySample,
            *numSamplesInWfmToDownload * numSignalsInResponseWfm, responseWfm,
            &numSignalsInResponseWfm, &responseWfmLength));

   /* Construct waveform to download.  
    * Append stimulus signals to response signals for each sample */
   numSignalsInWfmToDownload = numSignalsInStimulusWfm + numSignalsInResponseWfm;
   *wfmToDownload =
      malloc (numSignalsInWfmToDownload * *numSamplesInWfmToDownload * sizeof(ViUInt8));

   if (*wfmToDownload == NULL)
   {
      printf("The necessary memory could not be allocated.\n");
      checkErr(IVI_ERROR_OUT_OF_MEMORY);
   }

   /* Iterators correspond to the following:
    * i - sample index in waveforms
    * j - signal index in the current stimulus waveform sample
    * k - signal index in the current response waveform sample
    */
   for (i = 0; i < *numSamplesInWfmToDownload; ++i)
   {
      for (j = 0; j < numSignalsInStimulusWfm; ++j)
      {
         (*wfmToDownload)[(i * numSignalsInWfmToDownload) + j] = 
            stimulusWfm[(i * numSignalsInStimulusWfm) + j];
      }
      for (k = 0; k < numSignalsInResponseWfm; ++k)
      {
         (*wfmToDownload)[(i * numSignalsInWfmToDownload) + numSignalsInStimulusWfm + k] = 
            responseWfm[(i * numSignalsInResponseWfm) + k];
      }
   }
   

Error:

   if (error != VI_SUCCESS)
   {
      printf("Error encountered\n===================\n");
      
      /*  Get errors from HWS */
      niHWS_GetErrorString (error, sizeof(errDesc)/sizeof(ViChar), errDesc);
      printf("File read error: %s\n\n", errDesc);
   } 
   
   free (stimulusWfm);
   free (responseWfm);

   return error;
}


ViStatus setupGeneration(
      ViRsrc deviceID, ViConstString genChannelList,
      ViReal64 sampleClockRate, ViConstString sampleClockOutputTerminal, 
      ViConstString dataActiveEventDestination, ViConstString waveformName,
      ViUInt8* wfmToDownload, ViInt32 numSamplesInWfmToDownload, 
      ViSession* genViPtr)
{
   
   ViStatus error = VI_SUCCESS;

   if (genViPtr == NULL)
   {
      printf("Null output parameter passed to setupGeneration function.\n");
      checkErr(IVI_ERROR_NULL_POINTER);
   }
   
   /* Initialize generation session */
   checkErr(niHSDIO_InitGenerationSession (
            deviceID, VI_FALSE, VI_FALSE, VI_NULL, genViPtr));
   
   /* Assign channels for dynamic generation */
   checkErr(niHSDIO_AssignDynamicChannels (*genViPtr, genChannelList));
   
   /* Configure Sample Clock */
   checkErr(niHSDIO_ConfigureSampleClock (
            *genViPtr, NIHSDIO_VAL_ON_BOARD_CLOCK_STR, sampleClockRate));
   
   /* Export Sample Clock */
   checkErr(niHSDIO_ExportSignal (
            *genViPtr, NIHSDIO_VAL_SAMPLE_CLOCK, VI_NULL, 
            sampleClockOutputTerminal));
   
   /* Export data active event */
   checkErr(niHSDIO_ExportSignal(
            *genViPtr, NIHSDIO_VAL_DATA_ACTIVE_EVENT, 
            VI_NULL, dataActiveEventDestination));

   /* Enable extended digital state to use hardware compare */
   checkErr(niHSDIO_SetAttributeViInt32 (
            *genViPtr, "", NIHSDIO_ATTR_SUPPORTED_DATA_STATES, 
            NIHSDIO_VAL_STATES_0_1_Z_L_H_X));
   
   /* Write waveform to device */
   checkErr(niHSDIO_WriteNamedWaveformWDT (
            *genViPtr, waveformName, numSamplesInWfmToDownload,
            NIHSDIO_VAL_GROUP_BY_SAMPLE, wfmToDownload));
   
Error:
   
   return error;
}


ViStatus setupAcquisition(
      ViRsrc deviceID, ViConstString acqChannelList,
      ViConstString sampleClockSource, ViReal64 sampleClockRate, 
      ViConstString startTriggerSource, ViInt32 numSamplesToAcquire, 
      ViSession* acqViPtr)
{
   ViStatus error = VI_SUCCESS;
   
   if (acqViPtr == NULL)
   {
      printf("Null output parameter passed to setupAcquistion function.\n");
      checkErr(IVI_ERROR_NULL_POINTER);
   }

   /* Initialize acquisition session */
   checkErr(niHSDIO_InitAcquisitionSession(
      deviceID, VI_FALSE, VI_FALSE, VI_NULL, acqViPtr));
   
   /* Assign channels for dynamic acquisition */
   checkErr(niHSDIO_AssignDynamicChannels (*acqViPtr, acqChannelList));
   
   /* Configure clocking parameters */
   checkErr(niHSDIO_ConfigureSampleClock(
            *acqViPtr, sampleClockSource, sampleClockRate));
   
   /* Configure start trigger */
   checkErr(niHSDIO_ConfigureDigitalEdgeStartTrigger(
            *acqViPtr, startTriggerSource, NIHSDIO_VAL_RISING_EDGE));

   /* Enable extended digital state to use hardware compare */
   checkErr(niHSDIO_SetAttributeViInt32 (
            *acqViPtr, "", NIHSDIO_ATTR_SUPPORTED_DATA_STATES, 
            NIHSDIO_VAL_STATES_0_1_Z_L_H_X));
   
   /* Configure the number of samples to acquire to device */
   checkErr(niHSDIO_ConfigureAcquisitionSize(
            *acqViPtr, numSamplesToAcquire, 1));
   
Error:
   
   return error;
   
}

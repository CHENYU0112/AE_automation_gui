/************************************************************************
*
*  Example Program:
*    ReadHWSFileAndGenerateWDT.c
*
*  Description:
*    Read waveform data from an HWS file in Digital Waveform
*    Datatype format and generate.
*
*  Pin Connection Information:
*    None.
*
************************************************************************/


/* Includes */
#include <stdio.h>
#include <stdlib.h>
#include "niHSDIO.h"
#include "nihws.h"

int main(void)
{
   ViRsrc deviceID = "PXI1Slot2";
   ViConstString channelList = "0-15";
   ViString filePath = "mydata.hws";
   ViReal64 sampleClockRate = 50.0e6;
   ViUInt8* waveformData = NULL;
   ViUInt32 waveformLength = 0;
   ViUInt32 numberOfSignals = 0;
   ViConstString waveformName = "myWfm";
   ViInt32 timeout = 10000; /* milliseconds */

   ViSession vi = VI_NULL;
   ViStatus error = VI_SUCCESS;
   ViChar errDesc[1024];

   /* Initialize generation session */
   checkErr(niHSDIO_InitGenerationSession(
            deviceID, VI_FALSE, VI_FALSE, VI_NULL, &vi));

   /* Assign channels for dynamic generation */
   checkErr(niHSDIO_AssignDynamicChannels (vi, channelList));

   /* Configure sample clock parameters */
   checkErr(niHSDIO_ConfigureSampleClock(
            vi, NIHSDIO_VAL_ON_BOARD_CLOCK_STR, sampleClockRate));
            

   /* Dynamically allocate memory based on the size of the waveform */
   /* Then get waveform data from file and Write waveform to device */ 
   
   
   /* Get waveform length from file */
   checkErr(niHWS_RetrieveDigitalWfmWDT(
            filePath, VI_NULL, niHWS_Val_GroupBySample, VI_NULL, VI_NULL,
            &numberOfSignals, &waveformLength));
               
   /* Dynamically allocate memory */         
   waveformData = (ViUInt8*) malloc (numberOfSignals * waveformLength * sizeof(ViUInt8));
      
   /* Verify proper memory allocation */
   if (waveformData == NULL)
   {
      printf("The necessary memory could not be allocated.\n");
      checkErr(IVI_ERROR_OUT_OF_MEMORY);
   }
      
   /* Read data from file and write to device */
   checkErr(niHWS_RetrieveDigitalWfmWDT(
            filePath, VI_NULL, niHWS_Val_GroupBySample, waveformLength * numberOfSignals, waveformData,
            &numberOfSignals, &waveformLength));
   checkErr(niHSDIO_WriteNamedWaveformWDT(
            vi, waveformName, waveformLength, NIHSDIO_VAL_GROUP_BY_SAMPLE,
            waveformData));


   /* Initiate generation */
   checkErr(niHSDIO_Initiate(vi));

   /* Wait for generation to complete */
   checkErr(niHSDIO_WaitUntilDone(vi, timeout));

Error:
   
   /* Deallocate the buffer for waveform data */
   if (waveformData != NULL)
   {
      free (waveformData);
      waveformData = NULL;
   }

   if (error == VI_SUCCESS)
   {
      /* print result */
      printf("Read %d signals of %d samples each from file.\n", numberOfSignals, waveformLength);
      printf("Done without error.\n");
   }
   else
   {
      /* Get error description and print */
      niHSDIO_GetError(vi, &error, sizeof(errDesc)/sizeof(ViChar), errDesc);
      
      printf("\nError encountered\n===================\n%s\n", errDesc);
   }
   
   /* close the session */
   niHSDIO_close(vi);
   
   /* prompt to exit (for pop-up console windows) */
   printf("\nHit <Enter> to continue...\n");
   getchar();
   
   return error;
}

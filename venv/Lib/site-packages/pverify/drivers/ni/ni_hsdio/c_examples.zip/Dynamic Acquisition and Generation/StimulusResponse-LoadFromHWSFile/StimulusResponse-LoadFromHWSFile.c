/************************************************************************
*
*  Example Program:
*    DeviceDynamicAcqAndGen-SourceSynchronous.c
*
*  Description:
*   This example demonstrates how to provide stimulus data to a 
*   device under test (DUT), and then acquire and compare the 
*   response data from the DUT to a set of expected response values.
*   The stimulus and expected response values are provided in an 
*   HWS data file.
*
*  Pin Connection Information:
*    Connect the exported Sample clock (default: DDC CLK OUT) from the
*    generation device to the clock input terminal (default: STROBE)
*    on the acquisition device, and connect the Data Active event
*    (default PFI 1) to the acquisition Start trigger (default PFI 2).
*    
*
************************************************************************/


/* Includes */
#include <stdio.h>
#include "niHSDIO.h"

/* These two functions were created simply to make the main program easier to read */
ViStatus setupGenerationDevice (ViRsrc genDeviceID, ViConstString genChannelList, ViConstString sampleClockOutputTerminal,
                                ViReal64 sampleClockRate, ViConstString dataActiveEventDestination, ViConstString waveformName,
                                ViConstString filePath, ViInt32 *waveformSize, ViSession *genViPtr);

ViStatus setupAcquisitionDevice (ViRsrc acqDeviceID, ViConstString acqChannelList, ViConstString sampleClockSource,
                                 ViReal64 sampleClockRate, ViConstString startTriggerSource, ViInt32 acquisitionSize, ViSession *genViPtr);

int main(void)
{
  
   ViRsrc deviceID = "PXI1Slot2";
   ViReal64 sampleClockRate = 50.0e6;
   ViInt32 waveformSize;
   ViStatus error = VI_SUCCESS;
   ViChar errDesc[1024];
   ViInt32 numSampleErrors = 0; 
   
   /* Generation */
   ViConstString filePath = "bidirectionalWfm_16bitMarchingOnesWithErrors.hws";
   ViConstString genChannelList = "0-15";
   ViConstString sampleClockOutputTerminal = NIHSDIO_VAL_DDC_CLK_OUT_STR;
   ViConstString dataActiveEventDestination = NIHSDIO_VAL_PFI1_STR;
   ViConstString waveformName = "myWfm";
   ViSession genVi = VI_NULL;
   
   /* Acquisition */
   ViConstString acqChannelList = "0-15";
   ViConstString sampleClockSource = NIHSDIO_VAL_STROBE_STR;
   ViConstString startTriggerSource = NIHSDIO_VAL_PFI2_STR;
   ViInt32 msReadTimeout = 10000;
   ViSession acqVi = VI_NULL;
   
   /* Initialize, configure, and write waveforms to generation device */
   checkErr(setupGenerationDevice (deviceID, genChannelList, sampleClockOutputTerminal, 
            sampleClockRate, dataActiveEventDestination, waveformName, filePath, &waveformSize, &genVi));
   
   /* Commit settings on generation device so the Sample clock will start.
   This must run before Initiate is run for the Acquisition session */
   checkErr(niHSDIO_CommitDynamic (genVi));
   
   /* Initialize, Configure, and Initiate Acquisition Sessions */
   checkErr(setupAcquisitionDevice  (deviceID, acqChannelList, sampleClockSource,
            sampleClockRate, startTriggerSource, waveformSize, &acqVi));
   
   /* Initiate generation. This function must be run after the 
   acquisition session is initiated and waiting for a Start trigger.
   Otherwise, the generation may begin before the acquisition is ready to receive data. */
   checkErr(niHSDIO_Initiate (genVi));

   /* Wait for acquisition and generation to finish */
   checkErr(niHSDIO_WaitUntilDone (acqVi, msReadTimeout));
   
   /* Get the number of sample errors */
   checkErr(niHSDIO_GetAttributeViInt32 (acqVi, "", NIHSDIO_ATTR_HWC_NUM_SAMPLE_ERRORS, &numSampleErrors));
   

   
Error:
   
   if (error == VI_SUCCESS)
   {
      /* print result */ 
      printf("Done.\n");
      printf("Number of sample errors found = %d.\n", numSampleErrors);
   }
   else
   {
      printf("Error encountered\n===================\n");
      
      /*  Get errors from NI-HSDIO sessions. Calling niHSDIO_GetError returns 
          the error and clears the error for that session. */
      
      niHSDIO_GetError(genVi, &error, sizeof(errDesc)/sizeof(ViChar), errDesc);           
      if (error != VI_SUCCESS)
         printf("Device ID: %s\nError Description: %s\n", deviceID, errDesc);
      
      niHSDIO_GetError(acqVi, &error, sizeof(errDesc)/sizeof(ViChar), errDesc);            
      if (error != VI_SUCCESS)
         printf("Device ID: %s\nError Description: %s\n", deviceID, errDesc);
      
   }     
   
   /* close the sessions */
   niHSDIO_close(genVi);
   
   niHSDIO_close(acqVi);
   
   /* prompt to exit (for pop-up console windows) */
   printf("\nHit <Enter> to continue...\n");
   getchar();
   
   return error;
}

ViStatus setupGenerationDevice(ViRsrc genDeviceID, ViConstString genChannelList, ViConstString sampleClockOutputTerminal,
                               ViReal64 sampleClockRate,ViConstString dataActiveEventDestination, ViConstString waveformName,
                               ViConstString filePath, ViInt32 *waveformSize, ViSession *genViPtr)
{
   
   ViStatus error = VI_SUCCESS;
   ViSession genVi = VI_NULL;
   ViBoolean useRateFromWaveform = VI_FALSE;
   
   
   /* Initialize generation session */
   checkErr(niHSDIO_InitGenerationSession (
            genDeviceID, VI_FALSE, VI_FALSE, VI_NULL, &genVi));
   
   /* Assign channels for dynamic generation */
   checkErr(niHSDIO_AssignDynamicChannels (genVi, genChannelList));
   
   /* Configure Sample clock */
   checkErr(niHSDIO_ConfigureSampleClock (
            genVi, NIHSDIO_VAL_ON_BOARD_CLOCK_STR, sampleClockRate));
   
   /* Export Sample clock */
   checkErr(niHSDIO_ExportSignal (
            genVi, NIHSDIO_VAL_SAMPLE_CLOCK, VI_NULL, sampleClockOutputTerminal));
   
   /* Export Data Active event */
   checkErr(niHSDIO_ExportSignal(genVi, NIHSDIO_VAL_DATA_ACTIVE_EVENT, 
            VI_NULL, dataActiveEventDestination));
   
   /* Enable extended digital states to use hardware compare */
   checkErr(niHSDIO_SetAttributeViInt32 (
            genVi, "", NIHSDIO_ATTR_SUPPORTED_DATA_STATES, NIHSDIO_VAL_STATES_0_1_Z_L_H_X));

   /* Write waveform to device */
   checkErr(niHSDIO_WriteNamedWaveformFromFileHWS (
            genVi, waveformName, filePath, useRateFromWaveform, waveformSize));

   
   
Error:
   
   *genViPtr = genVi;
   
   return error;
}


ViStatus setupAcquisitionDevice (ViRsrc acqDeviceID, ViConstString acqChannelList, ViConstString sampleClockSource,
                                 ViReal64 sampleClockRate, ViConstString startTriggerSource, ViInt32 acquisitionSize, ViSession *acqViPtr)
{
   ViStatus error = VI_SUCCESS;
   ViSession acqVi = VI_NULL;
   
   /* Initialize acquisition session */
   checkErr(niHSDIO_InitAcquisitionSession(
      acqDeviceID, VI_FALSE, VI_FALSE, VI_NULL, &acqVi));
   
   /* Assign channels for dynamic acquisition */
   checkErr(niHSDIO_AssignDynamicChannels (acqVi, acqChannelList));
   
   
   /* Configure clocking parameters */
   checkErr(niHSDIO_ConfigureSampleClock(
            acqVi, sampleClockSource, sampleClockRate));
   
   /* Configure Start trigger */
   checkErr(niHSDIO_ConfigureDigitalEdgeStartTrigger(
            acqVi, startTriggerSource, NIHSDIO_VAL_RISING_EDGE));

   /* Enable extended digital states to use hardware compare */
   checkErr(niHSDIO_SetAttributeViInt32 (
            acqVi, "", NIHSDIO_ATTR_SUPPORTED_DATA_STATES, NIHSDIO_VAL_STATES_0_1_Z_L_H_X));
   
   /* Configure the number of samples to acquire to device */
   checkErr(niHSDIO_ConfigureAcquisitionSize(
            acqVi, acquisitionSize, 1));
   
   /* Initiate Acquisition */
   checkErr(niHSDIO_Initiate (acqVi));
   
Error:
   
   *acqViPtr = acqVi;
   
   return error;
   
}

/************************************************************************
*
*  Example Program:
*    DynamicAcquisitionOfLargeBuffer.c
*
*  Description:
*    Acquires a large buffer to device memory and fetches data in 
*    chunks.  Waveform acquired is also written to a file in chunks.
*
*  Pin Connection Information:
*    None.
*
************************************************************************/


/* Includes */
#include <stdio.h>
#include "niHSDIO.h"
#include "nihws.h"

/* Defines */
#define SAMPLES_TO_ACQUIRE 1024010
#define SAMPLES_TO_FETCH   1024

int main(void)
{
   
   ViRsrc deviceID = "PXI1Slot2";
   ViString channelList = "0-15";
   ViReal64 sampleClockRate = 50.0e6;
   ViInt32 readTimeout = 10000; /* milliseconds */
   ViString filePath = "mydata.hws";
   ViInt32 compressionLevel = 0;
   ViUInt8 patternReadU8[SAMPLES_TO_FETCH];
   ViUInt16 patternReadU16[SAMPLES_TO_FETCH]; 
   ViUInt32 patternReadU32[SAMPLES_TO_FETCH];
   ViInt32 dataWidth = 4;
   
   ViSession vi = VI_NULL;
   ViStatus error = VI_SUCCESS;
   ViInt32 numSamplesRead = 0;
   ViInt32 backlog = 0;
   ViInt32 actualSamplesToFetch = 0;
   ViInt32 totalSamplesRead = 0;
   tHWS_FileHandle fileHandle;
   ViBoolean fileOpenedSuccessfully = VI_FALSE;
   tHWS_WfmRef wfmRef;
   ViChar errDesc[1024];
   
   
   /* Initialize acquisition session */
   checkErr(niHSDIO_InitAcquisitionSession(
            deviceID, VI_FALSE, VI_FALSE, VI_NULL, &vi));
   
   /* Assign channels for dynamic acquisition */
   checkErr(niHSDIO_AssignDynamicChannels (vi, channelList));
   
            
   /* Configure clocking parameters */
   checkErr(niHSDIO_ConfigureSampleClock(
            vi, NIHSDIO_VAL_ON_BOARD_CLOCK_STR, sampleClockRate));
            
   /* Open file to write waveform to */
   checkErr(niHWS_OpenFile(
            filePath, niHWS_Val_ReadWriteCreateNewAlways, &fileHandle));
   
   fileOpenedSuccessfully = VI_TRUE;
            
   /* Create waveform reference */
   checkErr(niHWS_NewWfmReference(
            fileHandle, VI_NULL, VI_NULL, compressionLevel, &wfmRef));
            
   /* Configure dynamic channels info of stored waveform */
   checkErr(niHWS_SetWfmStringAttribute(
            wfmRef, niHWS_Attr_DynamicChannelList, channelList));
            
   /* Configure the number of samples to acquire to device */
   checkErr(niHSDIO_ConfigureAcquisitionSize(vi, SAMPLES_TO_ACQUIRE, 1));
   
   /* Initiate acquisition to device */
   printf("Acquiring data to device... \n");
   checkErr(niHSDIO_Initiate(vi));
   
   /* Fetch data from device in chunks */
   printf("Fetching data to user buffer and writing to file...\n");
   while (totalSamplesRead < SAMPLES_TO_ACQUIRE)
   {
      /* Get number of samples not yet transferred to user buffer */
      checkErr(niHSDIO_GetAttributeViInt32(
               vi, VI_NULL, NIHSDIO_ATTR_FETCH_BACKLOG, &backlog));
      
      /* Fetch size may not be a factor of the samples acquired.
         In this case, the last fetch should fetch the number of 
         samples remaining on the device */
      actualSamplesToFetch = (SAMPLES_TO_FETCH <= backlog) ? 
                             SAMPLES_TO_FETCH : backlog;

      /* Query the Data Width attribute */
      checkErr(niHSDIO_GetAttributeViInt32(
               vi, VI_NULL, NIHSDIO_ATTR_DATA_WIDTH, &dataWidth));
      
   /* Read Waveform data from device and write to HWS file*/
   /* The Data Width attribute is used to determine which
      Read and Write functions should be used. */
      if (dataWidth == 1)
      {
         checkErr(niHSDIO_FetchWaveformU8(
                  vi, SAMPLES_TO_FETCH, readTimeout, 
                  &numSamplesRead, patternReadU8));
         niHWS_WriteDigitalU8 (wfmRef, actualSamplesToFetch, patternReadU8);
      }
      else if (dataWidth == 2)
      {
         checkErr(niHSDIO_FetchWaveformU16(
                  vi, SAMPLES_TO_FETCH, readTimeout, 
                  &numSamplesRead, patternReadU16));
         niHWS_WriteDigitalU16 (wfmRef, actualSamplesToFetch, patternReadU16);
      }            
      else  /* dataWidth == 4 */
      {
         checkErr(niHSDIO_FetchWaveformU32(
                  vi, SAMPLES_TO_FETCH, readTimeout, 
                  &numSamplesRead, patternReadU32));
         niHWS_WriteDigitalU32 (wfmRef, actualSamplesToFetch, patternReadU32);
      }
      
      totalSamplesRead = totalSamplesRead + numSamplesRead;
   }
   
Error:
   
   if (error == VI_SUCCESS)
   {
      /* print result */
      printf("Done without error.\n");
      printf("Total number of samples read = %d.\n", totalSamplesRead);
   }
   else
   {
      /* Get error description and print */
      niHSDIO_GetError(vi, &error, sizeof(errDesc)/sizeof(ViChar), errDesc);
      
      printf("\nError encountered\n===================\n%s\n", errDesc);
   }
   
   /* Close the file */
   if (fileOpenedSuccessfully)
      niHWS_CloseFile(fileHandle);
   
   /* close the session */
   niHSDIO_close(vi);
   
   /* prompt to exit (for pop-up console windows) */
   printf("\nHit <Enter> to continue...\n");
   getchar();
   
   return error;
}

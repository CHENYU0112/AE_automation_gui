/************************************************************************
*
*  Example Program:
*    DynamicGenerationWithIncrementalWrite.c
*
*  Description:
*    Reads a large waveform from a file, in chunks, and writes it 
*    to the device.
*
*  Pin Connection Information:
*    None.
*
************************************************************************/


/* Includes */
#include <stdio.h>
#include "niHSDIO.h"
#include "nihws.h"

/* Defines */
#define CHUNK_SIZE    65536
#define CHANNEL_STRING_SIZE 256

int main(void)
{
   
   ViString filePath = "mydata.hws";
   ViRsrc deviceID = "PXI1Slot2";
   ViChar channelList[CHANNEL_STRING_SIZE];
   ViReal64 sampleClockRate = 50.0e6;
   ViInt32 dataWidth = 4;
   ViUInt8 bufferU8[CHUNK_SIZE];
   ViUInt16 bufferU16[CHUNK_SIZE];
   ViUInt32 bufferU32[CHUNK_SIZE];
   ViConstString waveformName = "myWfm";
   ViInt32 timeout = 10000; /* milliseconds */
   
   tHWS_FileHandle fileHandle;
   tHWS_WfmRef wfmRef;
   ViSession vi = VI_NULL;
   ViInt32 waveformSize = 0;
   ViInt32 numSamplesWritten = 0;
   ViInt32 actualSamplesRead = 0;
   ViStatus error = VI_SUCCESS;
   ViChar errDesc[1024];
   ViBoolean fileOpenedSuccessfully = VI_FALSE;
   

   /* Open file to read in data */
   checkErr(niHWS_OpenFile(
            filePath, niHWS_Val_ReadOnly, &fileHandle));
            
   fileOpenedSuccessfully = VI_TRUE;
            
   /* Get waveform reference */
   checkErr(niHWS_GetWfmReference(
            fileHandle, VI_NULL, VI_NULL, &wfmRef));
            
   /* Get channel list of stored waveform */
   checkErr(niHWS_GetWfmStringAttribute(
            wfmRef, niHWS_Attr_DynamicChannelList,
            CHANNEL_STRING_SIZE, channelList));
            
   /* Initialize generation session */
   checkErr(niHSDIO_InitGenerationSession(
            deviceID, VI_FALSE, VI_FALSE, VI_NULL, &vi));
   
   /* Assign channels for dynamic generation */
   checkErr(niHSDIO_AssignDynamicChannels(vi, channelList));
   

   /* Configure clocking parameters */
   checkErr(niHSDIO_ConfigureSampleClock(
            vi, NIHSDIO_VAL_ON_BOARD_CLOCK_STR, sampleClockRate));

   /* Get waveform size and allocate waveform space on device memory */
   checkErr(niHWS_GetWfmI32Attribute(
            wfmRef, niHWS_Attr_WaveformSize, &waveformSize));
   
   checkErr(niHSDIO_AllocateNamedWaveform(vi, waveformName, waveformSize));
   
   /* Query the Data Width Attribute */
   checkErr(niHSDIO_GetAttributeViInt32(
            vi, VI_NULL, NIHSDIO_ATTR_DATA_WIDTH, &dataWidth));
   
   /* Write waveform to device in chunks */
   printf("Writing waveform to device...\n");
   while (numSamplesWritten < waveformSize) 
   {
   
      /* Read in chunk of waveform and Write chunk to device */
      /* The Data Width attribure is used to determine which
         Write and Read functions should be used */
   
      if (dataWidth == 1)
      {
      checkErr(niHWS_ReadDigitalU8(
               wfmRef, CHUNK_SIZE, bufferU8, &actualSamplesRead));
      checkErr(niHSDIO_WriteNamedWaveformU8(
               vi, waveformName, actualSamplesRead, bufferU8));
      }
      else if (dataWidth == 2)
      {
      checkErr(niHWS_ReadDigitalU16(
               wfmRef, CHUNK_SIZE, bufferU16, &actualSamplesRead));
      checkErr(niHSDIO_WriteNamedWaveformU16(
               vi, waveformName, actualSamplesRead, bufferU16));
      }
      else   /*dataWidth == 4*/
      {
      checkErr(niHWS_ReadDigitalU32(
               wfmRef, CHUNK_SIZE, bufferU32, &actualSamplesRead));
      checkErr(niHSDIO_WriteNamedWaveformU32(
               vi, waveformName, actualSamplesRead, bufferU32));
      }
               
      numSamplesWritten = numSamplesWritten + actualSamplesRead;
   }
   
   /* Initiate generation */
   printf("Generation initiated.\n");
   checkErr(niHSDIO_Initiate(vi));
   
   /* Wait for generation to complete */
   checkErr(niHSDIO_WaitUntilDone(vi, timeout));
   
Error:
   
   if (error == VI_SUCCESS)
   {
      /* print result */
      printf("Done without error.\n");
   }
   else
   {
      /* Get error description and print */
      printf("\nError status code: %d", error);
      niHSDIO_GetError(vi, &error, sizeof(errDesc)/sizeof(ViChar), errDesc);
      
      printf("\nError encountered\n===================\n%s\n", errDesc);
   }
   
   /* close the session */
   niHSDIO_close(vi);
   
   /* close file */
   if (fileOpenedSuccessfully)
      niHWS_CloseFile(fileHandle);
      
   
   /* prompt to exit (for pop-up console windows) */
   printf("\nHit <Enter> to continue...\n");
   getchar();
   
   return error;
}

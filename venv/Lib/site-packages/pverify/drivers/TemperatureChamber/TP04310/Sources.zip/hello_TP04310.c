#include <utility.h>
#include <formatio.h>
#include "TP04310.h"
#include <cvirte.h>

int main (int argc, char *argv[])
{
	ViRsrc	tp4310_addr = "GPIB::9::INSTR";
	//ViRsrc	tp4310_addr = "ASRL1::INSTR";
	ViSession 	tp4310;
	
	int i;
	
	ViChar driver[512];
	ViChar instrument[512];
	ViChar read_buffer[512];

	ViInt16  param_value;
	ViInt32  param_value_32;
	ViInt16  setp_num;
	ViInt16  setp_soak;
	ViReal64 setp_temp;
	ViReal64 setp_wndw;
	ViReal64 setp_ramp;
	
	if (InitCVIRTE (0, argv, 0) == 0)
		return -1;    /* out of memory */
	
	/* initialize connection to TP04300 instrument */
	TP04310_init (tp4310_addr, VI_TRUE,VI_FALSE, 9600, NULL, 5000, &tp4310);
	/* allo  couple seconds to reconfigure serial interface*/

	Delay(3.0);
	/* query revision and TP04300 identification string*/
	TP04310_revisionQuery(tp4310, driver, instrument);
	
	/* Display the instrument reply in Standard I/O window*/
	FmtOut("Hello, %s", instrument);
	

	Delay(3.0);

	/* Close connection to TP04310 instrument */
	TP04310_close(tp4310);
	
	return 0;
}

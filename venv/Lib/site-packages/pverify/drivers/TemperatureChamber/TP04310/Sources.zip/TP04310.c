#include <visa.h>
#include <ansi_c.h>
#include <formatio.h>
#include "TP04310.h"

#define TP04310_REVISION     "Rev 1.0, 09/07, CVI 8.0.1" /*  Instrument driver revision */
#define BUFFER_SIZE         512L         /* File I/O buffer size */
    
/*= TP04310 =================================================================*/
/* LabWindows/CVI 8.0.1 Instrument Driver                                    */
/* Original Release:                                                         */
/* By: Temptronic Corporation                                                                      */
/*     PH. (781) 688-2300               Fax  (781) 688-2301                  */
/*     e-mail: Service@temptronic.com                                        */
/* Modification History:                                                 */
/*===========================================================================*/
 
/*****************************************************************************/
/*= INSTRUMENT-DEPENDENT STATUS/RANGE STRUCTURE  ============================*/
/*****************************************************************************/
/*****************************************************************************/
/* TP04310_stringValPair is used in the TP04310_errorMessage function          */
/*===========================================================================*/
typedef struct  TP04310_stringValPair
{
   ViStatus stringVal;
   ViString stringName;
}  TP04310_tStringValPair;

/*=====================================================================*/
/* Use TP04310_instrStatusData structure to reflect the global status  */
/* variables that TP04310 driver needs to keep track of.               */
/*=====================================================================*/
struct TP04310_instrStatusData 
{
	ViChar    instrDriverRevision[512];
};

typedef struct TP04310_instrStatusData *TP04310_instrData;

/*****************************************************************************/
/*= UTILITY ROUTINE DECLARATIONS (Non-Exportable Functions) =================*/
/*****************************************************************************/
ViBoolean TP04310_invalidViBooleanRange (ViBoolean val);
ViBoolean TP04310_invalidViInt16Range (ViInt16 val, ViInt16 min, ViInt16 max);
ViBoolean TP04310_invalidViInt32Range (ViInt32 val, ViInt32 min, ViInt32 max);
ViBoolean TP04310_invalidViUInt8Range (ViUInt8 val, ViUInt8 min, ViUInt8 max);
ViBoolean TP04310_invalidViUInt16Range (ViUInt16 val, ViUInt16 min, ViUInt16 max);
ViBoolean TP04310_invalidViUInt32Range (ViUInt32 val, ViUInt32 min, ViUInt32 max);
ViBoolean TP04310_invalidViReal32Range (ViReal32 val, ViReal32 min, ViReal32 max);
ViBoolean TP04310_invalidViReal64Range (ViReal64 val, ViReal64 min, ViReal64 max);
ViStatus TP04310_waitOnVisaEvent (ViSession instrSession, ViEventType eventTypeIn, ViUInt32 tmoIn, ViPUInt16 STB);
ViStatus TP04310_initCleanUp (ViSession openRMSession, ViPSession openInstrSession, ViStatus currentStatus);
ViStatus TP04310_readToFile (ViSession instrSession, ViString filename, ViUInt32 readBytes, ViPUInt32 retCount);
ViStatus TP04310_writeFromFile (ViSession instrSession, ViString filename, ViUInt32 writeBytes, ViPUInt32 retCount);
ViStatus TP04310_defaultInstrSetup (ViSession openInstrSession);

/*****************************************************************************/
/*====== USER-CALLABLE FUNCTIONS (Exportable Functions) =====================*/
/*****************************************************************************/

/*===========================================================================*/
/* Function: Initialize                                                      */
/* Purpose:  This function opens the instrument, queries the instrument      */
/*           for its ID, and initializes the instrument to a known state.    */
/*===========================================================================*/

ViStatus _VI_FUNC TP04310_init (ViRsrc resourceName, 
								ViBoolean IDQuery,
                    			ViBoolean resetDevice, 
								ViInt32 baudRate,
								ViInt16 parity, 
            					ViInt32 timeoutmSec,
								ViPSession instrSession)
{
    ViStatus TP04310_status = VI_SUCCESS;
    ViSession rmSession = 0;
    ViUInt32 retCnt = 0;
    ViByte rdBuffer[BUFFER_SIZE];
	TP04310_instrData instrPtr = NULL;
	int serial = 0;
	
	
    /*- Check input parameter ranges ----------------------------------------*/
    if (TP04310_invalidViBooleanRange (IDQuery))
        return VI_ERROR_PARAMETER2;
    if (TP04310_invalidViBooleanRange (resetDevice))
        return VI_ERROR_PARAMETER3;
	
	
	/*- Check if serial interface    ----------------------------------------*/
	if ( FindPattern(resourceName, 0, 4, "ASRL", 0, 0) >= 0)
	{
		serial = 1;
		switch (baudRate)
		{
	        case    600:
	        case   1200:
	        case   2400:
	        case   4800:
	        case   9600:
	        case  19200:
	        case  38400:
	             break;
	        default:
	            TP04310_status = VI_ERROR_PARAMETER4;
	            return TP04310_status;
	    }
	    if (TP04310_invalidViInt16Range (parity, 0, 4))
	        return VI_ERROR_PARAMETER5;
	    if (timeoutmSec != -1 && timeoutmSec != 0)
	        if (TP04310_invalidViInt32Range (timeoutmSec, 1, 0x7fffffff))
	            return VI_ERROR_PARAMETER6;
	}	

    /*- Open instrument session ---------------------------------------------*/
    if ((TP04310_status = viOpenDefaultRM (&rmSession)) < 0)
        return TP04310_status;

    if ((TP04310_status = viOpen (rmSession, resourceName, VI_NULL, VI_NULL, instrSession)) < 0) 
	{
        viClose (rmSession);
        return TP04310_status;
    }

    /* Determine if the instrumment data structure has been initialized for  */
    /* the current VISA Session and malloc if it has not.                    */
    if (TP04310_status = viGetAttribute (*instrSession, VI_ATTR_USER_DATA, &instrPtr))
        return TP04310_status;
    
	
    if (instrPtr == NULL) 
        instrPtr = malloc (sizeof (struct TP04310_instrStatusData));

	Fmt (instrPtr -> instrDriverRevision, "%s<%s", TP04310_REVISION);
    
    if ((TP04310_status = viSetAttribute (*instrSession, VI_ATTR_USER_DATA, 
                            (ViUInt32)instrPtr)) < 0)
        return TP04310_status;   
	
    /*- Configure VISA Formatted I/O ----------------------------------------*/
  
    if ((TP04310_status = viSetBuf (*instrSession, VI_READ_BUF|VI_WRITE_BUF, 4000)) < 0)
            return TP04310_initCleanUp (rmSession, instrSession, TP04310_status);
  
    if ((TP04310_status = viSetAttribute (*instrSession, VI_ATTR_WR_BUF_OPER_MODE,
                            VI_FLUSH_ON_ACCESS)) < 0)
            return TP04310_initCleanUp (rmSession, instrSession, TP04310_status);
    
    if ((TP04310_status = viSetAttribute (*instrSession, VI_ATTR_RD_BUF_OPER_MODE,
                            VI_FLUSH_ON_ACCESS)) < 0)
            return TP04310_initCleanUp (rmSession, instrSession, TP04310_status);
	
	if (serial == 0)
	{
	    if ((TP04310_status = viSetAttribute (*instrSession, VI_ATTR_TMO_VALUE, 10000)) < 0)
	    	return TP04310_initCleanUp (rmSession, instrSession, TP04310_status);

	}
	else
	{
	    /* Serial Interface initialized to 8 databits, 1 stopbit, no parity, no flow control    */
	    if ((TP04310_status = viSetAttribute (*instrSession, VI_ATTR_ASRL_DATA_BITS, 8)) < 0)
	            return TP04310_initCleanUp (rmSession, instrSession, TP04310_status);
    
	    if ((TP04310_status = viSetAttribute (*instrSession, VI_ATTR_ASRL_STOP_BITS,
	                                         VI_ASRL_STOP_ONE)) < 0)
	            return TP04310_initCleanUp (rmSession, instrSession, TP04310_status);
   
	    if ((TP04310_status = viSetBuf (*instrSession, VI_ASRL_IN_BUF|VI_ASRL_OUT_BUF, 512)) < 0)
	            return TP04310_initCleanUp (rmSession, instrSession, TP04310_status);
   
 
	    if ((TP04310_status = viSetAttribute (*instrSession, VI_ATTR_TERMCHAR, '\n')) < 0)
	            return TP04310_initCleanUp (rmSession, instrSession, TP04310_status);
 
	    if ((TP04310_status = viSetAttribute (*instrSession, VI_ATTR_ASRL_END_IN,
	                                         VI_ASRL_END_TERMCHAR)) < 0)
	            return TP04310_initCleanUp (rmSession, instrSession, TP04310_status);
   
	    if ((TP04310_status = viSetAttribute (*instrSession, VI_ATTR_ASRL_END_OUT,
	                                         VI_ASRL_END_NONE)) < 0)
	            return TP04310_initCleanUp (rmSession, instrSession, TP04310_status);

	    if ((TP04310_status = TP04310_reconfigInterface (*instrSession, baudRate, 
	                            parity, timeoutmSec)) < 0)
	            return TP04310_initCleanUp (rmSession, instrSession, TP04310_status);
	}

    /*- Identification Query ------------------------------------------------*/
    if (IDQuery)
	{
        if ((TP04310_status = viWrite (*instrSession, "*IDN?\r\n", 7, &retCnt)) < 0)
            return TP04310_initCleanUp (rmSession, instrSession, TP04310_status);
        if ((TP04310_status = viRead (*instrSession, rdBuffer, BUFFER_SIZE, &retCnt)) < 0)
            return TP04310_status;

	    if ((TP04310_status = viSetAttribute (*instrSession, VI_ATTR_USER_DATA, 
                            (ViUInt32)instrPtr)) < 0)
            return TP04310_status;   
    }
        
    /*- Reset instrument ----------------------------------------------------*/
    if (resetDevice) {
        if ((TP04310_status = TP04310_reset (*instrSession)) < 0)
            return TP04310_initCleanUp (rmSession, instrSession, TP04310_status);
    }       
    else  /*- Send Default Instrument Setup ---------------------------------*/
        if ((TP04310_status = TP04310_defaultInstrSetup (*instrSession)) < 0)
            return TP04310_initCleanUp (rmSession, instrSession, TP04310_status);
	
    return TP04310_status;
}

/*===========================================================================*/
/* Function: Reconfigure Interface                                           */
/* Purpose:  This function allows the user to change the Baud Rate, Parity,  */
/*           and Time Out of the serial interface.                           */
/*===========================================================================*/
ViStatus _VI_FUNC TP04310_reconfigInterface (ViSession instrumentHandle, ViInt32 baudRate,
                                   ViInt16 parity, ViInt32 timeoutmSec)
{
    ViStatus TP04310_status = VI_SUCCESS;
    
    switch (baudRate)
	{
        case    300:
        case   1200:
        case   2400:
        case   4800:
        case   9600:
        case  19200:
        case  38400:
        case  57600:
           break;
        default:
            TP04310_status = VI_ERROR_PARAMETER2;
            return TP04310_status;
    }
    if (TP04310_invalidViInt16Range (parity, 0, 4))
        return VI_ERROR_PARAMETER3;
    if (timeoutmSec != -1 && timeoutmSec != 0)
        if (TP04310_invalidViInt32Range (timeoutmSec, 1, 0x7fffffff))
            return VI_ERROR_PARAMETER4;
    
    if ((TP04310_status = viSetAttribute (instrumentHandle, VI_ATTR_ASRL_BAUD, 
                                        (ViUInt32)baudRate)) < 0)
        return TP04310_status;                                       
    if ((TP04310_status = viSetAttribute (instrumentHandle, VI_ATTR_ASRL_PARITY,
                                        (ViUInt16)parity)) < 0)
        return TP04310_status;                                       
    if ((TP04310_status = viSetAttribute (instrumentHandle, VI_ATTR_TMO_VALUE,
                                        (ViUInt32)(timeoutmSec))) < 0)
        return TP04310_status;                                       
    return TP04310_status;
}
/*===========================================================================*/

/*****************************************************************************/
/*-------- INSERT USER-CALLABLE INSTRUMENT-DEPENDENT ROUTINES HERE ----------*/
/*****************************************************************************/
           

ViStatus _VI_FUNC TP04310_write_config_parameter (ViSession instrumentHandle,
                                                  ViInt16 configParamID,
                                                  ViInt16 configParamValue)
{
    ViStatus TP04310_status = VI_SUCCESS;
	ViChar writeBuffer[BUFFER_SIZE] = {0};
    ViUInt32 writeCnt = 0,
		     retCnt = 0;
	// check all the parameters for proper range and 
	// build a string to write to the instrument
	switch (configParamID)
	{
		default:	
			break;
		case TP04310_CONFIG_CYCLE_COUNT:
			if(TP04310_invalidViInt16Range ( configParamValue, 1, 9999))
				return VI_ERROR_PARAMETER3;
			Fmt(writeBuffer,"CYCC %i\r\n", configParamValue);
			break;
		case TP04310_CONFIG_SHUTDOWN_TIMER:
			if(TP04310_invalidViInt16Range ( configParamValue, 0, 1000))
				return VI_ERROR_PARAMETER3;
			Fmt(writeBuffer,"STIM %i\r\n", configParamValue);
		    break;
    	case TP04310_CONFIG_TEST_TIME:
			if(TP04310_invalidViInt16Range ( configParamValue, 0, 9999))
				return VI_ERROR_PARAMETER3;
			Fmt(writeBuffer,"TTIM %i\r\n", configParamValue);
			break;
		case TP04310_CONFIG_DUT_SENSOR_TYPE:
			if(TP04310_invalidViInt16Range ( configParamValue, 0, 2))
				return VI_ERROR_PARAMETER3;
			Fmt(writeBuffer,"DSNS %i\r\n", configParamValue);
			break;
		case TP04310_CONFIG_DUT_THERMAL_CONSTANT:
			if(TP04310_invalidViInt16Range ( configParamValue, 20, 500))
				return VI_ERROR_PARAMETER3;
			Fmt(writeBuffer,"DUTC %i\r\n", configParamValue);
			break;
		case TP04310_CONFIG_DUT_MODE:
			if(TP04310_invalidViInt16Range ( configParamValue, 0, 1))
				return VI_ERROR_PARAMETER3;
			Fmt(writeBuffer,"DUTM %i\r\n", configParamValue);
			break;
		case TP04310_CONFIG_AIR_LOW_TEMP_LIMIT:
			if(TP04310_invalidViInt16Range ( configParamValue, -99, 25))
				return VI_ERROR_PARAMETER3;
			Fmt(writeBuffer,"LLIM %i\r\n", configParamValue);
			break;
		case TP04310_CONFIG_AIR_HIGH_TEMP_LIMIT:
			if(TP04310_invalidViInt16Range ( configParamValue, 25, 225))
				return VI_ERROR_PARAMETER3;
			Fmt(writeBuffer,"ULIM %i\r\n", configParamValue);
			break;
		case TP04310_CONFIG_AIR_TO_DUT_MAX_DIFFERENCE:
			if(TP04310_invalidViInt16Range ( configParamValue, 10, 300))
				return VI_ERROR_PARAMETER3;
			Fmt(writeBuffer,"ADMD %i\r\n", configParamValue);
			break;
	}
	writeCnt = NumFmtdBytes();
	// write a command to the instrument
	if ((TP04310_status = viWrite (instrumentHandle, writeBuffer, writeCnt, &retCnt)) < 0)
        return TP04310_status;
	
    return TP04310_status; 
}

ViStatus _VI_FUNC TP04310_read_config_parameter (ViSession instrumentHandle,
                                                 ViInt16 configParamID,
                                                 ViInt16 *configParamValue)
{
    ViStatus TP04310_status = VI_SUCCESS;
	ViChar writeBuffer[BUFFER_SIZE] = {0};
    ViByte rdBuffer[BUFFER_SIZE] = {0};
    ViUInt32 writeCnt = 0,
		     retCnt = 0;
	
    // build a querry string to send to the instrument 
	switch (configParamID)
	{
		default:	
			break;
		case TP04310_CONFIG_CYCLE_COUNT:
			Fmt(writeBuffer,"CYCC?\r\n");
			break;
		case TP04310_CONFIG_SHUTDOWN_TIMER:
			Fmt(writeBuffer,"STIM?\r\n");
		    break;
    	case TP04310_CONFIG_TEST_TIME:
			Fmt(writeBuffer,"TTIM?\r\n");
			break;
		case TP04310_CONFIG_DUT_SENSOR_TYPE:
			Fmt(writeBuffer,"DSNS?\r\n");
			break;
		case TP04310_CONFIG_DUT_THERMAL_CONSTANT:
			Fmt(writeBuffer,"DUTC?\r\n");
			break;
		case TP04310_CONFIG_DUT_MODE:
			Fmt(writeBuffer,"DUTM?\r\n");
			break;
		case TP04310_CONFIG_AIR_LOW_TEMP_LIMIT:
			Fmt(writeBuffer,"LLIM?\r\n");
			break;
		case TP04310_CONFIG_AIR_HIGH_TEMP_LIMIT:
			Fmt(writeBuffer,"ULIM?\r\n");
			break;
		case TP04310_CONFIG_AIR_TO_DUT_MAX_DIFFERENCE:
			Fmt(writeBuffer,"ADMD?\r\n");
			break;
	}
	writeCnt = NumFmtdBytes();
	
    // write a querry to the instrument  
	if ((TP04310_status = viWrite (instrumentHandle, writeBuffer, writeCnt, &retCnt)) < 0)
        return TP04310_status;

	// read the instrument response
    if ((TP04310_status = viRead (instrumentHandle, rdBuffer, BUFFER_SIZE, &retCnt)) < 0)
        return TP04310_status;
	
	// parse the instrument response 
	Scan(rdBuffer,"%s>%d[b2]", configParamValue);
	
	// check the Scan parameters for a proper range
    switch (configParamID)
	{
		default:	
			break;
		case TP04310_CONFIG_CYCLE_COUNT:
			if(TP04310_invalidViInt16Range (*configParamValue, 1, 9999))
				return VI_ERROR_INSTR_INTERPRETING_RESPONSE;
			break;
		case TP04310_CONFIG_SHUTDOWN_TIMER:
			if(TP04310_invalidViInt16Range (*configParamValue, 0, 1000))
				return VI_ERROR_INSTR_INTERPRETING_RESPONSE;
			break;
    	case TP04310_CONFIG_TEST_TIME:
			if(TP04310_invalidViInt16Range (*configParamValue, 0, 9999))
				return VI_ERROR_INSTR_INTERPRETING_RESPONSE;
			break;
		case TP04310_CONFIG_DUT_SENSOR_TYPE:
			if(TP04310_invalidViInt16Range (*configParamValue, 0, 2))
				return VI_ERROR_INSTR_INTERPRETING_RESPONSE;
			break;
		case TP04310_CONFIG_DUT_THERMAL_CONSTANT:
			if(TP04310_invalidViInt16Range (*configParamValue, 20, 500))
				return VI_ERROR_INSTR_INTERPRETING_RESPONSE;
			break;
		case TP04310_CONFIG_DUT_MODE:
			if(TP04310_invalidViInt16Range (*configParamValue, 0, 1))
				return VI_ERROR_INSTR_INTERPRETING_RESPONSE;
			break;
		case TP04310_CONFIG_AIR_LOW_TEMP_LIMIT:
			if(TP04310_invalidViInt16Range (*configParamValue, -99, 25))
				return VI_ERROR_INSTR_INTERPRETING_RESPONSE;
			break;
		case TP04310_CONFIG_AIR_HIGH_TEMP_LIMIT:
			if(TP04310_invalidViInt16Range (*configParamValue, 25, 225))
				return VI_ERROR_INSTR_INTERPRETING_RESPONSE;
			break;
		case TP04310_CONFIG_AIR_TO_DUT_MAX_DIFFERENCE:
			if(TP04310_invalidViInt16Range (*configParamValue, 10, 300))
				return VI_ERROR_INSTR_INTERPRETING_RESPONSE;
			break;
	}
	return TP04310_status;  
}

ViStatus _VI_FUNC TP04310_write_setpoint_info (ViSession instrumentHandle,
                                               ViInt16   setpNumber,
                                               ViReal64  setpTemperature,
                                               ViReal64  setpWindow,
                                               ViInt16   setpSoakTime,
                                               ViReal64  setpRampRate)
{
    ViStatus TP04310_status = VI_SUCCESS;
	ViChar writeBuffer[BUFFER_SIZE] = {0};
    ViUInt32 writeCnt = 0,
		     retCnt = 0;

	// check all the parameters for proper range
	if(TP04310_invalidViInt16Range (setpNumber, 0, 11) )
		return VI_ERROR_PARAMETER2;
	if(TP04310_invalidViReal64Range (setpTemperature, -99.9, 225.0 ) )
		return VI_ERROR_PARAMETER3;
	if(TP04310_invalidViReal64Range (setpWindow, 0.1, 9.9) )
		return VI_ERROR_PARAMETER4;
	if(TP04310_invalidViInt16Range  (setpSoakTime, 0, 9999) )
		return VI_ERROR_PARAMETER5;
	if(TP04310_invalidViReal64Range ( setpRampRate, 0.0, 9999.9) )
		return VI_ERROR_PARAMETER6;
	
	// build a string of multiple commands to send to the instrument
	Fmt(writeBuffer, "%s<SETN %i;SETP %f;WNDW %f;SOAK %i;RAMP %f\r\n", 
		                         setpNumber,
								 setpTemperature,
								 setpWindow,
								 setpSoakTime,
								 setpRampRate);
	writeCnt = NumFmtdBytes();
	// send multiple commands
	if ((TP04310_status = viWrite (instrumentHandle, writeBuffer, writeCnt, &retCnt)) < 0)
	    return TP04310_status;
	
	return TP04310_status;  
}

ViStatus _VI_FUNC TP04310_read_setpoint_info (ViSession instrumentHandle,
                                              ViInt16  _VI_FAR *setpNumber,
                                              ViReal64 _VI_FAR *setpTemperature,
                                              ViReal64 _VI_FAR *setpWindow,
                                              ViInt16  _VI_FAR *setpSoakTime,
                                              ViReal64 _VI_FAR *setpRampRate)
{
    ViStatus TP04310_status = VI_SUCCESS;
	ViChar rdBuffer[BUFFER_SIZE] = {0};
	ViChar writeBuffer[BUFFER_SIZE] = {0};
	ViUInt32 writeCnt = 0,
		     retCnt = 0;
	

    // build a string of multiple querries to send to the instrument    
	Fmt(writeBuffer, "SETN?;SETP?;WNDW?;SOAK?;RAMP?\r\n");
	writeCnt = NumFmtdBytes();
	
	// send multiple command querries
	if ((TP04310_status = viWrite (instrumentHandle, writeBuffer, writeCnt, &retCnt)) < 0)
	    return TP04310_status;
	
	// read the instrument response
    if ((TP04310_status = viRead (instrumentHandle, rdBuffer, BUFFER_SIZE, &retCnt)) < 0)
        return TP04310_status;
	
	// parse the instrument response 
	Scan(rdBuffer,"%s>%d[b2];%f[b8];%f[b8];%d[b2];%f[b8]", 
		                                            setpNumber, 
													setpTemperature,
													setpWindow,
													setpSoakTime,
													setpRampRate);
	
    // check the Scan parameters for a proper range
	if( TP04310_invalidViInt16Range      (*setpNumber, 0, 11) || 
			TP04310_invalidViReal64Range (*setpTemperature, -99.9, 225.0)||
			TP04310_invalidViReal64Range (*setpWindow, 0.1, 9.9) ||
			TP04310_invalidViInt16Range  (*setpSoakTime, 0, 9999) ||
			TP04310_invalidViReal64Range (*setpRampRate, 0.0, 9999.0) )
		return VI_ERROR_INSTR_INTERPRETING_RESPONSE;
	
	return TP04310_status;  
}

ViStatus _VI_FUNC TP04310_write_setpoint_number (ViSession instrumentHandle,
                                                 ViInt16 setpNumber)
{
    ViStatus TP04310_status = VI_SUCCESS;
	ViChar writeBuffer[BUFFER_SIZE] = {0};
	ViUInt32 writeCnt = 0,
		     retCnt = 0;

	// check all the parameters for proper range
	if(TP04310_invalidViInt16Range (setpNumber, 0, 11) )
		return VI_ERROR_PARAMETER2;
	
	// build a command string to send to the instrument
	Fmt(writeBuffer, "SETN %i\r\n", setpNumber);
	writeCnt = NumFmtdBytes();
	
	// write the command to the instrument
	if ((TP04310_status = viWrite (instrumentHandle, writeBuffer, writeCnt, &retCnt)) < 0)
	    return TP04310_status;
    
	return TP04310_status;
}

ViStatus _VI_FUNC TP04310_read_setpoint_number (ViSession instrumentHandle,
                                                ViInt16 _VI_FAR *setpNumber)
{
    ViStatus TP04310_status = VI_SUCCESS;
	ViChar rdBuffer[BUFFER_SIZE] = {0};
	ViChar writeBuffer[BUFFER_SIZE] = {0};
	ViUInt32 writeCnt = 0,
		     retCnt = 0;
	
	// build a querry string to send to the instrument 
	Fmt(writeBuffer, "SETN?\r\n");
	writeCnt = NumFmtdBytes();
	
	// write querry to the instrument
	if ((TP04310_status = viWrite (instrumentHandle, writeBuffer, writeCnt, &retCnt)) < 0)
	    return TP04310_status;
	
	// read the instrument response
    if ((TP04310_status = viRead (instrumentHandle, rdBuffer, BUFFER_SIZE, &retCnt)) < 0)
        return TP04310_status;
	
	// parse the instrument response
	Scan(rdBuffer,"%s>%d[b2]", setpNumber);
	
    // check the Scan parameters for a proper range
	if(TP04310_invalidViInt16Range (*setpNumber, 0, 11) )
		return VI_ERROR_INSTR_INTERPRETING_RESPONSE;
	
	return TP04310_status;
}

ViStatus _VI_FUNC TP04310_write_setpoint_temperature (ViSession instrumentHandle,
                                                      ViReal64 setpTemperature)
{
    ViStatus TP04310_status = VI_SUCCESS;
	ViChar writeBuffer[BUFFER_SIZE] = {0};
    ViUInt32 writeCnt = 0,
		     retCnt = 0;

	// check all the parameters for proper range
	if(TP04310_invalidViReal64Range ( setpTemperature, -99.9, 225.0 ) )
		return VI_ERROR_PARAMETER2;

	// build a command to send to the instrument
	Fmt(writeBuffer, "SETP %f\r\n", setpTemperature);
	writeCnt = NumFmtdBytes();
	
	// send a command
	if ((TP04310_status = viWrite (instrumentHandle, writeBuffer, writeCnt, &retCnt)) < 0)
	    return TP04310_status;
	
	return TP04310_status;      
}

ViStatus _VI_FUNC TP04310_read_setpoint_temperature (ViSession instrumentHandle,
                                                     ViReal64 _VI_FAR *setpTemperature)
{
    ViStatus TP04310_status = VI_SUCCESS;
	ViChar rdBuffer[BUFFER_SIZE] = {0};
	ViChar writeBuffer[BUFFER_SIZE] = {0};
	ViUInt32 writeCnt = 0,
		     retCnt = 0;
	
	// build a querry string to send to the instrument 
	Fmt(writeBuffer, "SETP?\r\n");
	writeCnt = NumFmtdBytes();
	
	// write querry to the instrument
	if ((TP04310_status = viWrite (instrumentHandle, writeBuffer, writeCnt, &retCnt)) < 0)
	    return TP04310_status;
	
	// read the instrument response
    if ((TP04310_status = viRead (instrumentHandle, rdBuffer, BUFFER_SIZE, &retCnt)) < 0)
        return TP04310_status;
	
	// parse the instrument response
	Scan(rdBuffer,"%s>%f[b8]", setpTemperature);
	
    // check the Scan parameters for a proper range
	if(TP04310_invalidViReal64Range ( *setpTemperature, -99.9, 225.0 ) )
		return VI_ERROR_INSTR_INTERPRETING_RESPONSE;

	return TP04310_status;    
}

ViStatus _VI_FUNC TP04310_write_setpoint_window (ViSession instrumentHandle,
                                                 ViReal64 setpWindow)
{
    ViStatus TP04310_status = VI_SUCCESS;
	ViChar writeBuffer[BUFFER_SIZE] = {0};
    ViUInt32 writeCnt = 0,
		     retCnt = 0;

	// check all the parameters for proper range
	if(TP04310_invalidViReal64Range ( setpWindow, 0.1, 9.9 ) )
		return VI_ERROR_PARAMETER2;

	// build a command to send to the instrument
	Fmt(writeBuffer, "WNDW %f\r\n", setpWindow);
	writeCnt = NumFmtdBytes();
	
	// send a command
	if ((TP04310_status = viWrite (instrumentHandle, writeBuffer, writeCnt, &retCnt)) < 0)
	    return TP04310_status;
	
	return TP04310_status;    
}

ViStatus _VI_FUNC TP04310_read_setpoint_window (ViSession instrumentHandle,
                                                ViReal64 _VI_FAR *setpWindow)
{
    ViStatus TP04310_status = VI_SUCCESS;
	ViChar rdBuffer[BUFFER_SIZE] = {0};
	ViChar writeBuffer[BUFFER_SIZE] = {0};
	ViUInt32 writeCnt = 0,
		     retCnt = 0;
	
	// build a querry string to send to the instrument 
	Fmt(writeBuffer, "WNDW?\r\n");
	writeCnt = NumFmtdBytes();
	
	// write querry to the instrument
	if ((TP04310_status = viWrite (instrumentHandle, writeBuffer, writeCnt, &retCnt)) < 0)
	    return TP04310_status;
	
	// read the instrument response
    if ((TP04310_status = viRead (instrumentHandle, rdBuffer, BUFFER_SIZE, &retCnt)) < 0)
        return TP04310_status;
	
	// parse the instrument response
	Scan(rdBuffer,"%s>%f[b8]", setpWindow);
	
    // check the Scan parameters for a proper range
	if(TP04310_invalidViReal64Range ( *setpWindow, 0.1, 9.9 ) )
		return VI_ERROR_INSTR_INTERPRETING_RESPONSE;

	return TP04310_status;    
}

ViStatus _VI_FUNC TP04310_write_setpoint_soak (ViSession instrumentHandle,
                                               ViInt16 setpSoak)
{
    ViStatus TP04310_status = VI_SUCCESS;
	ViChar writeBuffer[BUFFER_SIZE] = {0};
    ViUInt32 writeCnt = 0,
		     retCnt = 0;

	// check all the parameters for proper range
	if(TP04310_invalidViInt16Range ( setpSoak, 0, 9999 ) )
		return VI_ERROR_PARAMETER2;

	// build a command to send to the instrument
	Fmt(writeBuffer, "SOAK %i\r\n", setpSoak);
	writeCnt = NumFmtdBytes();
	
	// send a command
	if ((TP04310_status = viWrite (instrumentHandle, writeBuffer, writeCnt, &retCnt)) < 0)
	    return TP04310_status;
	
	return TP04310_status;    
}

ViStatus _VI_FUNC TP04310_read_setpoint_soak (ViSession instrumentHandle,
                                              ViInt16 _VI_FAR *setpSoak)
{
    ViStatus TP04310_status = VI_SUCCESS;
	ViChar rdBuffer[BUFFER_SIZE] = {0};
	ViChar writeBuffer[BUFFER_SIZE] = {0};
	ViUInt32 writeCnt = 0,
		     retCnt = 0;
	
	// build a querry string to send to the instrument 
	Fmt(writeBuffer, "SOAK?\r\n");
	writeCnt = NumFmtdBytes();
	
	// write querry to the instrument
	if ((TP04310_status = viWrite (instrumentHandle, writeBuffer, writeCnt, &retCnt)) < 0)
	    return TP04310_status;
	
	// read the instrument response
    if ((TP04310_status = viRead (instrumentHandle, rdBuffer, BUFFER_SIZE, &retCnt)) < 0)
        return TP04310_status;
	
	// parse the instrument response
	Scan(rdBuffer,"%s>%d[b2]", setpSoak);
	
    // check the Scan parameters for a proper range
	if(TP04310_invalidViInt16Range ( *setpSoak, 0, 9999 ) )
		return VI_ERROR_INSTR_INTERPRETING_RESPONSE;

	return TP04310_status;    
}

ViStatus _VI_FUNC TP04310_write_setpoint_ramp (ViSession instrumentHandle,
                                               ViReal64 setpRamp)
{
    ViStatus TP04310_status = VI_SUCCESS;
	ViChar writeBuffer[BUFFER_SIZE] = {0};
    ViUInt32 writeCnt = 0,
		     retCnt = 0;

	// check all the parameters for proper range
	if(TP04310_invalidViReal64Range ( setpRamp, 0.0, 9999.9 ) )
		return VI_ERROR_PARAMETER2;

	// build a command to send to the instrument
	Fmt(writeBuffer, "RAMP %f\r\n", setpRamp);
	writeCnt = NumFmtdBytes();
	
	// send a command
	if ((TP04310_status = viWrite (instrumentHandle, writeBuffer, writeCnt, &retCnt)) < 0)
	    return TP04310_status;
	
	return TP04310_status;    
}

ViStatus _VI_FUNC TP04310_read_setpoint_ramp (ViSession instrumentHandle,
                                              ViReal64 _VI_FAR *setpRamp)
{
    ViStatus TP04310_status = VI_SUCCESS;
	ViChar rdBuffer[BUFFER_SIZE] = {0};
	ViChar writeBuffer[BUFFER_SIZE] = {0};
	ViUInt32 writeCnt = 0,
		     retCnt = 0;
	
	// build a querry string to send to the instrument 
	Fmt(writeBuffer, "RAMP?\r\n");
	writeCnt = NumFmtdBytes();
	
	// write querry to the instrument
	if ((TP04310_status = viWrite (instrumentHandle, writeBuffer, writeCnt, &retCnt)) < 0)
	    return TP04310_status;
	
	// read the instrument response
    if ((TP04310_status = viRead (instrumentHandle, rdBuffer, BUFFER_SIZE, &retCnt)) < 0)
        return TP04310_status;
	
	// parse the instrument response
	Scan(rdBuffer,"%s>%f[b8]", setpRamp);
	
    // check the Scan parameters for a proper range
	if(TP04310_invalidViReal64Range ( *setpRamp, 0.0, 9999.0 ) )
		return VI_ERROR_INSTR_INTERPRETING_RESPONSE;

	return TP04310_status;    
}

ViStatus _VI_FUNC TP04310_load_setup_file (ViSession instrumentHandle,
                                           ViInt16 setupFile)
{
    ViStatus TP04310_status = VI_SUCCESS;
	ViChar writeBuffer[BUFFER_SIZE] = {0};
	ViUInt32 writeCnt = 0,
		     retCnt = 0;

    // check all the parameters for proper range
	if(TP04310_invalidViInt16Range ( setupFile, 1, 12 ) )
		return VI_ERROR_PARAMETER2;

	
	// build a command string to send to the instrument
	Fmt(writeBuffer, "SFIL %d\r\n", setupFile);
	writeCnt = NumFmtdBytes();
	
	// write the command to the instrument
	if ((TP04310_status = viWrite (instrumentHandle, writeBuffer, writeCnt, &retCnt)) < 0)
	    return TP04310_status;
    
	return TP04310_status;
}


ViStatus _VI_FUNC TP04310_save_setup (ViSession instrumentHandle,
                                      ViInt16 setupFile)
{
    ViStatus TP04310_status = VI_SUCCESS;
	ViChar writeBuffer[BUFFER_SIZE] = {0};
	ViUInt32 writeCnt = 0,
		     retCnt = 0;

	// check all the parameters for proper range
	if(TP04310_invalidViInt16Range ( setupFile, 1, 12 ) )
		return VI_ERROR_PARAMETER2;

	// build a command string to send to the instrument
	Fmt(writeBuffer, "CFIL %d\r\n", setupFile);
	writeCnt = NumFmtdBytes();
	
	// write command to the instrument
	if ((TP04310_status = viWrite (instrumentHandle, writeBuffer, writeCnt, &retCnt)) < 0)
	    return TP04310_status;
	
	return TP04310_status;    
}

ViStatus _VI_FUNC TP04310_read_SRE (ViSession instrumentHandle,
                                    ViInt16 *SRE_register)
{
    ViStatus TP04310_status = VI_SUCCESS;
	ViChar rdBuffer[BUFFER_SIZE] = {0};
	ViChar writeBuffer[BUFFER_SIZE] = {0};
	ViUInt32 writeCnt = 0,
		     retCnt = 0;
	
	// build a querry string to send to the instrument 
	Fmt(writeBuffer, "*SRE?\r\n");
	writeCnt = NumFmtdBytes();
	
	// write querry to the instrument
	if ((TP04310_status = viWrite (instrumentHandle, writeBuffer, writeCnt, &retCnt)) < 0)
	    return TP04310_status;
	
	// read the instrument response
    if ((TP04310_status = viRead (instrumentHandle, rdBuffer, BUFFER_SIZE, &retCnt)) < 0)
        return TP04310_status;
	
	// parse the instrument response
	Scan(rdBuffer,"%s>%d[b2]", SRE_register);
	
    // check the Scan parameters for a proper range
	if(TP04310_invalidViInt16Range ( *SRE_register, 0, 0xFF ) )
		return VI_ERROR_INSTR_INTERPRETING_RESPONSE;

	return TP04310_status;    
}

ViStatus _VI_FUNC TP04310_write_SRE (ViSession instrumentHandle,
                                     ViInt16 SRE_register)
{
    ViStatus TP04310_status = VI_SUCCESS;
	ViChar writeBuffer[BUFFER_SIZE] = {0};
	ViUInt32 writeCnt = 0,
		     retCnt = 0;

	// check all the parameters for proper range
	if( TP04310_invalidViInt16Range (SRE_register, 0, 0xFF) )
		return VI_ERROR_PARAMETER2;
	
	// build a command string to send to the instrument
	Fmt(writeBuffer, "*SRE %i\r\n", SRE_register);
	writeCnt = NumFmtdBytes();
	
	// write the command to the instrument
	if ((TP04310_status = viWrite (instrumentHandle, writeBuffer, writeCnt, &retCnt)) < 0)
	    return TP04310_status;
    
	return TP04310_status;    
}

ViStatus _VI_FUNC TP04310_read_TESE (ViSession instrumentHandle,
                                     ViInt16 *TESE_register)
{
    ViStatus TP04310_status = VI_SUCCESS;
	ViChar rdBuffer[BUFFER_SIZE] = {0};
	ViChar writeBuffer[BUFFER_SIZE] = {0};
	ViUInt32 writeCnt = 0,
		     retCnt = 0;
	
	// build a querry string to send to the instrument 
	Fmt(writeBuffer, "TESE?\r\n");
	writeCnt = NumFmtdBytes();
	
	// write querry to the instrument
	if ((TP04310_status = viWrite (instrumentHandle, writeBuffer, writeCnt, &retCnt)) < 0)
	    return TP04310_status;
	
	// read the instrument response
    if ((TP04310_status = viRead (instrumentHandle, rdBuffer, BUFFER_SIZE, &retCnt)) < 0)
        return TP04310_status;
	
	// parse the instrument response
	Scan(rdBuffer,"%s>%d[b2]", TESE_register);
	
    // check the Scan parameters for a proper range
	if(TP04310_invalidViInt16Range ( *TESE_register, 0, 0xFF ) )
		return VI_ERROR_INSTR_INTERPRETING_RESPONSE;

	return TP04310_status;    
}

ViStatus _VI_FUNC TP04310_write_TESE (ViSession instrumentHandle,
                                      ViInt16 TESE_register)
{
    ViStatus TP04310_status = VI_SUCCESS;
	ViChar writeBuffer[BUFFER_SIZE] = {0};
	ViUInt32 writeCnt = 0,
		     retCnt = 0;

	// check all the parameters for proper range
	if( TP04310_invalidViInt16Range (TESE_register, 0, 0xFF) )
		return VI_ERROR_PARAMETER2;
	
	// build a command string to send to the instrument
	Fmt(writeBuffer, "TESE %i\r\n", TESE_register);
	writeCnt = NumFmtdBytes();
	
	// write the command to the instrument
	if ((TP04310_status = viWrite (instrumentHandle, writeBuffer, writeCnt, &retCnt)) < 0)
	    return TP04310_status;
    
	return TP04310_status;    
}

ViStatus _VI_FUNC TP04310_read_ESE (ViSession instrumentHandle,
                                    ViInt16 *ESE_register)
{
    ViStatus TP04310_status = VI_SUCCESS;
	ViChar rdBuffer[BUFFER_SIZE] = {0};
	ViChar writeBuffer[BUFFER_SIZE] = {0};
	ViUInt32 writeCnt = 0,
		     retCnt = 0;
	
	// build a querry string to send to the instrument 
	Fmt(writeBuffer, "*ESE?\r\n");
	writeCnt = NumFmtdBytes();
	
	// write querry to the instrument
	if ((TP04310_status = viWrite (instrumentHandle, writeBuffer, writeCnt, &retCnt)) < 0)
	    return TP04310_status;
	
	// read the instrument response
    if ((TP04310_status = viRead (instrumentHandle, rdBuffer, BUFFER_SIZE, &retCnt)) < 0)
        return TP04310_status;
	
	// parse the instrument response
	Scan(rdBuffer,"%s>%d[b2]", ESE_register);
	
    // check the Scan parameters for a proper range
	if(TP04310_invalidViInt16Range ( *ESE_register, 0, 0xFF ) )
		return VI_ERROR_INSTR_INTERPRETING_RESPONSE;

	return TP04310_status;    
}

ViStatus _VI_FUNC TP04310_write_ESE (ViSession instrumentHandle,
                                     ViInt16 ESE_register)
{
    ViStatus TP04310_status = VI_SUCCESS;
	ViChar writeBuffer[BUFFER_SIZE] = {0};
	ViUInt32 writeCnt = 0,
		     retCnt = 0;

	// check all the parameters for proper range
	if( TP04310_invalidViInt16Range (ESE_register, 0, 0xFF) )
		return VI_ERROR_PARAMETER2;
	
	// build a command string to send to the instrument
	Fmt(writeBuffer, "*ESE %i\r\n", ESE_register);
	writeCnt = NumFmtdBytes();
	
	// write the command to the instrument
	if ((TP04310_status = viWrite (instrumentHandle, writeBuffer, writeCnt, &retCnt)) < 0)
	    return TP04310_status;
    
	return TP04310_status;    
}

ViStatus _VI_FUNC TP04310_cycle (ViSession instrumentHandle,
                                        ViInt16 startStopCycling)
{
    ViStatus TP04310_status = VI_SUCCESS;
	ViChar writeBuffer[BUFFER_SIZE] = {0};
	ViUInt32 writeCnt = 0,
		     retCnt = 0;

	// check all the parameters for proper range
	if( TP04310_invalidViInt16Range (startStopCycling, 0, 1) )
		return VI_ERROR_PARAMETER2;
	
	// build a command string to send to the instrument
	if (startStopCycling == 1)
		Fmt(writeBuffer, "RMPC 1; CYCL 1\r\n");
	else 
		Fmt(writeBuffer, "CYCL 0\r\n");
	writeCnt = NumFmtdBytes();
	
	// write the command to the instrument
	if ((TP04310_status = viWrite (instrumentHandle, writeBuffer, writeCnt, &retCnt)) < 0)
	    return TP04310_status;
    
	return TP04310_status;    
}

ViStatus _VI_FUNC TP04310_cycle_query (ViSession instrumentHandle,
                                       ViInt16 _VI_FAR *cyclingStatus)
{
    ViStatus TP04310_status = VI_SUCCESS;
	ViChar rdBuffer[BUFFER_SIZE] = {0};
	ViChar writeBuffer[BUFFER_SIZE] = {0};
	ViUInt32 writeCnt = 0,
		     retCnt = 0;
	
	// build a querry string to send to the instrument 
	Fmt(writeBuffer, "CYCL?\r\n");
	writeCnt = NumFmtdBytes();
	
	// write querry to the instrument
	if ((TP04310_status = viWrite (instrumentHandle, writeBuffer, writeCnt, &retCnt)) < 0)
	    return TP04310_status;
	
	// read the instrument response
    if ((TP04310_status = viRead (instrumentHandle, rdBuffer, BUFFER_SIZE, &retCnt)) < 0)
        return TP04310_status;
	
	// parse the instrument response
	Scan(rdBuffer,"%s>%d[b2]", cyclingStatus);
	
    // check the Scan parameters for a proper range
	if(TP04310_invalidViInt16Range ( *cyclingStatus, 0, 9999 ) )
		return VI_ERROR_INSTR_INTERPRETING_RESPONSE;

	return TP04310_status;    
}

ViStatus _VI_FUNC TP04310_next_setpoint (ViSession instrumentHandle)
{
    ViStatus TP04310_status = VI_SUCCESS;
	ViChar writeBuffer[BUFFER_SIZE] = {0};
	ViUInt32 writeCnt = 0,
		     retCnt = 0;

	// build a command string to send to the instrument
	Fmt(writeBuffer, "NEXT\r\n");
	writeCnt = NumFmtdBytes();
	
	// write the command to the instrument
	if ((TP04310_status = viWrite (instrumentHandle, writeBuffer, writeCnt, &retCnt)) < 0)
	    return TP04310_status;
    
	return TP04310_status;    
}

ViStatus _VI_FUNC TP04310_read_STB (ViSession instrumentHandle,
                                    ViInt16 _VI_FAR *status_byte)
{
    ViStatus TP04310_status = VI_SUCCESS;
	ViChar rdBuffer[BUFFER_SIZE] = {0};
	ViChar writeBuffer[BUFFER_SIZE] = {0};
	ViUInt32 writeCnt = 0,
		     retCnt = 0;
	
	// build a querry string to send to the instrument 
	Fmt(writeBuffer, "*STB?\r\n");
	writeCnt = NumFmtdBytes();
	
	// write querry to the instrument
	if ((TP04310_status = viWrite (instrumentHandle, writeBuffer, writeCnt, &retCnt)) < 0)
	    return TP04310_status;
	
	// read the instrument response
    if ((TP04310_status = viRead (instrumentHandle, rdBuffer, BUFFER_SIZE, &retCnt)) < 0)
        return TP04310_status;
	
	// parse the instrument response
	Scan(rdBuffer,"%s>%d[b2]", status_byte);
	
    // check the Scan parameters for a proper range
	if(TP04310_invalidViInt16Range ( *status_byte, 0, 0xFF ) )
		return VI_ERROR_INSTR_INTERPRETING_RESPONSE;

	return TP04310_status;    
}

ViStatus _VI_FUNC TP04310_read_ESR (ViSession instrumentHandle,
                                    ViInt16 _VI_FAR *ESR_register)
{
    ViStatus TP04310_status = VI_SUCCESS;
	ViChar rdBuffer[BUFFER_SIZE] = {0};
	ViChar writeBuffer[BUFFER_SIZE] = {0};
	ViUInt32 writeCnt = 0,
		     retCnt = 0;
	
	// build a querry string to send to the instrument 
	Fmt(writeBuffer, "*ESR?\r\n");
	writeCnt = NumFmtdBytes();
	
	// write querry to the instrument
	if ((TP04310_status = viWrite (instrumentHandle, writeBuffer, writeCnt, &retCnt)) < 0)
	    return TP04310_status;
	
	// read the instrument response
    if ((TP04310_status = viRead (instrumentHandle, rdBuffer, BUFFER_SIZE, &retCnt)) < 0)
        return TP04310_status;
	
	// parse the instrument response
	Scan(rdBuffer,"%s>%d[b2]", ESR_register);
	
    // check the Scan parameters for a proper range
	if(TP04310_invalidViInt16Range ( *ESR_register, 0, 0xFF ) )
		return VI_ERROR_INSTR_INTERPRETING_RESPONSE;

	return TP04310_status;    
}

ViStatus _VI_FUNC TP04310_read_TESR (ViSession instrumentHandle,
                                     ViInt16 _VI_FAR *TESR_register)
{
    ViStatus TP04310_status = VI_SUCCESS;
	ViChar rdBuffer[BUFFER_SIZE] = {0};
	ViChar writeBuffer[BUFFER_SIZE] = {0};
	ViUInt32 writeCnt = 0,
		     retCnt = 0;
	
	// build a querry string to send to the instrument 
	Fmt(writeBuffer, "TESR?\r\n");
	writeCnt = NumFmtdBytes();
	
	// write querry to the instrument
	if ((TP04310_status = viWrite (instrumentHandle, writeBuffer, writeCnt, &retCnt)) < 0)
	    return TP04310_status;
	
	// read the instrument response
    if ((TP04310_status = viRead (instrumentHandle, rdBuffer, BUFFER_SIZE, &retCnt)) < 0)
        return TP04310_status;
	
	// parse the instrument response
	Scan(rdBuffer,"%s>%d[b2]", TESR_register);
	
    // check the Scan parameters for a proper range
	if(TP04310_invalidViInt16Range ( *TESR_register, 0, 0xFF ) )
		return VI_ERROR_INSTR_INTERPRETING_RESPONSE;

	return TP04310_status;    
}

ViStatus _VI_FUNC TP04310_read_TECR (ViSession instrumentHandle,
                                     ViInt16 _VI_FAR *TECR_register)
{
    ViStatus TP04310_status = VI_SUCCESS;
	ViChar rdBuffer[BUFFER_SIZE] = {0};
	ViChar writeBuffer[BUFFER_SIZE] = {0};
	ViUInt32 writeCnt = 0,
		     retCnt = 0;
	
	// build a querry string to send to the instrument 
	Fmt(writeBuffer, "TECR?\r\n");
	writeCnt = NumFmtdBytes();
	
	// write querry to the instrument
	if ((TP04310_status = viWrite (instrumentHandle, writeBuffer, writeCnt, &retCnt)) < 0)
	    return TP04310_status;
	
	// read the instrument response
    if ((TP04310_status = viRead (instrumentHandle, rdBuffer, BUFFER_SIZE, &retCnt)) < 0)
        return TP04310_status;
	
	// parse the instrument response
	Scan(rdBuffer,"%s>%d[b2]", TECR_register);
	
    // check the Scan parameters for a proper range
	if(TP04310_invalidViInt16Range ( *TECR_register, 0, 0xFF ) )
		return VI_ERROR_INSTR_INTERPRETING_RESPONSE;

	return TP04310_status;    
}

ViStatus _VI_FUNC TP04310_read_AUXC (ViSession instrumentHandle,
                                     ViInt16 _VI_FAR *auxc_register)
{
    ViStatus TP04310_status = VI_SUCCESS;
	ViChar rdBuffer[BUFFER_SIZE] = {0};
	ViChar writeBuffer[BUFFER_SIZE] = {0};
	ViUInt32 writeCnt = 0,
		     retCnt = 0;
	
	// build a querry string to send to the instrument 
	Fmt(writeBuffer, "AUXC?\r\n");
	writeCnt = NumFmtdBytes();
	
	// write querry to the instrument
	if ((TP04310_status = viWrite (instrumentHandle, writeBuffer, writeCnt, &retCnt)) < 0)
	    return TP04310_status;
	
	// read the instrument response
    if ((TP04310_status = viRead (instrumentHandle, rdBuffer, BUFFER_SIZE, &retCnt)) < 0)
        return TP04310_status;
	
	// parse the instrument response
	Scan(rdBuffer,"%s>%d[b2]", auxc_register);
	
    // check the Scan parameters for a proper range
	if(TP04310_invalidViInt16Range ( *auxc_register, 0, 0xFFFF ) )
		return VI_ERROR_INSTR_INTERPRETING_RESPONSE;

	return TP04310_status;    
}

ViStatus _VI_FUNC TP04310_read_air_flow_scfm (ViSession instrumentHandle,
                                              ViReal64 *currentAirFlow_scfm)
{
    ViStatus TP04310_status = VI_SUCCESS;
	ViChar rdBuffer[BUFFER_SIZE] = {0};
	ViChar writeBuffer[BUFFER_SIZE] = {0};
	ViUInt32 writeCnt = 0,
		     retCnt = 0;
	
	// build a querry string to send to the instrument 
	Fmt(writeBuffer, "FLWR?\r\n");
	writeCnt = NumFmtdBytes();
	
	// write querry to the instrument
	if ((TP04310_status = viWrite (instrumentHandle, writeBuffer, writeCnt, &retCnt)) < 0)
	    return TP04310_status;
	
	// read the instrument response
    if ((TP04310_status = viRead (instrumentHandle, rdBuffer, BUFFER_SIZE, &retCnt)) < 0)
        return TP04310_status;
	
	// parse the instrument response
	Scan(rdBuffer,"%s>%f[b8]", currentAirFlow_scfm);
	
    // check the Scan parameters for a proper range
	if(TP04310_invalidViReal64Range ( *currentAirFlow_scfm, 0.0, 25.0 ) )
		return VI_ERROR_INSTR_INTERPRETING_RESPONSE;

	return TP04310_status;  
}

ViStatus _VI_FUNC TP04310_read_air_flow_lites_per_sec (ViSession instrumentHandle,
                                                       ViReal64 _VI_FAR *currentAirFlow_l_s)
{
    ViStatus TP04310_status = VI_SUCCESS;
	ViChar rdBuffer[BUFFER_SIZE] = {0};
	ViChar writeBuffer[BUFFER_SIZE] = {0};
	ViUInt32 writeCnt = 0,
		     retCnt = 0;
	
	// build a querry string to send to the instrument 
	Fmt(writeBuffer, "FLRL?\r\n");
	writeCnt = NumFmtdBytes();
	
	// write querry to the instrument
	if ((TP04310_status = viWrite (instrumentHandle, writeBuffer, writeCnt, &retCnt)) < 0)
	    return TP04310_status;
	
	// read the instrument response
    if ((TP04310_status = viRead (instrumentHandle, rdBuffer, BUFFER_SIZE, &retCnt)) < 0)
        return TP04310_status;
	
	// parse the instrument response
	Scan(rdBuffer,"%s>%f[b8]", currentAirFlow_l_s);
	
    // check the Scan parameters for a proper range
	if(TP04310_invalidViReal64Range ( *currentAirFlow_l_s, 0.0, 12.0 ) )
		return VI_ERROR_INSTR_INTERPRETING_RESPONSE;

	return TP04310_status;    
}

ViStatus _VI_FUNC TP04310_read_dynamic_setpoint (ViSession instrumentHandle,
                                                 ViReal64 _VI_FAR *dynamicSetpoint)
{
    ViStatus TP04310_status = VI_SUCCESS;
	ViChar rdBuffer[BUFFER_SIZE] = {0};
	ViChar writeBuffer[BUFFER_SIZE] = {0};
	ViUInt32 writeCnt = 0,
		     retCnt = 0;
	
	// build a querry string to send to the instrument 
	Fmt(writeBuffer, "SETD?\r\n");
	writeCnt = NumFmtdBytes();
	
	// write querry to the instrument
	if ((TP04310_status = viWrite (instrumentHandle, writeBuffer, writeCnt, &retCnt)) < 0)
	    return TP04310_status;
	
	// read the instrument response
    if ((TP04310_status = viRead (instrumentHandle, rdBuffer, BUFFER_SIZE, &retCnt)) < 0)
        return TP04310_status;
	
	// parse the instrument response
	Scan(rdBuffer,"%s>%f[b8]", dynamicSetpoint);
	
    // check the Scan parameters for a proper range
	if(TP04310_invalidViReal64Range ( *dynamicSetpoint,-150.0, 225.0 ) )
		return VI_ERROR_INSTR_INTERPRETING_RESPONSE;

	return TP04310_status;  
}

ViStatus _VI_FUNC TP04310_read_control_temperature (ViSession instrumentHandle,
                                                    ViReal64 _VI_FAR *controlTemperature)
{
    ViStatus TP04310_status = VI_SUCCESS;
	ViChar rdBuffer[BUFFER_SIZE] = {0};
	ViChar writeBuffer[BUFFER_SIZE] = {0};
	ViUInt32 writeCnt = 0,
		     retCnt = 0;
	
	// build a querry string to send to the instrument 
	Fmt(writeBuffer, "TEMP?\r\n");
	writeCnt = NumFmtdBytes();
	
	// write querry to the instrument
	if ((TP04310_status = viWrite (instrumentHandle, writeBuffer, writeCnt, &retCnt)) < 0)
	    return TP04310_status;
	
	// read the instrument response
    if ((TP04310_status = viRead (instrumentHandle, rdBuffer, BUFFER_SIZE, &retCnt)) < 0)
        return TP04310_status;
	
	// parse the instrument response
	Scan(rdBuffer,"%s>%f[b8]", controlTemperature);
	
    // check the Scan parameters for a proper range
	if(TP04310_invalidViReal64Range ( *controlTemperature,-150.0, 250.0 ) )
		return VI_ERROR_INSTR_INTERPRETING_RESPONSE;

	return TP04310_status;  
}

ViStatus _VI_FUNC TP04310_read_air_temperature (ViSession instrumentHandle,
                                                ViReal64 *airTemperature)
{
    ViStatus TP04310_status = VI_SUCCESS;
	ViChar rdBuffer[BUFFER_SIZE] = {0};
	ViChar writeBuffer[BUFFER_SIZE] = {0};
	ViUInt32 writeCnt = 0,
		     retCnt = 0;
	
	// build a querry string to send to the instrument 
	Fmt(writeBuffer, "TMPA?\r\n");
	writeCnt = NumFmtdBytes();
	
	// write querry to the instrument
	if ((TP04310_status = viWrite (instrumentHandle, writeBuffer, writeCnt, &retCnt)) < 0)
	    return TP04310_status;
	
	// read the instrument response
    if ((TP04310_status = viRead (instrumentHandle, rdBuffer, BUFFER_SIZE, &retCnt)) < 0)
        return TP04310_status;
	
	// parse the instrument response
	Scan(rdBuffer,"%s>%f[b8]", airTemperature);
	
    // check the Scan parameters for a proper range
	if(TP04310_invalidViReal64Range ( *airTemperature,-150.0, 250.0 ) )
		return VI_ERROR_INSTR_INTERPRETING_RESPONSE;

	return TP04310_status;    
}

ViStatus _VI_FUNC TP04310_read_DUT_temperature (ViSession instrumentHandle,
                                                ViReal64 *DUTTemperature)
{
    ViStatus TP04310_status = VI_SUCCESS;
	ViChar rdBuffer[BUFFER_SIZE] = {0};
	ViChar writeBuffer[BUFFER_SIZE] = {0};
	ViUInt32 writeCnt = 0,
		     retCnt = 0;
	
	// build a querry string to send to the instrument 
	Fmt(writeBuffer, "TMPD?\r\n");
	writeCnt = NumFmtdBytes();
	
	// write querry to the instrument
	if ((TP04310_status = viWrite (instrumentHandle, writeBuffer, writeCnt, &retCnt)) < 0)
	    return TP04310_status;
	
	// read the instrument response
    if ((TP04310_status = viRead (instrumentHandle, rdBuffer, BUFFER_SIZE, &retCnt)) < 0)
        return TP04310_status;
	
	// if instrument replied "NaN" return an error
	if ((TP04310_status = CompareStrings(rdBuffer, 0, "NaN\r\n", 0, 1)) == 0)
		return VI_ERROR_INSTR_QUERY_ERROR;

	// parse the instrument response
	Scan(rdBuffer,"%s>%f[b8]", DUTTemperature);
	
    // check the Scan parameters for a proper range
	if(TP04310_invalidViReal64Range ( *DUTTemperature,-150.0, 250.0 ) )
		return VI_ERROR_INSTR_INTERPRETING_RESPONSE;

	return TP04310_status;    
}

/*===========================================================================*/
/* Function: Write To Instrument                                             */
/* Purpose:  This function writes a command string to the instrument.        */
/*===========================================================================*/
ViStatus _VI_FUNC TP04310_writeInstrData (ViSession instrumentHandle, ViString writeBuffer)
{
    ViStatus TP04310_status = VI_SUCCESS;
    ViChar wrBuffer[BUFFER_SIZE] = {0};
	ViUInt32 writeCnt = 0,
		     retCnt = 0;

	Fmt(wrBuffer, "%s\r\n", writeBuffer);
	writeCnt = NumFmtdBytes(); 
	if ((TP04310_status = viWrite (instrumentHandle, wrBuffer, writeCnt, &retCnt)) < 0)
        return TP04310_status;

    return TP04310_status;
}

/*===========================================================================*/
/* Function: Read Instrument Buffer                                          */
/* Purpose:  This function reads the output buffer of the instrument.        */
/*===========================================================================*/
ViStatus _VI_FUNC TP04310_readInstrData (ViSession instrSession, ViInt32 numberBytesToRead,
                    ViChar _VI_FAR readBuffer[], ViPInt32 numBytesRead)
{
    ViStatus TP04310_status = VI_SUCCESS;
    *numBytesRead = 0L;
        
    if ((TP04310_status = viRead (instrSession, readBuffer, numberBytesToRead, numBytesRead)) < 0)
        return TP04310_status;

    return TP04310_status;
}

/*===========================================================================*/
/* Function: Reset                                                           */
/* Purpose:  This function resets the instrument to the Cycle Screen.        */
/*===========================================================================*/
ViStatus _VI_FUNC TP04310_reset (ViSession instrumentHandle)
{
    ViUInt32 retCnt = 0;
    ViStatus TP04310_status = VI_SUCCESS;

    if ((TP04310_status = viWrite (instrumentHandle, "*RST\r\n", 6, &retCnt)) < 0)
        return TP04310_status;

    return TP04310_status;
}
/*===========================================================================*/
/* Function: Reset                                                           */
/* Purpose:  This function resets the instrument to the Operator Screen.     */
/*===========================================================================*/
ViStatus _VI_FUNC TP04310_reset_op_screen (ViSession instrumentHandle)
{
    ViUInt32 retCnt = 0;
    ViStatus TP04310_status = VI_SUCCESS;

    if ((TP04310_status = viWrite (instrumentHandle, "RSTO\r\n", 6, &retCnt)) < 0)
        return TP04310_status;

    return TP04310_status;
}

/*===========================================================================*/
/* Function: Device Clear                                                    */
/* Purpose:  This function clears the standard event status and temperature  */
/*           event status registers.                                         */
/*===========================================================================*/
ViStatus _VI_FUNC TP04310_device_clear (ViSession instrumentHandle)
{
    ViUInt32 retCnt = 0;
    ViStatus TP04310_status = VI_SUCCESS;

    if ((TP04310_status = viWrite (instrumentHandle, "*CLS\r\n", 6, &retCnt)) < 0)
        return TP04310_status;

    return TP04310_status;
}

/*===========================================================================*/
/* Function: Device Error Clear                                              */
/* Purpose:  This function clears device-specific errors.                    */ 
/*																			 */
/* Note:     After sending this command, wait 4 seconds before sending       */
/*           another command.                                                */
/*===========================================================================*/
ViStatus _VI_FUNC TP04310_device_error_clear (ViSession instrumentHandle)
{
    ViUInt32 retCnt = 0;
    ViStatus TP04310_status = VI_SUCCESS;

    if ((TP04310_status = viWrite (instrumentHandle, "CLER\r\n", 6, &retCnt)) < 0)
        return TP04310_status;

    return TP04310_status;
}

/*===========================================================================*/
/* Function: Self-Test                                                       */
/* Purpose:  This function executes the instrument self-test and returns     */
/*           the result.                                                     */
/*===========================================================================*/
ViStatus _VI_FUNC TP04310_selfTest (ViSession instrSession, ViInt16 _VI_FAR *testResult,
                    ViChar _VI_FAR testMessage[])
{
    ViStatus TP04310_status = VI_SUCCESS;
    ViByte rdBuffer[BUFFER_SIZE] = {0};
    ViUInt32 retCnt = 0;    	

	if ((TP04310_status = viWrite (instrSession, "*TST?\r\n", 7, &retCnt)) < 0)
        return TP04310_status;

    /*=====================================================================*/
    /* Test the test_message to see if a self-test error occurred. Assign  */
    /* the result to *test_result and return. Zero (0) means that the test */
    /* executed successfully any other number means selftest failed see    */
    /* control help for more details.                                      */
    /*=====================================================================*/
    if ((TP04310_status = viRead(instrSession, rdBuffer, BUFFER_SIZE,&retCnt)) < 0 )
		return TP04310_status;
	Scan (rdBuffer, "%d[b2]", testResult);
	if (*testResult == 0)
		Fmt(testMessage, "%s<%s", "Self-test executed successfully");
	else
		Fmt(testMessage, "%s<%s", "Self-test failed");        
    return TP04310_status;
}

/*===========================================================================*/
/* Function: Error Query                                                     */
/* Purpose:  This function queries the device-specific instrument error,     */
/*           and returns the result.                                         */
/*===========================================================================*/
ViStatus _VI_FUNC TP04310_errorQuery (ViSession instrSession, ViPInt32 errorCode,
                    ViChar _VI_FAR errorMessage[])
{
    ViStatus TP04310_status = VI_SUCCESS;
	ViByte rdBuffer[BUFFER_SIZE] = {0}; 
    TP04310_instrData instrPtr = NULL;

	ViUInt32 retCnt = 0;
	ViStatus status_code = 0;  // ViInt32

	if ((TP04310_status = viWrite (instrSession, "EROR?\r\n", 7, &retCnt)) < 0)
        return TP04310_status;

    if ((TP04310_status = viRead(instrSession, rdBuffer, BUFFER_SIZE, &retCnt)) < 0)
        return TP04310_status;

    Scan (rdBuffer, "%s>%d[b4]", errorCode);
	if (*errorCode > 0)
	{
		for (status_code = 0; status_code < 16; ++status_code)
			if ( (*errorCode & (1 << status_code)) != 0) 
				break;
	}
	else
	{
		*errorCode = 0;
		Fmt(errorMessage, "%s<%s", "No error");
		return TP04310_status; // no error 
	}
	
    if (TP04310_status = viGetAttribute (instrSession, VI_ATTR_USER_DATA, &instrPtr))
        return TP04310_status;
    
    if (instrPtr == NULL) 
        return TP04310_status;
	
	// 4300 compatible
	status_code += VI_ERROR_INSTR_OFFSET + 0xF0L + 0x01L;
	
	TP04310_errorMessage (instrSession, status_code, errorMessage);
	
    return TP04310_status;
}

/*===========================================================================*/
/* Function: Error Message                                                   */
/* Purpose:  This function translates the error return value from the        */
/*           instrument driver into a user-readable string.                  */
/*===========================================================================*/
ViStatus _VI_FUNC TP04310_errorMessage (ViSession instrSession, ViStatus statusCode,
                    ViChar _VI_FAR errMessage[])
{
    ViStatus TP04310_status = VI_SUCCESS;
    ViInt16 i;
    static TP04310_tStringValPair statusDescArray[] =
	{
        {VI_WARN_NSUP_ID_QUERY,     "WARNING: ID Query not supported"},
        {VI_WARN_NSUP_RESET,        "WARNING: Reset not supported"},
        {VI_WARN_NSUP_SELF_TEST,    "WARNING: Self-test not supported"},
        {VI_WARN_NSUP_ERROR_QUERY,  "WARNING: Error Query not supported"},     
        {VI_WARN_NSUP_REV_QUERY,    "WARNING: Revision Query not supported"},
        {VI_ERROR_PARAMETER1,   "ERROR: Parameter 1 out of range"},
        {VI_ERROR_PARAMETER2,   "ERROR: Parameter 2 out of range"},
        {VI_ERROR_PARAMETER3,   "ERROR: Parameter 3 out of range"},
        {VI_ERROR_PARAMETER4,   "ERROR: Parameter 4 out of range"},
        {VI_ERROR_PARAMETER5,   "ERROR: Parameter 5 out of range"},
        {VI_ERROR_PARAMETER6,   "ERROR: Parameter 6 out of range"},
        {VI_ERROR_PARAMETER7,   "ERROR: Parameter 7 out of range"},
        {VI_ERROR_PARAMETER8,   "ERROR: Parameter 8 out of range"},
        {VI_ERROR_FAIL_ID_QUERY,"ERROR: Identification query failed"},
        {VI_ERROR_INV_RESPONSE, "ERROR: Interpreting instrument response"},
        {VI_ERROR_INSTR_FILE_OPEN,    "ERROR: Opening the specified file"},
        {VI_ERROR_INSTR_FILE_WRITE,   "ERROR: Writing to the specified file"},
        {VI_ERROR_INSTR_INTERPRETING_RESPONSE, "ERROR: Interpreting the instrument's response"},
        {VI_ERROR_INSTR_PARAMETER9 ,  "ERROR: Parameter 9 out of range"},
        {VI_ERROR_INSTR_PARAMETER10,  "ERROR: Parameter 10 out of range"},
        {VI_ERROR_INSTR_PARAMETER11,  "ERROR: Parameter 11 out of range"},
        {VI_ERROR_INSTR_PARAMETER12,  "ERROR: Parameter 12 out of range"},
        {VI_ERROR_INSTR_PARAMETER13,  "ERROR: Parameter 13 out of range"},
        {VI_ERROR_INSTR_PARAMETER14,  "ERROR: Parameter 14 out of range"},
        {VI_ERROR_INSTR_PARAMETER15,  "ERROR: Parameter 15 out of range"},
                
        /*=CHANGE:=============================================================*/
        /* Insert instrument-specific error codes here.  Example:              */
        /*=====================================================================*/
        {TP04310_ERROR_INVALID_CONFIGURATION, "ERROR: Instrument configuration error"},
		
		{TP04310_EROR_OVERHEAT,            "ERROR: Overheat Failure"},
		{TP04310_EROR_AIR_OPEN_LOOP,       "ERROR: Air Temperature Open Loop Failure"},
		{TP04310_EROR_RESERVED_BIT2,       "ERROR: Reserved"},
		{TP04310_EROR_LOW_FLOW,            "ERROR: Low Air Flow Failure"},
		{TP04310_EROR_LOW_PRESSURE,        "ERROR: Low Input Air Pressure Failure"},
		{TP04310_EROR_AIR_SENSOR_OPEN,     "ERROR: Air Sensor Open Failure"},
		{TP04310_EROR_RESERVED_BIT6,       "ERROR: Reserved"},    
		{TP04310_EROR_INTERNAL_ERROR,      "ERROR: Internal Error"},
		{TP04310_EROR_RESERVED_BIT8,       "ERROR: Reserved"},
		{TP04310_EROR_FLOW_SENSOR_FAILURE, "ERROR: Flow Sensor Hardware Failure"},
		{TP04310_EROR_AC_ABSENT,           "ERROR: No Line Sense"},
		{TP04310_EROR_NVRAM_FAULT,         "ERROR: NVRAM Fault"},
		{TP04310_EROR_BVRAM_FAULT,         "ERROR: BVRAM Fault"},
		{TP04310_EROR_RESERVED_BIT13,      "ERROR: Reserved"},
		{TP04310_EROR_NO_DSNS_SELECTED,    "ERROR: No DUT Sensor Selected"},
		{TP04310_EROR_RESERVED_BIT15,      "ERROR: Reserved"},
        
        {VI_NULL, VI_NULL}
    };

    TP04310_status = viStatusDesc (instrSession, statusCode, errMessage);
    if (TP04310_status == VI_WARN_UNKNOWN_STATUS)
	{
        for (i = 0; statusDescArray[i].stringName; i++)
		{
            if (statusDescArray[i].stringVal == statusCode)
			{
                Fmt (errMessage, "%s<%s", statusDescArray[i].stringName);
                return (VI_SUCCESS);
            }
        }
        Fmt (errMessage, "%s<Unknown Error 0x%x[uw8p0]", statusCode);
        return (VI_WARN_UNKNOWN_STATUS);
    }
    
    TP04310_status = VI_SUCCESS;
    return TP04310_status;
}

/*===========================================================================*/
/* Function: Revision Query                                                  */
/* Purpose:  This function returns the driver and instrument revisions.      */
/*===========================================================================*/
ViStatus _VI_FUNC TP04310_revisionQuery (ViSession instrSession,
                    ViChar _VI_FAR driverRev[], ViChar _VI_FAR instrRev[])
{
    ViStatus TP04310_status = VI_SUCCESS;
	ViByte rdBuffer[BUFFER_SIZE] = {0}; 
	TP04310_instrData instrPtr = NULL;

	ViUInt32 retCnt = 0;


    if ((TP04310_status = viWrite (instrSession, "*IDN?\r\n", 7, &retCnt)) < 0)
        return TP04310_status;

    if ((TP04310_status = viRead(instrSession, rdBuffer, BUFFER_SIZE, &retCnt)) < 0)
        return TP04310_status;

	if (TP04310_status = viGetAttribute (instrSession, VI_ATTR_USER_DATA, &instrPtr))
        return TP04310_status;

    if ((TP04310_status = viSetAttribute (instrSession, VI_ATTR_USER_DATA, 
                        (ViUInt32)instrPtr)) < 0)
        return TP04310_status;   

	Fmt (instrRev, "%s<%s", rdBuffer);
    
    Fmt (driverRev, "%s<%s", TP04310_REVISION);
    
    return TP04310_status;
}

ViStatus _VI_FUNC TP04310_write_device_command (ViSession instrumentHandle,
                                                ViInt16 instrCmd,
                                                ViInt16 cmdArg)
{
    ViStatus TP04310_status = VI_SUCCESS;
	ViChar writeBuffer[BUFFER_SIZE] = {0};
    ViUInt32 writeCnt = 0,
		     retCnt = 0;
	// check all the parameters for proper range 
	if(TP04310_invalidViInt16Range ( instrCmd, 0, 2))
		return VI_ERROR_PARAMETER2;
	
	if(TP04310_invalidViInt16Range ( cmdArg, 0, 1))
		return VI_ERROR_PARAMETER3;
	
	// build a string to write to the instrument 
	switch (instrCmd)
	{
		default:	
			break;
		case TP04310_CMD_AIR:
			Fmt(writeBuffer,"FLOW %i\r\n",cmdArg);
			break;
		case TP04310_CMD_HEAD:
			Fmt(writeBuffer,"HEAD %i\r\n",cmdArg);
		    break;
		case TP04310_CMD_COMPRESSOR:
			Fmt(writeBuffer,"COOL %i\r\n",cmdArg);
			break;
	}
	writeCnt = NumFmtdBytes();
	// write a command to the instrument
	if ((TP04310_status = viWrite (instrumentHandle, writeBuffer, writeCnt, &retCnt)) < 0)
        return TP04310_status;
	
    return TP04310_status;    
}

ViStatus _VI_FUNC TP04310_read_device_state (ViSession instrumentHandle, ViInt16 instrCmd,
                                                ViInt16 _VI_FAR *cmdArg)
{
    ViStatus TP04310_status = VI_SUCCESS;
	ViChar writeBuffer[BUFFER_SIZE] = {0};
	ViChar rdBuffer[BUFFER_SIZE] = {0};
	
    ViUInt32 writeCnt = 0,
		     retCnt = 0;
	// check all the parameters for proper range 
	if(TP04310_invalidViInt16Range ( instrCmd, 0, 4))
		return VI_ERROR_PARAMETER2;
	
	// build a string to write to the instrument 
	switch (instrCmd)
	{
		default:	
			break;
		case TP04310_CMD_AIR:
			Fmt(writeBuffer,"FLOW?\r\n");
			break;
		case TP04310_CMD_HEAD:
			Fmt(writeBuffer,"HEAD?\r\n");
		    break;
		case TP04310_CMD_COMPRESSOR:
			Fmt(writeBuffer,"COOL?\r\n");
			break;
	}
	writeCnt = NumFmtdBytes();
	// write a command to the instrument
	if ((TP04310_status = viWrite (instrumentHandle, writeBuffer, writeCnt, &retCnt)) < 0)
        return TP04310_status;
	
	// read the instrument response
    if ((TP04310_status = viRead (instrumentHandle, rdBuffer, BUFFER_SIZE, &retCnt)) < 0)
        return TP04310_status;
	
	// parse the instrument response
	Scan(rdBuffer,"%s>%d[b2]", cmdArg);
	
    // check the Scan parameters for a proper range
	if(TP04310_invalidViInt16Range ( *cmdArg, 0, 1 ) )
		return VI_ERROR_INSTR_INTERPRETING_RESPONSE;

    return TP04310_status;    
}

/*===========================================================================*/
/* Function: Close                                                           */
/* Purpose:  This function closes the instrument.                            */
/*===========================================================================*/
ViStatus _VI_FUNC TP04310_close (ViSession instrSession)
{
    TP04310_instrData instrPtr = NULL;
    ViSession rmSession;
    ViStatus TP04310_status = VI_SUCCESS;

    if ((TP04310_status = viGetAttribute (instrSession, VI_ATTR_RM_SESSION, &rmSession)) < 0)
        return TP04310_status;
    if ((TP04310_status = viGetAttribute (instrSession, VI_ATTR_USER_DATA, &instrPtr)) < 0)
        return TP04310_status;
            
    if (instrPtr != NULL) 
        free (instrPtr);
    
    TP04310_status = viClose (instrSession);
    viClose (rmSession);

    return TP04310_status;
}

/*****************************************************************************/
/*= UTILITY ROUTINES (Non-Exportable Functions) =============================*/
/*****************************************************************************/

/*===========================================================================*/
/* Function: Boolean Value Out Of Range - ViBoolean                          */
/* Purpose:  This function checks a Boolean to see if it is equal to VI_TRUE */
/*           or VI_FALSE. If the value is out of range, the return value is  */
/*           VI_TRUE, otherwise the return value is VI_FALSE.                */
/*===========================================================================*/
ViBoolean TP04310_invalidViBooleanRange (ViBoolean val)
{
    return ((val != VI_FALSE && val != VI_TRUE) ? VI_TRUE : VI_FALSE);
}

/*===========================================================================*/
/* Function: Short Signed Integer Value Out Of Range - ViInt16               */
/* Purpose:  This function checks a short signed integer value to see if it  */  
/*           lies between a minimum and maximum value.  If the value is out  */
/*           of range, the return value is VI_TRUE, otherwise the return     */
/*           value is VI_FALSE.                                              */
/*===========================================================================*/
ViBoolean TP04310_invalidViInt16Range (ViInt16 val, ViInt16 min, ViInt16 max)
{
    return ((val < min || val > max) ? VI_TRUE : VI_FALSE);
}

/*===========================================================================*/
/* Function: Long Signed Integer Value Out Of Range - ViInt32                */
/* Purpose:  This function checks a long signed integer value to see if it   */  
/*           lies between a minimum and maximum value.  If the value is out  */
/*           of range, the return value is VI_TRUE, otherwise the return     */
/*           value is VI_FALSE.                                              */
/*===========================================================================*/
ViBoolean TP04310_invalidViInt32Range (ViInt32 val, ViInt32 min, ViInt32 max)
{
    return ((val < min || val > max) ? VI_TRUE : VI_FALSE);
}

/*===========================================================================*/
/* Function: Unsigned Char Value Out Of Range - ViUInt8                      */
/* Purpose:  This function checks an unsigned char value to see if it        */  
/*           lies between a minimum and maximum value.  If the value is out  */
/*           of range, the return value is VI_TRUE, otherwise the return     */
/*           value is VI_FALSE.                                              */
/*===========================================================================*/
ViBoolean TP04310_invalidViUInt8Range (ViUInt8 val, ViUInt8 min, ViUInt8 max)
{
    return ((val < min || val > max) ? VI_TRUE : VI_FALSE);
}

/*===========================================================================*/
/* Function: Short Unsigned Integer Value Out Of Range - ViUInt16            */
/* Purpose:  This function checks a short unsigned integer value to see if it*/  
/*           lies between a minimum and maximum value.  If the value is out  */
/*           of range, the return value is VI_TRUE, otherwise the return     */
/*           value is VI_FALSE.                                              */
/*===========================================================================*/
ViBoolean TP04310_invalidViUInt16Range (ViUInt16 val, ViUInt16 min, ViUInt16 max)
{
    return ((val < min || val > max) ? VI_TRUE : VI_FALSE);
}

/*===========================================================================*/
/* Function: Long Unsigned Integer Value Out Of Range - ViUInt32             */
/* Purpose:  This function checks a long unsigned integer value to see if it */  
/*           lies between a minimum and maximum value.  If the value is out  */
/*           of range, the return value is VI_TRUE, otherwise the return     */
/*           value is VI_FALSE.                                              */
/*===========================================================================*/
ViBoolean TP04310_invalidViUInt32Range (ViUInt32 val, ViUInt32 min, ViUInt32 max)
{
    return ((val < min || val > max) ? VI_TRUE : VI_FALSE);
}

/*===========================================================================*/
/* Function: Real (Float) Value Out Of Range - ViReal32                      */
/* Purpose:  This function checks a real (float) value to see if it lies     */  
/*           between a minimum and maximum value.  If the value is out of    */
/*           range, the return value is VI_TRUE, otherwise the return value  */
/*           is VI_FALSE.                                                    */
/*===========================================================================*/
ViBoolean TP04310_invalidViReal32Range (ViReal32 val, ViReal32 min, ViReal32 max)
{
    return ((val < min || val > max) ? VI_TRUE : VI_FALSE);
}

/*===========================================================================*/
/* Function: Real (Double) Value Out Of Range - ViReal64                     */
/* Purpose:  This function checks a real (double) value to see if it lies    */  
/*           between a minimum and maximum value.  If the value is out of    */
/*           range, the return value is VI_TRUE, otherwise the return value  */
/*           is VI_FALSE.                                                    */
/*===========================================================================*/
ViBoolean TP04310_invalidViReal64Range (ViReal64 val, ViReal64 min, ViReal64 max)
{
    return ((val < min || val > max) ? VI_TRUE : VI_FALSE);
}


/*================================================================================*/
/* Function: Wait On VISA Event                                                   */
/* Purpose:  This function waits for the occurrence of an enabled VISA Event. The */
/*           event type must be enabled before entering this function. Any        */
/*           programmatic commands, actions, or conditions, necessary to generate */
/*           the specified event type, must be satisified before entering this    */
/*           function. The function will wait for the specified timeout and then  */
/*           return. If the specified event is received then the function will    */
/*           return VI_SUCCESS (0), otherwise the status code for the generated   */
/*           error will be returned. In either case the function will disable the */
/*           event type and deallocate the event handle passed from viWaitOnEvent */
/*           before returning. WARNING: If VI_TMO_INFINITE is passed in as the    */
/*           timeout this function WILL NOT return until the specified event is   */
/*           received, if the event is not received the function will not return  */
/*           and it will be necessary to terminate CVI in order to regain control.*/
/*================================================================================*/
ViStatus TP04310_waitOnVisaEvent (ViSession instrSession, ViEventType eventTypeIn, 
            ViUInt32 timeoutIn, ViPUInt16 STB)
{            
    ViStatus TP04310_status = VI_SUCCESS, tempStatus = VI_SUCCESS;
    ViEventType eventTypeOut = 0;
    ViEvent eventHandle = 0;
    
    /* For debug purposes we want to be able to see the status returned by        */
    /* viDisableEvent and viClose if one of the internal functions fails but do   */
    /* not want to return that value as that is not where the initial error       */
    /* occurs in the function, so we assign it to tempStatus.                     */
    
    if ((TP04310_status = viWaitOnEvent (instrSession, eventTypeIn, timeoutIn, 
                                        &eventTypeOut, &eventHandle)) < 0) {
        tempStatus = viDisableEvent (instrSession, eventTypeIn, VI_QUEUE);
        return TP04310_status;
    } 
    
    if (eventTypeIn == VI_EVENT_SERVICE_REQ)
        if ((TP04310_status = viReadSTB (instrSession, STB)) < 0) {
            tempStatus = viClose (eventHandle);
            tempStatus = viDisableEvent (instrSession, eventTypeIn, VI_QUEUE);
            return TP04310_status;
        }   
        
    if ((TP04310_status = viClose (eventHandle)) < 0) {             
        tempStatus = viDisableEvent (instrSession, eventTypeIn, VI_QUEUE);
        return TP04310_status;                 
    }
    
    if ((TP04310_status = viDisableEvent (instrSession, eventTypeIn, VI_QUEUE)) < 0)
        return TP04310_status;                                                   

    return TP04310_status;                                    
}    

/*===========================================================================*/
/* Function: Initialize Clean Up                                             */
/* Purpose:  This function is used only by the TP04310_init function.  When   */
/*           an error is detected this function is called to close the       */
/*           open resource manager and instrument object sessions and to     */
/*           set the instrSession that is returned from TP04310_init to       */
/*           VI_NULL.                                                        */
/*===========================================================================*/
ViStatus TP04310_initCleanUp (ViSession openRMSession,
                    ViPSession openInstrSession, ViStatus currentStatus)
{
    TP04310_instrData instrPtr;
    
    if (viGetAttribute (*openInstrSession, VI_ATTR_USER_DATA, &instrPtr) >= 0)
        if (instrPtr != NULL) 
            free (instrPtr);

    viClose (*openInstrSession);
    viClose (openRMSession);
    *openInstrSession = VI_NULL;
    
    return currentStatus;
}

/*===========================================================================*/
/* Function: Read To File From Instrument                                    */
/* Purpose:  This function is used to read data from the instrument and      */
/*           write it to a user specified file.                              */
/*===========================================================================*/
ViStatus TP04310_readToFile (ViSession instrSession, ViString filename,
                    ViUInt32 readBytes, ViPUInt32 retCount)
{
    ViStatus  TP04310_status = VI_SUCCESS;
    ViByte    buffer[BUFFER_SIZE];
    ViUInt32  bytesReadInstr = 0, bytesWrittenFile = 0;
    FILE     *targetFile;

    *retCount = 0L;
    if ((targetFile = fopen (filename, "wb")) == VI_NULL)
        return VI_ERROR_INSTR_FILE_OPEN; /* not defined by VTL */

    for (;;) {
        if (readBytes > BUFFER_SIZE)
            TP04310_status = viRead (instrSession, buffer, BUFFER_SIZE, &bytesReadInstr);
        else
            TP04310_status = viRead (instrSession, buffer, readBytes, &bytesReadInstr);

        bytesWrittenFile = fwrite (buffer, sizeof (ViByte), (size_t)bytesReadInstr, targetFile);
        *retCount += bytesWrittenFile;
        if (bytesWrittenFile < bytesReadInstr)
            TP04310_status = VI_ERROR_INSTR_FILE_WRITE; /* not defined by VTL */

        if ((readBytes <= BUFFER_SIZE) || (TP04310_status <= 0) || (TP04310_status == VI_SUCCESS_TERM_CHAR))
            break;

        readBytes -= BUFFER_SIZE;
    }

    fclose (targetFile);
    return TP04310_status;
}

/*===========================================================================*/
/* Function: Write From File To Instrument                                   */
/* Purpose:  This function is used to read data from a user specified file   */
/*           and write it to the instrument.                                 */
/*===========================================================================*/
ViStatus TP04310_writeFromFile (ViSession instrSession, ViString filename,
                    ViUInt32 writeBytes, ViPUInt32 retCount)
{
    ViStatus  TP04310_status = VI_SUCCESS;
    ViByte    buffer[BUFFER_SIZE];
    ViUInt32  bytesRead = 0, bytesWritten = 0;
    FILE     *sourceFile;
    ViBoolean sendEnd = VI_FALSE;

    *retCount = 0L;
    if ((sourceFile = fopen (filename, "rb")) == VI_NULL)
        return VI_ERROR_INSTR_FILE_OPEN; /* not defined by VTL */

    while (!feof (sourceFile)) {
        bytesRead = (ViUInt32)fread (buffer, sizeof (ViByte), BUFFER_SIZE, sourceFile);
        if ((writeBytes > BUFFER_SIZE) && (bytesRead == BUFFER_SIZE)) {
            viGetAttribute (instrSession, VI_ATTR_SEND_END_EN, &sendEnd);
            viSetAttribute (instrSession, VI_ATTR_SEND_END_EN, VI_FALSE);
            TP04310_status = viWrite (instrSession, buffer, BUFFER_SIZE, &bytesWritten);
            viSetAttribute (instrSession, VI_ATTR_SEND_END_EN, sendEnd);
            writeBytes -= BUFFER_SIZE;
            *retCount += bytesWritten;
            if (TP04310_status < 0)
                break;
        }
        else {
            TP04310_status = viWrite (instrSession, buffer, ((bytesRead < writeBytes) ? bytesRead : writeBytes), &bytesWritten);
            *retCount += bytesWritten;
            break;
        }
    }

    fclose (sourceFile);
    return TP04310_status;
}

/*===========================================================================*/
/* Function: Default Instrument Setup                                        */
/* Purpose:  This function sends a default setup to the instrument.  This    */
/*           function is called by the TP04310_reset operation and by the     */
/*           TP04310_init function if the reset option has not been           */
/*           selected.  This function is useful for configuring any          */
/*           instrument settings that are required by the rest of the        */
/*           instrument driver functions such as turning headers ON or OFF   */
/*           or using the long or short form for commands, queries, and data.*/                                    
/*===========================================================================*/
ViStatus TP04310_defaultInstrSetup (ViSession instrSession)
{
    ViStatus TP04310_status = VI_SUCCESS;
    ViUInt32 retCnt = 0;
    TP04310_instrData instrPtr;
    
    /* Determine if the structure has been initialized for the current VISA  */
    /* Session and malloc if it has not.                                     */
    if (TP04310_status = viGetAttribute (instrSession, VI_ATTR_USER_DATA, &instrPtr))
        return TP04310_status;
    
    if (instrPtr == NULL) 
        instrPtr = malloc (sizeof (struct TP04310_instrStatusData));

	Fmt (instrPtr -> instrDriverRevision, "%s<%s", TP04310_REVISION);
    
    if ((TP04310_status = viSetAttribute (instrSession, VI_ATTR_USER_DATA, 
                            (ViUInt32)instrPtr)) < 0)
        return TP04310_status;                                       

    /*=====================================================================*/
    /* Send """ command to load the default setup           */
    /* send to your device.                                                */
    /*=====================================================================*/
    if ((TP04310_status = viWrite (instrSession, "*RST;DUTM 0;DSNS 0;FLOW 0;HEAD 0\r\n", 34, &retCnt)) < 0)
        return TP04310_status;

    return TP04310_status;
}

/*****************************************************************************/
/*=== END INSTRUMENT DRIVER SOURCE CODE =====================================*/
/*****************************************************************************/
